CREATE TABLE account_permission_events (
 id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id),
 actor TEXT NOT NULL, previous_reviewer INTEGER NOT NULL, reviewer INTEGER NOT NULL CHECK(reviewer IN (0,1)),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
