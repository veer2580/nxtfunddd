ALTER TABLE accounts ADD COLUMN email_verified_at INTEGER;
ALTER TABLE accounts ADD COLUMN verification_locked_until INTEGER NOT NULL DEFAULT 0;
ALTER TABLE investor_registrations ADD COLUMN decision TEXT NOT NULL DEFAULT 'pending' CHECK(decision IN ('pending','approved','rejected','suspended'));
ALTER TABLE investor_registrations ADD COLUMN version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE investor_registrations ADD COLUMN revision INTEGER NOT NULL DEFAULT 1;
ALTER TABLE investor_review_events ADD COLUMN internal_note TEXT NOT NULL DEFAULT '';
CREATE TABLE investor_drafts (
 account_id TEXT PRIMARY KEY REFERENCES accounts(id), fields_json TEXT NOT NULL,
 version INTEGER NOT NULL CHECK(version > 0), saved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE investor_submission_snapshots (
 registration_id TEXT NOT NULL REFERENCES investor_registrations(id), revision INTEGER NOT NULL,
 fields_json TEXT NOT NULL, risk_version TEXT NOT NULL, acknowledged_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(registration_id,revision)
);
CREATE TABLE investor_submission_keys (
 account_id TEXT NOT NULL REFERENCES accounts(id), submission_key TEXT NOT NULL, payload_hash TEXT NOT NULL,
 registration_id TEXT NOT NULL REFERENCES investor_registrations(id), revision INTEGER NOT NULL,
 PRIMARY KEY(account_id,submission_key)
);
CREATE TABLE email_challenges (
 id TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id), code_hash TEXT NOT NULL,
 created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
 consumed_at INTEGER, invalidated_at INTEGER
);
CREATE INDEX email_challenge_owner ON email_challenges(account_id,created_at);
CREATE TABLE verification_sends (
 account_id TEXT NOT NULL REFERENCES accounts(id), ip_hash TEXT NOT NULL, sent_at INTEGER NOT NULL
);
CREATE INDEX verification_send_time ON verification_sends(sent_at);
CREATE TABLE notification_outbox (
 id TEXT PRIMARY KEY, event_key TEXT NOT NULL UNIQUE, account_id TEXT NOT NULL REFERENCES accounts(id),
 kind TEXT NOT NULL, payload_json TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
 next_attempt_at INTEGER NOT NULL, delivered_at INTEGER, leased_until INTEGER NOT NULL DEFAULT 0,
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','delivered','failed','cancelled'))
);
CREATE INDEX notification_due ON notification_outbox(state,next_attempt_at);
