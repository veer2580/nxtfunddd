PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  reviewer INTEGER NOT NULL DEFAULT 0 CHECK (reviewer IN (0, 1))
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS investor_registrations (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL UNIQUE REFERENCES accounts(id),
  idempotency_key TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  reference TEXT NOT NULL UNIQUE,
  fields_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_review' CHECK (status IN ('pending_review', 'in_review', 'needs_information')),
  published INTEGER NOT NULL DEFAULT 0 CHECK (published = 0),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS investor_review_events (
  id TEXT PRIMARY KEY,
  registration_id TEXT NOT NULL REFERENCES investor_registrations(id),
  reviewer_id TEXT NOT NULL REFERENCES accounts(id),
  previous_status TEXT NOT NULL,
  status TEXT NOT NULL,
  applicant_message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  starts_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL
);
