# Investor backend foundation

Implemented locally on 4 October 2026, continuing the website audit. The source handbook is **NxtFund MVP implementation handbook v1.0**, the owner's 44-page PDF at `/Users/artiacharya/Downloads/NxtFund-MVP-Handoff.pdf`. Latest explicit owner approvals take precedence over conflicting public copy, header/design recommendations and legacy URL conventions. Approved public pages, hero and intro are preserved. Nothing has been deployed or provisioned.

## Exact review gap and completion

The earlier workflow could only start initial review or request information. It had no approval decision and therefore could not authorize an investor workspace. This milestone extends **the existing `investor_registrations` record and `investor_review_events` audit trail**, rather than introducing another registration/review system.

Local states: awaiting review → in review → changes requested, approved or not approved. Requested changes are resubmitted by the owner under the same reference as a new immutable revision. A not-approved profile must first be reopened by a reviewer. An approved profile can be suspended; suspension immediately blocks protected investor access. Resuming review removes approval until another authorized decision. Reviewers cannot review themselves. Approval requires a verified account email and a current submitted risk acknowledgement. It never publishes a public profile or represents regulatory approval.

## What works locally

- Authenticated **explicit Save draft**, ownership checks, saved timestamps and optimistic versions. Drafts survive sign-in, refresh and return visits. Stale writes return 409 and do not overwrite saved data. Versions remain monotonic across submissions. Before authentication, entries remain in React memory only; inline sign-in does not unmount the form. Existing saved drafts are offered for explicit restoration when pre-authentication entries exist.
- Random six-digit email verification, hashed validation codes, five-minute expiry, single use, resend replacement, 60-second resend cooldown, five failed attempts followed by a 15-minute lock, five sends per destination/hour and twenty per local loopback IP/hour. The server enforces these limits. Production code/email configuration is separate and disabled.
- Verified-email submission with server validation, risk acknowledgement, owned record, immutable revision, transactional outbox and commit-only reference. Identical retries return the existing receipt. Different pending submissions cannot overwrite records. Requested changes create a new revision with the same reference. An uncertain network result offers status reconciliation before another attempt.
- Authorized review decisions, optimistic review versions, applicant-visible explanations, separate internal notes and immutable review events. Reviewer permission is assigned/revoked only by a trusted local CLI; permission changes are also audited. Database permissions are checked freshly, not taken from client flags.
- Exactly three investor workspace destinations: **Overview**, **Browse startups**, **My interests**. Overview shows actual draft/pending/changes-requested/approved status and submitted preferences. Protected browse/interest pages and APIs require verified email and manual approval. Real dealflow, interest submission and budget editing are not connected; those areas report their actual availability rather than inventing records, empty totals or success.
- Transactional notification outbox with unique event keys, leased delivery, deduplication, exponential retry and a maximum of five attempts. Failed messages remain in the outbox for operator attention. Email failure cannot undo a committed registration/review decision. Messages contain safe references/next-step links, not confidential documents or internal review notes.

## Provider choice

No database/authentication stack had been selected. For deployment, the proposed setup is **PostgreSQL with Supabase Auth**, using request-scoped server authentication and private ownership/reviewer access rules. This remains a proposal, not a provisioned or integrated service.

Benefits: one PostgreSQL/authentication ecosystem, cookie-based Next server integration, database-level ownership policies and managed account lifecycle. Trade-offs: provider-specific auth/session integration, hosting limits/costs to evaluate for the selected plan, and continued responsibility for roles, application transactions, access policies, backups and rate limiting. Service credentials that bypass access policies must never reach the client. See the official [server-side authentication guide](https://supabase.com/docs/guides/auth/server-side/creating-a-client) and [row-level security guide](https://supabase.com/docs/guides/database/postgres/row-level-security).

## Exact local setup

Use Node 24 (tested with 24.21.0), in the project directory:

1. Run `npm run db:local -- migrate`.
2. Run `npm run dev:backend` and keep it running.
3. In another terminal, run `npm run mail:local -- --watch`. Alternatively run `npm run mail:local` after a verification request for one delivery pass.
4. Open **http://localhost:3101/investor-registration**. Use test information. Create/sign in to a local account inline, save a draft, request an email code and verify it.
5. Local emails are private JSON files in **`.local/mail/`**. Open that folder locally (`open .local/mail`) and read the message addressed to your test account. Codes never appear in normal UI/API responses or application logs. This is a development mailbox, **not actual external SMTP/email delivery**. Old codes expire or are invalidated by resend.
6. Complete review, acknowledge risk and submit. Open the investor Overview after the committed receipt.
7. For a reviewer, create a separate local account at `/login`. Run `npm run db:local -- reviewer <existing-account-email>`. Sign in at `/login?returnTo=/review/investor-registrations` and open a submission. Start review, then request changes or make a decision with an applicant-visible explanation. Internal notes are separate. This local role assignment does not supply production MFA or an approved operations checklist.
8. Revoke reviewer access with `npm run db:local -- revoke-reviewer <existing-account-email>`.

The configured origin is exactly `http://localhost:3101`; mutations from `127.0.0.1` or other origins are rejected. The server binds loopback. New local account passwords require 15–128 characters; existing local accounts retain compatible sign-in. Passwords allow spaces/Unicode and use salted scrypt. Opaque session tokens are hashed in SQLite and sent through HttpOnly, SameSite cookies. Local HTTP cookies and the existing eight-hour local sessions are not represented as the handbook's production session/MFA policy.

Drafts, records and mail are under ignored, private `.local/`, excluded from production tracing. Migrations 001–003 are transactional/checksum-tracked and preserve existing records. `.next-local` keeps backend development separate from the user's marketing-site server. No form contents, passwords or codes are saved in localStorage/sessionStorage or URLs; only the opaque HttpOnly session cookie is persisted by the browser. Unsaved pre-authentication fields are deliberately lost on refresh; the form warns before leaving with unsaved changes.

## Local URLs

Use the `http://localhost:3101` origin for each path:

| Path | Implemented behavior |
| --- | --- |
| `/investor-registration` | Approved three-step form, account access, verification, drafts, review and submission |
| `/onboarding/investor` | Handbook onboarding entry using the same form/system |
| `/login` | Local account access, role-appropriate utility links and sign-out |
| `/app/investor` | Investor Overview and actual status/preferences |
| `/app/investor/startups` | Approval-gated startup discovery availability |
| `/app/investor/interests` | Approval-gated interest availability |
| `/account/investor-registration` | Preserved status URL using the same owned record |
| `/review/investor-registrations` | Preserved authorized reviewer workflow |
| `/ops/reviews` | Handbook operator entry using the same reviewer component/system |

Protected direct workspace loads preserve the allowlisted intended path through sign-in. External/protocol-relative/script/encoded or unrelated `returnTo` destinations cannot redirect externally. Record requests always enforce ownership/role on the server; client owner IDs, verification/approval flags and publication fields are not trusted. Private responses use `private, no-store`; request bodies are bounded to 32 KiB and cookie-authenticated mutations require the configured origin. Public profiles remain impossible to publish (`published = 0` database constraint), including after approval. Typical ticket preferences never initialize or contribute to investment budget totals.

Existing API URLs remain connected: `/api/auth/session`, `/api/auth/verification`, `/api/investor-registrations`, `/api/investor-registrations/draft`, `/api/investor-registrations/review`, `/api/investor-workspace`. A full handbook `/api/v1` migration for the broader product is not claimed by this registration milestone.

## Verification

- ESLint, `npx tsc --noEmit`, **47 application tests**, and `npm run build -- --webpack` passed.
- Real, isolated SQLite tests cover migration/reopen, owned draft restoration, stale conflicts, verification expiry/reuse/resend/attempt/hourly limits, forged verification/role flags, submission eligibility, unchanged reference on requested-change resubmission, immutable revisions, valid approval/suspension, self/cross-account denial and revoked reviewer permissions.
- Registration/outbox insertion failure rolls back the entire transaction. Actual development-mail filesystem failure after commit leaves the saved registration intact; retries deliver once, deduplicate and stop after five failures.
- Live HTTP checks cover owned drafts, 409 conflicts, hidden codes, reused-code rejection, verified-only submission, duplicates, applicant/reviewer denial, approval transitions, private internal notes and immediate role revocation.
- A checked-in browser regression (`npm run test:investor-history`, requiring an isolated Chrome debug browser on loopback port 9223) verifies keyboard sign-out and Back/Forward cannot restore cached private profiles. Private history restoration clears the cached view before a fresh server/session check.
- Chrome keyboard-only journeys at **320px and 1440px** cover inline account creation, pre-authentication retention, private local code delivery/verification, focused risk validation errors, draft save/refresh, committed receipt, three-destination navigation, requested changes, owner resubmission, manual approval and applicant status. Reduced-motion mode was used at 320px. Mobile and desktop screenshots were visually inspected.
- The built production preview, even with `APP_NIVESH_LOCAL_BACKEND=1`, returns disabled account availability and 503 from verification, draft save, registration, review and workspace APIs. Registration and related page shells remain viewable. No production provider journey was tested.

Additional Chrome checks at **320, 375, 390, 430, 768, 1024 and 1440px** confirmed a single H1 and no horizontal overflow on registration and Overview, with reduced-motion rendering. Protected direct loading preserved the exact allowed destination through keyboard sign-in; keyboard sign-out revoked subsequent workspace access. Screenshots at 320px, 768px and 1440px were captured; mobile and desktop views were visually inspected. Browser fixtures are explicitly local test records, not platform investors or production seed data. These are functional checks, not a complete WCAG audit, staging load test or production recovery certification.

To rerun the history regression on macOS, keep `npm run dev:backend` running, launch an isolated browser with `"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless --remote-debugging-port=9223 --user-data-dir=/private/tmp/app-nivesh-history-browser`, then run `npm run test:investor-history`. It creates an explicitly private local test profile; it never seeds production or prints credentials/codes. A different local debugging endpoint can be configured with `APP_NIVESH_BROWSER_DEBUG_URL`.

## Remaining boundaries and production gates

**Local implementation is not production-ready.** `NODE_ENV=production` hard-disables this adapter regardless of flags. The handbook's broader product and release gates are not declared complete.

Before production:

1. Select/authorize actual database/authentication/deployment providers and configure isolated staging/production resources. PostgreSQL/Supabase is still only a proposal. Apply/test a production adapter and migrations; SQLite is a real local store, not a distributed production substitute.
2. Configure real transactional email, verified sender, durable delivery worker, account recovery and production verification tests. Configure the handbook's idle/absolute session policy and operator MFA/least-privilege scope. Local password/reset/MFA coverage is not claimed as a full identity lifecycle.
3. Supply approved Terms/Privacy and risk/consent versions, retention/deletion rules, support identity and the actual investor review checklist/reviewer assignments. No placeholder legal checkbox, contact address or approval policy is invented. The local risk acknowledgement is explicitly a development version; public-profile publication requires separate consent and implementation.
4. Complete production CSRF/origin, rate-limiting, credential management, security auditing, monitoring, backups and documented restore tests. Local loopback request/sender limits are not a distributed deployment solution.
5. Integrate approved startup discovery, interest submission and budget persistence/consent in their separate milestones. Do not manufacture data to make workspace destinations look operational. Startup/document, seller, partner and contact submission remain disabled; no private document storage was added here.
6. Execute production-provider commits/rollback, verification delivery, concurrent writes, revoked eligibility, private-cache, publication-consent, keyboard/zoom and recovery checks before enabling production actions.

Missing production credentials did not stop this local milestone. No paid resources, secrets or deployment were created.

## Investor post-submission review checkpoint

Submitted investors sign in to `/app/investor` by default; valid explicit internal return destinations remain supported. `/investor-registration` and `/onboarding/investor` resolve the owned saved state and direct submitted investors to Overview. Only drafts and server-authorized requested changes open the editing flow. Overview shows the actual review status, original submission date/reference, applicant-visible messages and grouped read-only submitted details. Verification remains separate from approval; no server ownership or reviewer permissions were relaxed.

With the local backend and isolated Chrome debugging browser running as above, `npm run test:investor-postsubmission` verifies draft restoration, submitted routing, explicit returns, authorized correction navigation with the keyboard and refresh. It creates private local test fixtures, revokes its temporary reviewer permission on exit and writes desktop/mobile screenshots to `/private/tmp/investor-overview-1440.png` and `/private/tmp/investor-overview-320.png`. It exercises the existing authentication rate limit; repeated runs may require waiting for its 15-minute window. It does not reset or bypass that limit. Use `npm run test:investor-history` for the logout/history privacy regression.
