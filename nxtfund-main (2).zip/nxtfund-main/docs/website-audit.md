# NxtFund website audit — 4 October 2026

Local working tree audit; no deployment, paid services, database changes or commits. Existing changes were preserved.

## Checklist

- [x] Read AGENTS.md and installed Next Link guidance; inspect routes, shared components, form validators, API guards and integration notes.
- [x] Inventory pages separately from operational backend features.
- [x] Check all 15 pages at 320, 390, 768, 1024 and 1440px for overflow, unique IDs, one H1 and one shared header/footer.
- [x] Inspect screenshots of every public page; preserve the approved desktop hero and responsive compositions.
- [x] Audit rendered destinations and section anchors; verify direct loading and refresh.
- [x] Correct navigation, contrast tokens, technical public copy and intro recovery.
- [x] Run lint, TypeScript, production build and functional validation tests.
- [ ] Enable real submissions, authentication and private listing access: infrastructure and policy decisions remain missing.
- [ ] Publish approved Terms and Privacy: no approved policy text was found.

## Implemented fixes

- Removed the disabled Login header entry and its unused styling. There is no authentication or useful account destination; no pretend login was created. The rectangular header, logo divider and dropdown styling remain.
- Mobile submenu disclosures now close after navigation. Parent sections have an active state on mobile as well as desktop.
- Added a keyboard-visible Skip to content link and focusable main-content target across public pages and route fallbacks.
- Introduced shared `--brand-text` for small red text, selected controls and errors. Brand-red backgrounds, borders and decorative accents remain unchanged; the darker text improves contrast on pale surfaces.
- Removed translation from the full-page reveal wrapper while preserving its fade and the hero image expansion. Browser testing found that scrolling during the wrapper translation left direct hash targets about 12px off after it settled.
- Added a five-second recovery deadline to the existing intro. Its normal timing, counter, expansion and reduced-motion behavior remain; a stalled animation cannot indefinitely lock scrolling and navigation. The timer is cancelled on completion/unmount.
- Replaced technical storage/persistence explanations in public seller/partner/contact and opportunity copy with concise action availability. Detailed integration requirements remain internal.
- Corrected root metadata that advertised declaring investment intent despite that feature being absent from the public journey.
- Added a route-contract test against actual filesystem pages and header destinations to catch stale availability maps and broken links. Updated an existing unavailable-search assertion for the revised copy.

No broad redesign or unnecessary packages were added. The homepage already has the approved Hero → How It Works → Why NxtFund → Investor Network → TrueValue → Closing CTA → Footer order. The empty declared-capital section remains removed; reusable investment-intent logic is preserved. No invented figures or records were introduced.

## Route and link status

“Connected” means an existing canonical destination, not a functioning submission backend.

| URL | Page exists | Navigation connected | Feature status |
| --- | --- | --- | --- |
| `/` | Yes | Logo, shared navigation | Marketing page, intro and interactive sections |
| `/about-us` | Yes | Header/footer | Information page |
| `/startups` | Yes | Header/footer/home | Pathway, checklist and FAQs |
| `/startup-registration` | Yes | Header, Startups, homepage process/closing, Due Diligence, Contact | Form preparation/review; Submit disabled |
| `/investors` | Yes | Header/footer/home | Category selector and intended pathway |
| `/investor-registration` | Yes | Header, Investors, homepage process/closing, Due Diligence, Contact | Form preparation/review; Submit disabled |
| `/due-diligence` | Yes | Header/footer/home/Startups/Investors | Intended review process; no real reports |
| `/truevalue` | Yes | Header/footer/home | Intended pathways; search and access requests unavailable |
| `/truevalue/list-your-business` | Yes | Header and TrueValue seller action | Seller preparation/review; Submit and uploads disabled |
| `/truevalue/[listing-id]` | No | Not exposed | Requires actual published records and authorization |
| `/ecosystem` | Yes | Header/footer | Participation selector and working teasers |
| `/partners` | Yes | Header/footer/Ecosystem | Potential collaboration; no invented directory |
| `/become-a-partner` | Yes | Header/Partners/Ecosystem | Enquiry preparation/review; Submit disabled |
| `/events` | Yes | Header/footer/Ecosystem | Honest upcoming/past empty states; no verified records |
| `/gallery` | Yes | Header/footer/Ecosystem | Honest empty state; no verified activity photos |
| `/contact-us` | Yes | Header/footer | Inline validation and dedicated-form links; Submit disabled |
| `/login` | No | Removed optional header entry | Authentication/account access missing |
| `/terms-and-conditions` | No | Footer label disabled | Approved legal text required |
| `/privacy-policy` | No | Footer label disabled | Approved legal text and data policies required |

No established page URLs were substituted with homepage anchors. Missing legal destinations are readable disabled labels rather than active 404 links. No verified contact details or approved founder identity photo were found; these remain omitted. Decorative assets do not identify actual members, events or transactions.

## Forms, data and privacy

Five POST endpoints return `503` with `Cache-Control: no-store` without reading confidential request bodies: startup applications, investor registrations, seller listings, partner enquiries and contact enquiries. Inputs remain usable; final submission is disabled. Entries stay in React memory, not localStorage; leaving/refresh clears them. Validation errors preserve entered values. There is no real confirmation, issued reference, email delivery, publication or verification.

Server-only validators enforce field lengths, enum allowlists, duplicate fields, email/phone, exact INR ranges, conditional fields and private projections. Startup PDF checks enforce the documented 5 MiB/file limit and reject malformed/active/encrypted documents; these are not a complete parser or malware scanner. Seller uploads are rejected while private storage is absent. No private retrieval endpoints are exposed. Denied access to an implemented private record cannot be tested because neither the records nor authorized retrieval workflow exists.

No database schema/provider, authentication provider, private object storage, deployment-backed rate limiter or approved live event/gallery/listing/profile data source is configured. TrueValue returns an explicit unavailable state rather than fake zero search results. Confirmation components require supplied receipts and remain unmounted; their unit fixtures are not real persisted applications.

Detailed integration boundaries: `src/lib/startup-application/README.md`, `src/lib/investor-registration/README.md`, `src/lib/truevalue/README.md`, `src/lib/truevalue/seller-entry/README.md`, `src/lib/partner-enquiry/README.md`, `src/lib/contact-enquiry/README.md`, and `src/app/events/README.md`.

## Verification

- Production Chrome audit: all 15 public pages × five requested widths (75 page/width scans). No document-level horizontal overflow, duplicate IDs or H1/header/footer count issues were found. Every page was visually inspected in captured screenshots; this is not a claim that every screenshot at every width received a pixel-by-pixel review.
- All 15 direct loads and refreshes return usable pages. Rendered section anchors resolve uniquely. No active missing legal/login links are exposed.
- Browser click/touch journeys cover Startups → application, Investors → registration, TrueValue → seller entry, Partners → enquiry, Ecosystem → Partners and homepage footer → Contact. Invalid form continuation gives errors without creating confirmations.
- Startup, investor, seller and partner preparation flows reach review at 320 and 1440px and retain edits. Startup uses an in-memory test PDF and financial-unavailability explanation; seller review keeps the business name out of the anonymous preview. Partner URL errors and selected collaboration areas are verified. Homepage tabs support keyboard switching; all investor/ecosystem category controls and startup FAQs were exercised.
- Mobile disclosure closing and desktop dropdown stacking/Escape/focus restoration checked. Normal intro locking/completion and direct investor-network hash loading/refresh checked; reduced motion, stalled-frame recovery, browser back/forward and the keyboard skip link checked.
- The shared dark-red text token measures 6.23:1 contrast on white, 5.62:1 on pale blue and 5.73:1 on pale yellow. This does not constitute a complete accessibility certification.
- Lint, standalone TypeScript, webpack production build and 33 functional tests pass. Tests cover server validation, duplicate/malformed inputs, rejected PDFs/uploads, private field projection, fail-closed retries, empty/error states, receipt requirements and route availability. These are not tests of live database/storage/authentication.
- Real saved submission, transactional rollback, idempotent saved receipts, private record/download authorization, listing filters/access approval, gallery lightbox and event booking remain untestable/unimplemented. No screen-reader audit or production deployment validation is claimed.

## Remaining blockers, ordered by impact

1. **Private persistence and identity:** choose/configure durable database, authenticated applicant/reviewer identities and server-side ownership/reviewer checks. Add migrations and private records, initial review statuses and transactionally issued non-sensitive receipts.
2. **Private document storage:** configure private object storage, authorization on every retrieval, deployment request limits, complete PDF parsing/malware scanning, staged upload cleanup and orphan reconciliation. Never use public assets or deployment-local files as document storage.
3. **Submission transport and abuse protection:** wire validators to authenticated/origin-protected handlers; deployment-backed rate limiting/body limits, atomic idempotency/duplicate controls, pending/error retention and real confirmation integration. Test commits, failures, duplicates and denied access before enabling Submit.
4. **Approved legal and privacy decisions:** actual Terms/Privacy text, retention/deletion policy, document handling, investor verification and publication consent. Do not invent these decisions or compliance assurances.
5. **TrueValue publication/access:** real reviewed listings with approved anonymous projections; authenticated verification plus seller approval for private access; only then listing-detail/access-request routes and live filters.
6. **Verified content:** approved event records, tagged actual activity photographs, partner/investor profiles and verified contact configuration. Omit directories and photos until approved data exists.
7. **Production readiness:** deployment/environment setup and operational checks are outside this local audit. The site is not launch-ready with these dependencies unresolved.
