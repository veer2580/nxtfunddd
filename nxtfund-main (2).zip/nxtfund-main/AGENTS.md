<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

# NxtFund coding standards

Apply these standards to all NxtFund work:

- Write readable, maintainable, idiomatic code.
- Inspect the existing architecture before changing it.
- Use clear names and focused components.
- Keep components separated by meaningful responsibility.
- Use shared design tokens and clear names.
- Add dependencies only when justified.
- Handle relevant loading, empty, error and permission states.
- Validate inputs and enforce access checks on the server.
- Use real data and functional actions; clearly identify unavailable features.
- Avoid unnecessary abstractions, duplicated logic, conflicting CSS overrides and speculative patches.
- Comments should explain why, not restate the code.
- Verify responsive behavior, accessibility and relevant checks.
- Run lint, TypeScript, build and relevant functional checks.
- Report honestly what was tested and what remains unverified.
- Avoid unnecessary abstractions and CSS patches.

## Homepage visual direction

- Give every homepage section a relevant photo, explanatory illustration or meaningful visual, with a distinct composition and shared typography, colours and spacing.
- Preserve the approved desktop hero, header and intro unless explicitly asked to change them; recompose layouts for mobile rather than shrinking the desktop design.
- Use brief, optional scroll or interaction transitions. Keep important content visible if animation fails, respect reduced motion and support touch and keyboard interaction.
- Reuse suitable local assets or create simple code-native SVG illustrations. Do not imply that decorative imagery proves real people, deals, partners or activity.
- Avoid excessive motion, artificial loading delays, repeated card grids, invented metrics, testimonials and funding guarantees.
- Size responsive visuals explicitly to avoid layout shifts, and identify missing assets and unavailable destinations honestly.
