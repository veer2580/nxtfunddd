// Use an isolated Chrome debug browser and npm run dev:backend. Fixtures stay private and local.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { requestVerification, verifyEmail } from '../src/lib/backend/email-verification.mjs';
import { saveRegistration } from '../src/lib/backend/investor-persistence.mjs';
import { openStore, authenticate } from '../src/lib/backend/local-store.mjs';

if (process.env.NODE_ENV === 'production') throw Error('Local browser fixtures are disabled in production.');
const debugUrl = new URL(process.env.APP_NIVESH_BROWSER_DEBUG_URL ?? 'http://127.0.0.1:9223');
assert.ok(['localhost', '127.0.0.1'].includes(debugUrl.hostname), 'Use a local isolated test browser.');
const tab = await (await fetch(new URL('/json/new?about:blank', debugUrl), { method: 'PUT' })).json();
const socket = new WebSocket(tab.webSocketDebuggerUrl);
await new Promise(resolve => socket.addEventListener('open', resolve, { once: true }));
let requestId = 0;
const requests = new Map();
socket.addEventListener('message', event => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const request = requests.get(message.id);
  if (!request) return;
  requests.delete(message.id);
  clearTimeout(request.timeout);
  if (message.error) request.reject(Error('Browser command failed.'));
  else request.resolve(message.result);
});
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++requestId;
    const timeout = setTimeout(() => { requests.delete(id); reject(Error('Browser command timed out.')); }, 10000);
    requests.set(id, { resolve, reject, timeout });
    socket.send(JSON.stringify({ id, method, params }));
  });
}
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true });
  if (result.exceptionDetails) throw Error('Browser evaluation failed.');
  return result.result.value;
}
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(expression, message) {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (await evaluate(expression)) return;
    await pause(100);
  }
  throw Error(message);
}
async function key(key, code, virtualKey) {
  const params = { key, code, windowsVirtualKeyCode: virtualKey, ...(key === 'Enter' ? { text: '\r' } : {}) };
  await send('Input.dispatchKeyEvent', { type: 'keyDown', ...params });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', ...params });
}
async function signOutWithKeyboard() {
  for (let attempt = 0; attempt < 130; attempt++) {
    if (await evaluate("document.activeElement.tagName==='BUTTON' && document.activeElement.textContent==='Sign out' && !document.activeElement.disabled")) {
      await key('Enter', 'Enter', 13);
      return;
    }
    await key('Tab', 'Tab', 9);
  }
  throw Error('Sign out is not reachable by keyboard.');
}

const db = openStore();
try {
  const email = `history-regression-${Date.now()}@example.test`;
  const signed = authenticate(db, email, randomUUID() + randomUUID(), true);
  requestVerification(db, signed.account, signed.account.id);
  const mail = db.prepare("SELECT payload_json FROM notification_outbox WHERE account_id=? AND kind='email_verification'").get(signed.account.id);
  verifyEmail(db, signed.account, JSON.parse(mail.payload_json).body.match(/\b\d{6}\b/)[0]);
  saveRegistration(db, signed.account, {
    fullName: 'Local history regression investor', email, phone: '+919876543210', registeringAs: 'individual',
    organisationName: '', investorCategory: 'vc', sectors: 'Climate', stages: 'Seed',
    minimumInvestment: '500000', maximumInvestment: '1000000', riskAcknowledged: 'true',
  }, randomUUID());
  await send('Page.enable');
  await send('Runtime.enable');
  await send('Network.enable');
  await send('Emulation.setFocusEmulationEnabled', { enabled: true });
  await send('Network.setCookie', { name: 'app-nivesh-session', value: signed.token, url: 'http://localhost:3101', httpOnly: true, sameSite: 'Lax' });
  await send('Page.navigate', { url: 'http://localhost:3101/app/investor' });
  await waitFor("document.querySelector('main')?.textContent.includes('Local history regression investor')", 'Owned status did not load.');
  const history = await send('Page.getNavigationHistory');
  const privateEntry = history.entries[history.currentIndex].id;
  await send('Page.navigate', { url: 'http://localhost:3101/login' });
  await waitFor("[...document.querySelectorAll('button')].some(button=>button.textContent==='Sign out')", 'Account utilities did not load.');
  await signOutWithKeyboard();
  await waitFor("!!document.getElementById('auth-email')", 'Sign-out did not finish.');
  await send('Page.navigateToHistoryEntry', { entryId: privateEntry });
  await waitFor("location.pathname==='/login' && !!document.getElementById('auth-email')", 'Back restored an authenticated workspace.');
  const privateDataAbsent = `!document.querySelector('main')?.textContent.includes('Local history regression investor') && !document.querySelector('main')?.textContent.includes(${JSON.stringify(email)})`;
  assert.ok(await evaluate(privateDataAbsent), 'Private profile remained visible after logout.');
  const afterBack = await send('Page.getNavigationHistory');
  if (afterBack.currentIndex + 1 < afterBack.entries.length) {
    await send('Page.navigateToHistoryEntry', { entryId: afterBack.entries[afterBack.currentIndex + 1].id });
    await waitFor("!!document.getElementById('auth-email')", 'Forward restored an authenticated account view.');
    assert.ok(await evaluate(privateDataAbsent), 'Forward exposed a private profile.');
  }
  console.log('Private history regression passed: keyboard sign-out, Back and Forward cannot restore a private profile.');
} finally {
  db.close();
  socket.close();
}
