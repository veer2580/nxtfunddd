// Use an isolated Chrome debug browser and npm run dev:backend. Fixtures stay private and local.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { requestVerification, verifyEmail } from '../src/lib/backend/email-verification.mjs';
import { saveRegistration } from '../src/lib/backend/investor-persistence.mjs';
import { openStore, authenticate } from '../src/lib/backend/local-store.mjs';

if (process.env.NODE_ENV === 'production') throw Error('Local browser fixtures are disabled in production.');
const debugUrl = new URL(process.env.APP_NIVESH_BROWSER_DEBUG_URL ?? 'http://127.0.0.1:9223');
assert.ok(['localhost', '127.0.0.1'].includes(debugUrl.hostname), 'Use a local isolated test browser.');
const tab = await (await fetch(new URL('/json/new?about:blank', debugUrl), { method: 'PUT' })).json();
const socket = new WebSocket(tab.webSocketDebuggerUrl);
await new Promise(resolve => socket.addEventListener('open', resolve, { once: true }));
let requestId = 0;
const requests = new Map();
socket.addEventListener('message', event => {
  const message = JSON.parse(event.data);
  if (!message.id) return;
  const request = requests.get(message.id);
  if (!request) return;
  requests.delete(message.id);
  clearTimeout(request.timeout);
  if (message.error) request.reject(Error('Browser command failed: '+message.error.message));
  else request.resolve(message.result);
});
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const id = ++requestId;
    const timeout = setTimeout(() => { requests.delete(id); reject(Error('Browser command timed out.')); }, 10000);
    requests.set(id, { resolve, reject, timeout });
    socket.send(JSON.stringify({ id, method, params }));
  });
}
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true });
  if (result.exceptionDetails) throw Error('Browser evaluation failed.');
  return result.result.value;
}
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(expression, message) {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (await evaluate(expression)) return;
    await pause(100);
  }
  throw Error(message);
}
async function key(key, code, virtualKey) {
  const params = { key, code, windowsVirtualKeyCode: virtualKey, ...(key === 'Enter' ? { text: '\r' } : {}) };
  await send('Input.dispatchKeyEvent', { type: 'keyDown', ...params });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', ...params });
}
const {saveDraft}=await import('../src/lib/backend/investor-drafts.mjs');
const {reviewRegistration,getRegistration}=await import('../src/lib/backend/local-store.mjs');
const {assignLocalReviewer}=await import('../src/lib/backend/local-admin.mjs');
const {writeFile}=await import('node:fs/promises');
const db=openStore();
let reviewerEmail;
const password=randomUUID()+randomUUID();
const email=`postsubmission-${Date.now()}@example.test`;
const signed=authenticate(db,email,password,true);
const fields={fullName:'Local UX Review Investor',email,phone:'+919876543210',registeringAs:'individual',organisationName:'',investorCategory:'vc',sectors:'Climate',stages:'Seed',minimumInvestment:'500000',maximumInvestment:'1000000',riskAcknowledged:'true'};
async function login(returnTo) {
 const response=await fetch('http://localhost:3101/api/auth/session',{method:'POST',headers:{'Content-Type':'application/json',Origin:'http://localhost:3101'},body:JSON.stringify({action:'login',email,password,...(returnTo?{returnTo}:{})})});
 assert.equal(response.status,200); return (await response.json()).returnTo;
}
async function navigate(path,expression) {
 await send('Page.navigate',{url:'http://localhost:3101'+path});
 await waitFor(expression,'State screen did not resolve');
}
try {
 await send('Page.enable');await send('Runtime.enable');await send('Network.enable');
 await send('Network.setCookie',{name:'app-nivesh-session',value:signed.token,url:'http://localhost:3101',httpOnly:true,sameSite:'Lax'});
 saveDraft(db,signed.account,{...fields,riskAcknowledged:'false'},0);
 assert.equal(await login(),'/investor-registration');
 await navigate('/investor-registration',"document.getElementById('field-fullName')?.value==='Local UX Review Investor'");
 await send('Page.reload');await waitFor("document.getElementById('field-fullName')?.value==='Local UX Review Investor'",'Draft refresh failed');
 console.log('Draft routing and restoration passed.');
 requestVerification(db,signed.account,signed.account.id);
 const mail=db.prepare("SELECT payload_json FROM notification_outbox WHERE account_id=? AND kind='email_verification'").get(signed.account.id);
 verifyEmail(db,signed.account,JSON.parse(mail.payload_json).body.match(/\b\d{6}\b/)[0]);
 const registration=saveRegistration(db,signed.account,fields,randomUUID(),1);
 assert.equal(await login(),'/app/investor');
 assert.equal(await login('/app/investor/interests'),'/app/investor/interests');
 assert.equal(await login('https://example.test'),'/app/investor');
 await send('Network.clearBrowserCookies');
 await navigate('/login',"!!document.getElementById('auth-email')");
 for (const [id, value] of [['auth-email', email], ['auth-password', password]]) {
  for (let attempt = 0; attempt < 100 && !await evaluate(`document.activeElement.id===${JSON.stringify(id)}`); attempt++) await key('Tab','Tab',9);
  assert.ok(await evaluate(`document.activeElement.id===${JSON.stringify(id)}`),'Sign-in field is keyboard accessible');
  await send('Input.insertText',{text:value});
 }
 await key('Tab','Tab',9);
 assert.ok(await evaluate("document.activeElement.tagName==='BUTTON' && document.activeElement.textContent==='Sign in'"));
 await key('Enter','Enter',13);
 await waitFor("location.pathname==='/app/investor' && !!document.getElementById('submitted-profile-heading')",'Default keyboard sign-in did not open Overview');

 await navigate('/investor-registration',"location.pathname==='/app/investor' && !!document.getElementById('submitted-profile-heading')");
 assert.ok(await evaluate("!document.querySelector('main form') && !document.querySelector('main').textContent.includes('Save draft')"));
 for(const width of [320,375,390,430,768,1440]) {
  await send('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width<768});
  await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
  await send('Page.reload');await waitFor("!!document.getElementById('submitted-profile-heading')",'Status refresh failed');await evaluate('window.scrollTo(0,0)');await pause(350);
  assert.ok(await evaluate('document.documentElement.scrollWidth<=innerWidth'),`Overflow ${width}`);
  if(width===320 || width===1440) {const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true});await writeFile(`/private/tmp/investor-overview-${width}.png`,Buffer.from(shot.data,'base64'));}
 }
 console.log('Submitted redirect, refresh, read-only layout, default sign-in and explicit returns passed; widths 320/375/390/430/768/1440.');
 const reviewer=authenticate(db,`ux-reviewer-${Date.now()}@example.test`,randomUUID()+randomUUID(),true);
 reviewerEmail = reviewer.account.email;
 assignLocalReviewer(db,reviewerEmail,true);
 reviewRegistration(db,reviewer.account,registration.id,'in_review','Review started.',registration.statusCode,registration.version);
 const current=getRegistration(db,signed.account);
 reviewRegistration(db,reviewer.account,current.id,'needs_information','Please clarify your preferred startup stages.',current.statusCode,current.version);
 await navigate('/app/investor',"document.querySelector('main')?.textContent.includes('Please clarify your preferred startup stages.')");
 let correctionOpened = false;
 for (let attempt = 0; attempt < 100; attempt++) {
  if (await evaluate("document.activeElement.tagName==='A' && document.activeElement.textContent==='Make requested changes'")) {
   await key('Enter','Enter',13); correctionOpened = true; break;
  }
  await key('Tab','Tab',9);
 }
 assert.ok(correctionOpened,'Correction action must be keyboard accessible');
 await waitFor("document.getElementById('field-fullName')?.value==='Local UX Review Investor'",'Correction form did not open');
 assert.ok(await evaluate("!document.getElementById('field-fullName').disabled"));
 await send('Page.reload');await waitFor("document.getElementById('field-fullName')?.value==='Local UX Review Investor'",'Correction refresh failed');
 console.log('Authorized changes-requested correction routing and refresh passed.');
} finally {
 if (reviewerEmail) assignLocalReviewer(db,reviewerEmail,false);
 db.close();socket.close();
}
