import { assignLocalReviewer } from '../src/lib/backend/local-admin.mjs';
import { drainOutbox } from '../src/lib/backend/notifications.mjs';
import { openStore } from '../src/lib/backend/local-store.mjs';
if (process.env.NODE_ENV === 'production') throw Error('Local database administration is disabled in production.');
const db = openStore();
const [command, email] = process.argv.slice(2);
if (command === 'reviewer' || command === 'revoke-reviewer') {
  assignLocalReviewer(db, email, command === 'reviewer');
  console.log('Local reviewer permission updated and audited.');
} else if (command === 'mail') {
  do {
    const result = await drainOutbox(db);
    if (email !== '--watch' || result.delivered || result.failed) console.log(result);
    if (email === '--watch') await new Promise(resolve => setTimeout(resolve, 1000));
  } while (email === '--watch');
} else if (command !== 'migrate') throw Error('Use migrate or reviewer <existing-account-email>.');
else console.log('Local migrations applied.');
db.close();
