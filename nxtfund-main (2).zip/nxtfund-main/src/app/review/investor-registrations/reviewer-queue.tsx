"use client";
import { useCallback, useEffect, useState } from "react";
import { investorReviewTransitions, investorReviewLabels } from "@/lib/investor-registration/review-states.mjs";
import { investorFieldLabels } from "@/lib/investor-registration/content";
import SiteLink from "../../components/site-link";
import styles from "../../components/registration.module.css";

type Registration = { id: string; reference: string; status: string; statusCode: string; fields: Record<string, string>; version: number };
export default function ReviewerQueue() {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [pending, setPending] = useState(true);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState("");
  const load = useCallback(() => fetch("/api/investor-registrations/review", { cache: "no-store" })
    .then(async response => {
      const result = await response.json();
      setError("");
      if (!response.ok) { setRegistrations([]); setError(result.message); return; }
      setRegistrations(result.registrations);
    })
    .catch(() => { setRegistrations([]); setError("Unable to load the review queue. Try again."); })
    .finally(() => setPending(false)), []);
  useEffect(() => { void load(); }, [load]);
  async function save(event: React.FormEvent<HTMLFormElement>, registration: Registration) {
    event.preventDefault();
    if (pending) return;
    const form = new FormData(event.currentTarget);
    setPending(true); setError(""); setSaved("");
    try {
      const response = await fetch("/api/investor-registrations/review", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: registration.id, status: form.get("status"), message: form.get("message"), expectedStatus: registration.statusCode, expectedVersion: registration.version, internalNote: form.get("internalNote") }) });
      const result = await response.json();
      if (!response.ok) { setError(result.message); return; }
      setSaved("Review update saved."); await load();
    } catch { setError("Unable to save the review. Your message remains in the form; retry."); }
    finally { setPending(false); }
  }
  return <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}><div className={styles.container}><h1>Investor review</h1><p>Local development workflow. Email verification is separate from manual investor approval. Public profiles remain unpublished.</p>
    {pending && <p role="status">Loading or saving…</p>}{error && <p role="alert">{error}</p>}{saved && <p role="status">{saved}</p>}
    {!pending && !error && registrations.length === 0 && <p>No investor registrations await review.</p>}
    {registrations.map(registration => <details key={registration.id} className={styles.review}><summary><strong>{registration.reference}</strong> — {registration.status}</summary><h2>{registration.reference}</h2><p>{registration.status}</p><dl>{Object.entries(registration.fields).filter(([, value]) => value).map(([label, value]) => <div key={label}><dt>{investorFieldLabels[label as keyof typeof investorFieldLabels] ?? label}</dt><dd>{value}</dd></div>)}</dl><form onSubmit={event => save(event, registration)}><fieldset className={styles.choiceGroup}><legend>Review decision</legend>{(investorReviewTransitions[registration.statusCode as keyof typeof investorReviewTransitions] ?? []).map((status: string, index: number) => <label className={styles.checkbox} key={status}><input id={`review-${registration.id}-${status}`} type="radio" name="status" value={status} defaultChecked={index === 0} disabled={pending} /><span>{investorReviewLabels[status as keyof typeof investorReviewLabels]}</span></label>)}</fieldset><div className={styles.field}><label htmlFor={`message-${registration.id}`}>Message visible to the applicant</label><textarea id={`message-${registration.id}`} name="message" disabled={pending} maxLength={1000} rows={3} /></div><div className={styles.field}><label htmlFor={`internal-${registration.id}`}>Internal reviewer note (not shown to applicant)</label><textarea id={`internal-${registration.id}`} name="internalNote" maxLength={2000} rows={3} disabled={pending} /></div><button disabled={pending || !(investorReviewTransitions[registration.statusCode as keyof typeof investorReviewTransitions]?.length)} className={styles.primary}>Save review decision</button></form></details>)}
    <div className={styles.actions}><button className={styles.secondary} disabled={pending} onClick={() => { setPending(true); setError(""); void load(); }}>Refresh queue</button><SiteLink href="/login?returnTo=/review/investor-registrations" className={styles.secondary}>Account access</SiteLink></div>
  </div></main>;
}
