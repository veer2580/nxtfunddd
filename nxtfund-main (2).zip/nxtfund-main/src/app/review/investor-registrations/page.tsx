import type { Metadata } from "next";
import SiteHeader from "../../components/site-header";
import ReviewerQueue from "./reviewer-queue";
export const metadata: Metadata = { title: "Investor Initial Review", robots: { index: false, follow: false } };
export default function Review() { return <><SiteHeader /><ReviewerQueue /></>; }
