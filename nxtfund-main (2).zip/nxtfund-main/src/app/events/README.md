# Events and Gallery availability

`/events` and `/gallery` are public pages. Header Ecosystem dropdown, Ecosystem teasers and footer link to their canonical routes. Shared header/footer appear once; no homepage intro runs.

Gallery photos (public/images/gallery) were supplied by the site owner and are used on /gallery. No verified event data source or approved event records exist yet. Local stage/panel/brand portraits are not verified activity photographs and are not used on either page. Events has Upcoming and Past Events empty states. Gallery has the requested empty message and an SVG illustration. No fabricated dates, event cards, registration links, photo filters or lightbox are created.

Before adding events, obtain verified title, explicit start/end dates with timezone, completed/upcoming/cancelled status, physical location or online format, description, approved image and genuine details/registration destination. Cancelled must take precedence over chronological grouping; verify each destination before enabling registration. No date classification is currently exercised because no records exist.

Before adding photographs, obtain approved actual activity images, consent/rights, descriptive alt text, useful captions and verified event tags. Reserve intrinsic dimensions and responsive image sizes. Add filters only for available tags and a keyboard/touch-accessible lightbox only for real photos, with Escape, focus containment/restoration and visible controls.

Native route error boundaries offer generic recovery with retry and no raw error details. These handle render failures, not a simulated data-query error. There is no query, loading delay or artificial event/photo dataset. Content is initially visible; optional one-time reveals respect reduced motion and failed observer initialization.
