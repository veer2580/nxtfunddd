import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import ActivityVisual from "../components/activity-visual";
import ActivitySection from "../components/activity-section";
import styles from "../components/activity-pages.module.css";

export const metadata: Metadata = { title: "Events", description: "Explore founder conversations, investor interactions and ecosystem programmes from NxtFund. Verified event announcements will appear when available." };
export default function EventsPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
    <section className={styles.hero} aria-labelledby="events-heading"><div className={`${styles.container} ${styles.split}`}>
      <div><p className={styles.eyebrow}>EVENTS AND CONVERSATIONS</p><h1 id="events-heading">Conversations that open new possibilities.</h1><p>Explore founder conversations, investor interactions and ecosystem programmes from NxtFund.</p></div>
      <figure className={styles.visual}><ActivityVisual kind="conversation" /></figure>
    </div></section>
    <div className={`${styles.container} ${styles.content}`}>
      <div className={styles.eventSections}>
        <ActivitySection id="upcoming-events"><h2 id="upcoming-events-heading">Upcoming</h2><div className={styles.emptyState}><div className={styles.emptyVisual}><ActivityVisual kind="upcoming" /></div><p>Upcoming events will appear here when announced.</p></div></ActivitySection>
        <ActivitySection id="past-events"><h2 id="past-events-heading">Past Events</h2><div className={styles.emptyState}><div className={styles.emptyVisual}><ActivityVisual kind="past" /></div><p>No verified past events are available to show.</p></div></ActivitySection>
      </div>
      <div className={styles.return}><SiteLink href="/ecosystem" className={styles.textAction}>Explore the ecosystem <span aria-hidden="true">↗</span></SiteLink></div>
    </div>
  </main></>;
}
