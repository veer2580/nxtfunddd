"use client";
import ActivityError from "../components/activity-error";
export default function EventsError({ retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return <ActivityError pageName="Events" retry={retry} />;
}
