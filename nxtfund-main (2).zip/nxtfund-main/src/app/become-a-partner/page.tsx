import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import PartnerVisual from "../partners/partner-visual";
import PartnerForm from "./partner-form";
import styles from "../components/registration.module.css";
export const metadata: Metadata = { title: "Become a Partner", description: "Prepare your organisation’s details and proposed collaboration with NxtFund. Enquiry submission is currently unavailable." };
export default function BecomePartnerPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}><div className={styles.container}>
    <div className={styles.introduction}><p className={styles.eyebrow}>ECOSYSTEM COLLABORATION</p><h1>Become a Partner</h1><p>Tell us about your organisation and how you would like to collaborate with NxtFund.</p></div>
    <div className={styles.layout}><aside className={styles.aside}><div className={styles.visual}><PartnerVisual /></div><h2>Begin with a shared direction.</h2><p>An enquiry is a starting point for review, not partnership approval. No organisation details are published by this form.</p></aside><PartnerForm /></div>
  </div></main></>;
}
