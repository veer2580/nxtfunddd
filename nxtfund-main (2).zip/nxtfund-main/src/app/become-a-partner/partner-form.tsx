"use client";
import { useEffect, useRef, useState, type CSSProperties } from "react";
import RegistrationField from "../components/registration-field";
import SiteLink from "../components/site-link";
import { isPublicRouteAvailable } from "../components/site-navigation";
import { collaborationOptions, initialPartnerFields, organisationOptions, partnerFieldLimits, partnerLabels, validatePartnerFields, type PartnerFields, type PartnerErrors } from "@/lib/partner-enquiry/validation";
import styles from "../components/registration.module.css";

const steps = ["Your organisation and proposal", "Review enquiry"];
export default function PartnerForm() {
  const [fields, setFields] = useState(initialPartnerFields);
  const [step, setStep] = useState(0);
  const [errors, setErrors] = useState<PartnerErrors>({});
  const heading = useRef<HTMLHeadingElement>(null);
  const summary = useRef<HTMLDivElement>(null);
  const moved = useRef(false);
  useEffect(() => { if (moved.current) heading.current?.focus(); moved.current = true; }, [step]);
  function update(name: keyof PartnerFields, value: string | string[]) {
    setFields(current => ({ ...current, [name]: value }));
    setErrors(current => { const remaining = { ...current }; delete remaining[name]; return remaining; });
  }
  function review() {
    const issues = validatePartnerFields(fields);
    setErrors(issues);
    if (Object.keys(issues).length) { requestAnimationFrame(() => summary.current?.focus()); return; }
    setStep(1);
  }
  function field(name: keyof typeof partnerFieldLimits, example: string, options: { inputMode?: "email" | "tel"; autoComplete?: string; multiline?: boolean; required?: boolean; options?: readonly { value: string; label: string }[] } = {}) {
    return <RegistrationField key={name} name={name} label={partnerLabels[name]} value={fields[name]} example={example} maxLength={partnerFieldLimits[name]} error={errors[name]} onChange={value => update(name, value)} {...options} />;
  }
  return <form className={styles.form} noValidate onSubmit={event => { event.preventDefault(); if (step === 0) review(); }}>
    <div className={styles.availability} role="note"><strong>Submission unavailable</strong><p>You can prepare and review your enquiry. Partnership enquiries cannot be saved yet.</p><p>Entries stay in this tab’s memory. Refreshing or leaving clears them; nothing is sent to the server.</p></div>
    <ol className={styles.progress} style={{ "--registration-steps": 2 } as CSSProperties} aria-label="Partner enquiry progress">{steps.map((label, index) => <li key={label} aria-current={step === index ? "step" : undefined}><span aria-hidden="true">0{index + 1}</span><span>{label}</span></li>)}</ol>
    <h2 ref={heading} tabIndex={-1}>{steps[step]}</h2>
    {Object.keys(errors).length > 0 && <div ref={summary} role="alert" tabIndex={-1} className={styles.errorSummary}><strong>Check these details before continuing.</strong><ul>{Object.entries(errors).map(([name, message]) => <li key={name}><a href={`#field-${name}`}>{name === "collaborationAreas" ? "Collaboration areas" : partnerLabels[name as keyof typeof partnerFieldLimits]}: {message}</a></li>)}</ul></div>}
    {step === 0 ? <fieldset className={styles.fields}>
      <legend className="visually-hidden">Your organisation and proposal</legend>
      {field("organisationName", "The name of your organisation", { autoComplete: "organization" })}
      {field("organisationType", "Choose the type that best describes your organisation.", { options: organisationOptions })}
      {field("website", "Optional. For example, https://example.org. Include http:// or https://.", { required: false, autoComplete: "url" })}
      {field("contactPerson", "The person to contact about this enquiry", { autoComplete: "name" })}
      {field("email", "For example, contact@example.org", { inputMode: "email", autoComplete: "email" })}
      {field("phone", "Include country code where applicable, for example +91 98765 43210", { inputMode: "tel", autoComplete: "tel" })}
      <fieldset id="field-collaborationAreas" tabIndex={-1} className={`${styles.fields} ${styles.field}`} aria-invalid={Boolean(errors.collaborationAreas)} aria-describedby={`collaborationAreas-hint${errors.collaborationAreas ? " collaborationAreas-error" : ""}`}>
        <legend>Preferred collaboration areas</legend><p id="collaborationAreas-hint" className={styles.hint}>Select all that apply. Explain Other in your proposal.</p>
        {collaborationOptions.map(option => <label key={option.value} className={styles.checkbox}><input type="checkbox" name="collaborationAreas" value={option.value} checked={fields.collaborationAreas.includes(option.value)} onChange={event => update("collaborationAreas", event.target.checked ? [...fields.collaborationAreas, option.value] : fields.collaborationAreas.filter(value => value !== option.value))} />{option.label}</label>)}
        {errors.collaborationAreas && <p id="collaborationAreas-error" className={styles.error}>{errors.collaborationAreas}</p>}
      </fieldset>
      {field("proposal", "Describe the collaboration you have in mind and the support or expertise your organisation could offer.", { multiline: true })}
    </fieldset> : <div className={styles.review}>
      <dl>{(Object.keys(partnerLabels) as (keyof typeof partnerFieldLimits)[]).map(name => <div key={name}><dt>{partnerLabels[name]}</dt><dd>{name === "organisationType" ? organisationOptions.find(option => option.value === fields[name])?.label : fields[name] || "Not provided"}</dd></div>)}<div><dt>Preferred collaboration areas</dt><dd>{collaborationOptions.filter(option => fields.collaborationAreas.includes(option.value)).map(option => option.label).join("\n")}</dd></div></dl>
      <p>This enquiry is intended for review. It does not mean partnership approval, and no organisation profile is published.</p>
    </div>}
    <div className={styles.actions}>{step === 0 ? <button type="button" onClick={review} className={styles.primary}>Review enquiry</button> : <><button type="button" className={styles.secondary} onClick={() => { setErrors({}); setStep(0); }}>Edit enquiry</button><button type="submit" disabled className={styles.primary} aria-describedby="partner-submission-status">Submit enquiry — unavailable</button></>}</div>
    <p id="partner-submission-status" className={styles.hint}>Enquiry submission is currently unavailable. No enquiry has been saved.</p>
    <SiteLink href="/partners">Back to Partners</SiteLink>
    {isPublicRouteAvailable("/privacy-policy") && <SiteLink href="/privacy-policy">Privacy Policy</SiteLink>}
  </form>;
}
