import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import styles from "./investor-brief.module.css";

export const metadata: Metadata = {
  title: "Global Investor & Ecosystem Brief",
  description: "A global startup ecosystem connecting founders, capital, technology and opportunity.",
};

const regions = [
  { name: "USA", note: "Innovation Capital" },
  { name: "UK", note: "Strategic Partnerships" },
  { name: "Switzerland", note: "Global Wealth Partners" },
  { name: "UAE", note: "Growth Markets" },
  { name: "Singapore", note: "Investor Networks" },
  { name: "Europe", note: "Collaboration & Access" },
  { name: "Latin America", note: "Emerging Markets, New Opportunities" },
  { name: "Asia Pacific", note: "Scaling Global Opportunities" },
];

const investorTypes = [
  { title: "VC Network", copy: "Top tier venture capital firms from around the world." },
  { title: "Family Offices", copy: "Long-term capital for high-impact ventures." },
  { title: "HNI / UHNI Investors", copy: "High net worth individuals backing bold ideas." },
  { title: "Angel Investors", copy: "Early believers in tomorrow’s leaders." },
  { title: "Strategic Investors", copy: "Industry leaders with more than capital." },
  { title: "Global Investor Partners", copy: "Cross-border access to markets, networks and talent." },
];

const people = [
  { name: "Amit Singal", org: "Fluid Ventures" },
  { name: "Sumit Srivastava", org: "Startup Chaupal" },
  { name: "Mr. Pankaj", org: "Organic Funding" },
  { name: "Vivek Chadha", org: "AccelerateX" },
  { name: "Mr. Radhesh", org: "Shark Tank India" },
  { name: "Mr. Rakesh", org: "i-Start" },
  { name: "Mr. Shalabhh", org: "Marwari Catalysts" },
  { name: "Mr. Jamil", org: "i-Start" },
  { name: "Mr. Veer Singh", org: "IDFC Bank" },
];

function initials(name: string) {
  return name.replace(/^Mr\.\s*/, "").split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}

export default function InvestorBriefPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
    <section className={styles.hero} aria-labelledby="brief-heading"><div className={styles.container}>
      <p className={styles.eyebrow}>GLOBAL INVESTOR &amp; ECOSYSTEM BRIEF</p>
      <h1 id="brief-heading">Building the Next Generation of <span>Global</span> Companies.</h1>
      <p className={styles.lede}>A Global Startup Ecosystem Connecting <span>Founders, Capital, Technology</span> &amp; Opportunity.</p>
      <p className={styles.badge}>STARTUPS FROM AROUND THE WORLD CAN APPLY.</p>
    </div></section>

    <section className={styles.section} aria-labelledby="regions-heading"><div className={styles.container}>
      <h2 id="regions-heading" className={styles.center}>Our Global Reach</h2>
      <ul className={styles.regions}>
        <li className={styles.hub}><strong>India</strong><span>Our Strategic Hub</span></li>
        {regions.map((r) => <li key={r.name}><strong>{r.name}</strong><span>{r.note}</span></li>)}
      </ul>
    </div></section>

    <section className={styles.section} aria-labelledby="network-heading"><div className={styles.container}>
      <h2 id="network-heading" className={styles.center}>GLOBAL INVESTOR NETWORK</h2>
      <p className={`${styles.center} ${styles.muted}`}>Connecting founders with capital, expertise and strategic access.</p>
      <ul className={styles.types}>
        {investorTypes.map((t) => <li key={t.title}><h3>{t.title}</h3><p>{t.copy}</p></li>)}
      </ul>
      <div className={styles.actions}>
        <SiteLink className={styles.primary} href="/investor-registration">JOIN THE NETWORK →</SiteLink>
        <SiteLink className={styles.secondary} href="/investors">EXPLORE INVESTOR ACCESS →</SiteLink>
      </div>
    </div></section>

    <section className={`${styles.section} ${styles.people}`} aria-labelledby="people-heading"><div className={styles.container}>
      <p className={`${styles.eyebrow} ${styles.center}`}>OUR NETWORK &amp; ECOSYSTEM</p>
      <h2 id="people-heading" className={styles.center}>Meet the People Behind Our Journey</h2>
      <p className={`${styles.center} ${styles.muted}`}>A strong network of investors, mentors and industry leaders who have been part of our events and growing startup ecosystem.</p>
      <ul className={styles.peopleGrid}>
        {people.map((p) => (
          <li key={p.name}>
            <span className={styles.avatar} aria-hidden="true">{initials(p.name)}</span>
            <strong>{p.name}</strong><i aria-hidden="true" /><span>{p.org}</span>
          </li>
        ))}
      </ul>
    </div></section>
  </main></>;
}
