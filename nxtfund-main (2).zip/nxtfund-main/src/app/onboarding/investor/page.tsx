export { default, metadata } from "../../investor-registration/page";
