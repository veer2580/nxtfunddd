import RegistrationStatus from "../../components/registration-status";
import { investorPageAccount } from "@/lib/backend/investor-page";
export default async function Overview() { if (!await investorPageAccount("/app/investor")) return null; return <RegistrationStatus workspace />; }
