import type { Metadata } from "next";
import { localBackendEnabled } from "@/lib/backend/local-store.mjs";
import SiteHeader from "../../components/site-header";
import InvestorNavigation from "../../components/investor-navigation";
import styles from "../../components/registration.module.css";
export const metadata: Metadata = { title: "Investor Workspace", robots: { index: false, follow: false } };
export default async function InvestorLayout({ children }: { children: React.ReactNode }) {
  if (!localBackendEnabled()) return <><SiteHeader /><main id="main-content" className={`page-surface ${styles.page}`}><div className={styles.container}><h1>Investor workspace unavailable</h1><p>Production account access is not configured. The registration page remains viewable.</p></div></main></>;
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}><div className={styles.container}><InvestorNavigation />{children}</div></main></>;
}
