import InvestorAccessState from "../../../components/investor-access-state";
export default function Browse() { return <InvestorAccessState view="startups" />; }
