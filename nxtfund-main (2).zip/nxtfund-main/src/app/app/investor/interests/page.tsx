import InvestorAccessState from "../../../components/investor-access-state";
export default function Interests() { return <InvestorAccessState view="interests" />; }
