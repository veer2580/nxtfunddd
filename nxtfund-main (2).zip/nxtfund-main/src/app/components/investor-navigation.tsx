"use client";
import { usePathname } from "next/navigation";
import Link from "next/link";
import styles from "./registration.module.css";
const destinations = [["/app/investor", "Overview"], ["/app/investor/startups", "Browse startups"], ["/app/investor/interests", "My interests"]] as const;
export default function InvestorNavigation() {
  const path = usePathname();
  return <nav aria-label="Investor workspace" className={styles.actions}>{destinations.map(([href, label]) => <Link className={styles.secondary} key={href} href={href} aria-current={path === href ? "page" : undefined}>{label}</Link>)}</nav>;
}
