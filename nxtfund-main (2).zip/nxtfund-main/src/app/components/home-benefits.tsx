"use client";

import SiteLink from "./site-link";
import OpportunityIllustration from "./opportunity-illustration";
import { useScrollReveal } from "./use-scroll-reveal";
import styles from "./home-benefits.module.css";

const benefits = [
  {
    illustration: "diligence",
    title: "Due diligence before introductions",
    description:
      "Financial, legal, background and market checks help investors assess a startup beyond its pitch deck.",
  },
  {
    illustration: "investors",
    title: "Access to the right investor network",
    description:
      "Connect across VCs, angels, HNIs/UHNIs, strategic investors, global investor partners and family offices.",
  },
  {
    illustration: "grants",
    title: "Government grant support",
    description:
      "Explore relevant government schemes and application support where your startup meets the eligibility requirements.",
  },
  {
    illustration: "truevalue",
    title: "A pathway beyond fundraising",
    description:
      "Through TrueValue, explore opportunities to sell a business, product, IP or ownership stake.",
  },
] as const;

export default function HomeBenefits() {
  const { ref: section, entered } = useScrollReveal<HTMLElement>();

  return (
    <section
      ref={section}
      id="why-nxtfund"
      aria-labelledby="benefits-heading"
      className={styles.section}
      data-entered={entered}
    >
      <div className={styles.container}>
        <div className={styles.introduction}>
          <p className={styles.eyebrow}>WHY NXTFUND</p>
          <h2 id="benefits-heading">Better connections begin with greater clarity.</h2>
          <p className={styles.description}>
            A structured approach to startup discovery, investor introductions and the next chapter of business ownership.
          </p>
        </div>
        <ol className={styles.benefits}>
          {benefits.map((benefit, index) => (
            <li key={benefit.title} id={benefit.illustration === "diligence" ? "due-diligence" : undefined}>
              <div className={styles.visual} data-illustration={benefit.illustration}>
                <OpportunityIllustration kind={benefit.illustration} />
              </div>
              <div className={styles.benefitContent}>
                <span className={styles.number} aria-hidden="true">0{index + 1}</span>
                <h3>{benefit.title}</h3>
                <p>{benefit.description}</p>
                {benefit.illustration === "diligence" && <SiteLink href="/due-diligence" className={styles.action}>Explore due diligence <span aria-hidden="true">↗</span></SiteLink>}

              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
