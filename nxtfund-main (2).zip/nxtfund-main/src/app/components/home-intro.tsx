"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

// One source of approved copy for the intro and the expanded hero.
export const homeHeroContent = {
  headline: "Fund the Next Big Idea. Back the Next Big Return.",
  headlineLines: ["Fund the Next", "Big Idea.", "Back the Next", "Big Return."],
  description:
    "NxtFund connects India's startups with the right investors — VCs, angel investors, HNIs, family offices, and strategic partners — through a process built on real due diligence, not just a pitch deck.",
  actions: [
    { label: "I'm an Investor", href: "/investors" },
    { label: "I'm a Startup", href: "/startups" },
  ],
} as const;

const IntroContext = createContext({ opened: false, progress: 0 });

export function useHomeIntro() {
  return useContext(IntroContext);
}

export default function HomeIntro({ children }: { children: ReactNode }) {
  const [opened, setOpened] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!opened || !window.location.hash) return;
    // Hash targets are laid out only after the intro reveals the rest of the page.
    const frame = requestAnimationFrame(() => {
      const target = document.getElementById(window.location.hash.slice(1));
      target?.scrollIntoView({ behavior: "instant", block: "start" });
    });
    return () => cancelAnimationFrame(frame);
  }, [opened]);

  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const root = document.documentElement;
    const body = document.body;
    const rootOverflow = root.style.overflow;
    const bodyOverflow = body.style.overflow;
    let frame = 0;
    let startedAt: number | undefined;

    function unlock() {
      root.style.overflow = rootOverflow;
      body.style.overflow = bodyOverflow;
    }

    function finish() {
      clearTimeout(completionTimer);
      cancelAnimationFrame(frame);
      setProgress(100);
      setOpened(true);
      unlock();
    }

    function onPreferenceChange(event: MediaQueryListEvent) {
      if (event.matches) finish();
    }

    const animate = (now: number) => {
      startedAt ??= now;
      const elapsed = now - startedAt;
      const fraction = Math.min(Math.max((elapsed - 1000) / 2400, 0), 1);
      const eased = fraction < 0.5
        ? 2 * fraction * fraction
        : 1 - Math.pow(-2 * fraction + 2, 2) / 2;
      setProgress(Math.round(eased * 100));
      if (elapsed >= 3700) finish();
      else frame = requestAnimationFrame(animate);
    };

    // A stalled animation frame must not keep navigation and scrolling locked.
    const completionTimer = setTimeout(finish, 5000);
    if (preference.matches) {
      // Defer the state update until after the initial render.
      frame = requestAnimationFrame(finish);
    } else {
      root.style.overflow = "hidden";
      body.style.overflow = "hidden";
      frame = requestAnimationFrame(animate);
    }
    preference.addEventListener("change", onPreferenceChange);
    return () => {
      clearTimeout(completionTimer);
      cancelAnimationFrame(frame);
      preference.removeEventListener("change", onPreferenceChange);
      unlock();
    };
  }, []);

  return (
    <IntroContext.Provider value={{ opened, progress }}>
      <div className="home-intro" data-opened={opened}>{children}</div>
    </IntroContext.Provider>
  );
}

export function IntroReveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const { opened } = useHomeIntro();
  return (
    <div className={`intro-reveal ${className}`} inert={!opened} aria-hidden={!opened}>
      {children}
    </div>
  );
}
