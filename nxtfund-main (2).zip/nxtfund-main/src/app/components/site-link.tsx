import Link from "next/link";
import type { ComponentProps } from "react";
import { getPublicDestination } from "./site-navigation";

type SiteLinkProps = Omit<ComponentProps<typeof Link>, "href"> & { href: string };

export default function SiteLink({ href, children, onClick, ...props }: SiteLinkProps) {
  const destination = getPublicDestination(href);
  // Native fragment links also re-scroll when the selected hash is already current.
  if (destination?.startsWith("/#")) return <a href={destination} onClick={onClick} {...props}>{children}</a>;
  if (destination) return <Link href={destination} onClick={onClick} {...props}>{children}</Link>;

  // Missing pages remain readable and focusable without becoming dead navigation targets.
  return (
    <span
      className={`${props.className ?? ""} unavailable-link`}
      role="link"
      aria-disabled="true"
      tabIndex={props.tabIndex ?? 0}
      title="Page unavailable"
      aria-label={props["aria-label"]}
      aria-describedby={props["aria-describedby"]}
    >
      {children}<span className="visually-hidden"> — Page unavailable</span>
    </span>
  );
}
