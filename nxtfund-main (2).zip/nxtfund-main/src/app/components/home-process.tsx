"use client";

import { useRef, useState, type KeyboardEvent } from "react";
import SiteLink from "./site-link";
import { registrationRoutes } from "./site-navigation";
import OpportunityIllustration from "./opportunity-illustration";
import { useScrollReveal } from "./use-scroll-reveal";
import styles from "./home-process.module.css";

const pathways = [
  {
    id: "startups",
    label: "For Startups",
    steps: [
      { title: "Share your startup", description: "Submit your pitch, team details and financial information." },
      { title: "Prepare for investor conversations", description: "Complete due diligence and pitch to the relevant investor network." },
      { title: "Connect directly", description: "Discuss funding with interested investors, with government grant support where eligible." },
    ],
  },
  {
    id: "investors",
    label: "For Investors",
    steps: [
      { title: "Register and get verified", description: "Share your investor profile and investment preferences." },
      { title: "Explore relevant startups", description: "Browse startups that have completed the due diligence process." },
      { title: "Connect on your terms", description: "Speak directly with founders and structure your investment agreement with them." },
    ],
  },
] as const;

export default function HomeProcess() {
  const { ref: timeline, entered } = useScrollReveal<HTMLDivElement>();
  const [selectedTab, setSelectedTab] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);

  function navigateTabs(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next: number;
    switch (event.key) {
      case "ArrowRight": next = (index + 1) % pathways.length; break;
      case "ArrowLeft": next = (index + pathways.length - 1) % pathways.length; break;
      case "Home": next = 0; break;
      case "End": next = pathways.length - 1; break;
      default: return;
    }
    event.preventDefault();
    setSelectedTab(next);
    tabs.current[next]?.focus();
  }

  return (
    <section id="process" aria-labelledby="process-heading" className={styles.process}>
      <div className={styles.introduction}>
        <p className={styles.eyebrow}>HOW IT WORKS</p>
        <h2 id="process-heading">A clear path to your next opportunity.</h2>
        <p className={styles.description}>Choose your pathway and see what comes next.</p>
        <p className={styles.availability}>These steps outline the intended process. Startup and investor submissions are currently unavailable.</p>
        <div role="tablist" aria-label="Choose your pathway" className={styles.tabs}>
          {pathways.map((pathway, index) => (
            <button
              key={pathway.id}
              ref={(element) => { tabs.current[index] = element; }}
              type="button"
              role="tab"
              id={`process-tab-${pathway.id}`}
              aria-controls={`process-panel-${pathway.id}`}
              aria-selected={selectedTab === index}
              tabIndex={selectedTab === index ? 0 : -1}
              onClick={() => setSelectedTab(index)}
              onKeyDown={(event) => navigateTabs(event, index)}
            >
              {pathway.label}
            </button>
          ))}
        </div>
      </div>
      <div ref={timeline} className={styles.timeline} data-entered={entered}>
        {pathways.map((pathway, index) => (
          <div
            key={pathway.id}
            role="tabpanel"
            id={`process-panel-${pathway.id}`}
            aria-labelledby={`process-tab-${pathway.id}`}
            aria-hidden={selectedTab !== index}
            inert={selectedTab !== index}
            tabIndex={selectedTab === index ? 0 : -1}
            data-active={selectedTab === index}
            className={styles.panel}
          >
            <figure className={styles.visual} data-pathway={pathway.id}>
              <OpportunityIllustration kind={pathway.id === "startups" ? "startup" : "investors"} />
            </figure>
            <div className={styles.panelContent}>
              <ol className={styles.steps}>
                {pathway.steps.map((step, stepIndex) => (
                  <li key={step.title}>
                    <span className={styles.number} aria-hidden="true">0{stepIndex + 1}</span>
                    <div>
                      <h3>{step.title}</h3>
                      <p>{step.description}</p>
                    </div>
                  </li>
                ))}
              </ol>
              <SiteLink href={pathway.id === "startups" ? registrationRoutes.startup : registrationRoutes.investor} className={styles.action}>{pathway.id === "startups" ? "Apply as a Startup" : "Join as an Investor"} <span aria-hidden="true">↗</span></SiteLink>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
