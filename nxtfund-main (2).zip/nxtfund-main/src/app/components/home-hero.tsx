"use client";

import Image from "next/image";
import SiteLink from "./site-link";
import { homeHeroContent, useHomeIntro } from "./home-intro";
import styles from "./home-hero.module.css";

const heroImages = [
  { src: "/images/hero-a.jpg", color: "yellow", objectPosition: "50% 25%", mobileOnly: false },
  { src: "/images/hero-b.jpg", color: "blue", objectPosition: "50% 30%", mobileOnly: false },
  { src: "/images/hero-c.jpg", color: "yellow", objectPosition: "50% 30%", mobileOnly: true },
  { src: "/images/hero-c.jpg", color: "yellow", objectPosition: "50% 30%", mobileOnly: false },
] as const;

export default function HomeHero() {
  const { opened, progress } = useHomeIntro();

  return (
    <section
      id="hero"
      className={styles.hero}
      aria-labelledby="hero-heading"
      data-opened={opened}
    >
      <h1 id="hero-heading" className={styles.srOnly}>
        {homeHeroContent.headline}
      </h1>

      <div className={styles.composition}>
        {homeHeroContent.headlineLines.map((line, index) => {
          const visual = heroImages[index];
          return (
            <div
              key={line}
              className={`${styles.row} ${index % 2 ? styles.imageFirst : styles.imageLast}`}
            >
              <div className={styles.word} aria-hidden="true">
                <span>{line}</span>
              </div>
              <div className={`${styles.visual} ${styles[visual.color]} ${visual.mobileOnly ? styles.mobileOnly : ""}`}>
                <div className={styles.imageWrap}>
                  <Image
                    src={visual.src}
                    alt=""
                    fill
                    loading="eager"
                    sizes="(max-width: 900px) 30vw, (max-width: 1384px) 23vw, 304px"
                    className={styles.image}
                    style={{ objectPosition: visual.objectPosition }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className={styles.introProgress} aria-hidden="true">
        <div className={styles.introLine} />

        <div className={styles.progressRow}>
          <span className={styles.counter}>{progress}</span>
        </div>
      </div>

      <div className={styles.heroDetails}>
        <p className={styles.description}>{homeHeroContent.description}</p>
        <div className={styles.ctaWrap}>
          {homeHeroContent.actions.map((action) => (
            <SiteLink
              key={action.href}
              href={action.href}
              className={styles.cta}
              tabIndex={opened ? 0 : -1}
            >
              {action.label}
            </SiteLink>
          ))}
        </div>
      </div>

    </section>
  );
}
