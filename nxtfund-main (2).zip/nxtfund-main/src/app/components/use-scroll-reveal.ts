"use client";

import { useEffect, useRef, useState } from "react";
import { useHomeIntro } from "./home-intro";

export function useScrollReveal<T extends HTMLElement>(ready?: boolean) {
  const { opened } = useHomeIntro();
  const enabled = ready ?? opened;
  const ref = useRef<T>(null);
  const [entered, setEntered] = useState(false);

  useEffect(() => {
    if (!enabled || !ref.current || typeof IntersectionObserver === "undefined") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let observer: IntersectionObserver | undefined;
    try {
      observer = new IntersectionObserver(([entry]) => {
        if (entry.isIntersecting) {
          setEntered(true);
          observer?.disconnect();
        }
      }, { threshold: 0.1 });
      observer.observe(ref.current);
    } catch {
      // Observation enhances the presentation; it must never gate access to content.
      observer?.disconnect();
    }
    return () => observer?.disconnect();
  }, [enabled]);

  return { ref, entered };
}
