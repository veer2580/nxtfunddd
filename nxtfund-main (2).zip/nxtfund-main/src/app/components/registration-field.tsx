import type { ChangeEvent } from "react";
import styles from "./registration.module.css";

export default function RegistrationField({ name, label, value, onChange, error, example, maxLength, required = true, multiline = false, inputMode, autoComplete, options }: {
  name: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  example: string;
  maxLength: number;
  required?: boolean;
  multiline?: boolean;
  inputMode?: "email" | "tel" | "decimal";
  autoComplete?: string;
  options?: readonly { value: string; label: string }[];
}) {
  const props = {
    id: `field-${name}`, name, value, required,
    onChange: (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => onChange(event.target.value),
    "aria-invalid": Boolean(error),
    "aria-describedby": `${name}-hint${error ? ` ${name}-error` : ""}`,
  };
  return <div className={styles.field}>
    <label htmlFor={props.id}>{label}</label>
    {options ? <select {...props}><option value="">Choose an option</option>{options.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select>
      : multiline ? <textarea {...props} maxLength={maxLength} rows={4} />
      : <input {...props} maxLength={maxLength} type={inputMode === "email" ? "email" : "text"} inputMode={inputMode} autoComplete={autoComplete} />}
    <p id={`${name}-hint`} className={styles.hint}>{example}</p>
    {error && <p id={`${name}-error`} className={styles.error}>{error}</p>}
  </div>;
}
