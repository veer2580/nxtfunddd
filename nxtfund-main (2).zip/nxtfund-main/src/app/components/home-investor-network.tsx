"use client";

import { useRef, useState, type KeyboardEvent } from "react";
import { useScrollReveal } from "./use-scroll-reveal";
import styles from "./home-investor-network.module.css";

import { investorCategories as categories } from "@/lib/investor-categories";

export default function HomeInvestorNetwork() {
  const { ref, entered } = useScrollReveal<HTMLElement>();
  const [selectedCategory, setSelectedCategory] = useState(0);
  const controls = useRef<(HTMLButtonElement | null)[]>([]);

  function navigateCategories(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next: number;
    switch (event.key) {
      case "ArrowRight": case "ArrowDown": next = (index + 1) % categories.length; break;
      case "ArrowLeft": case "ArrowUp": next = (index + categories.length - 1) % categories.length; break;
      case "Home": next = 0; break;
      case "End": next = categories.length - 1; break;
      default: return;
    }
    event.preventDefault();
    setSelectedCategory(next);
    controls.current[next]?.focus();
  }

  return (
    <section ref={ref} id="investor-network" aria-labelledby="network-heading" className={styles.section} data-entered={entered}>
      <div className={styles.editorial}>
        <p className={styles.eyebrow}>THE INVESTOR NETWORK</p>
        <h2 id="network-heading">Different kinds of capital. One connected ecosystem.</h2>
        <p className={styles.description}>From early-stage angels to global investment partners, explore the investor network on NxtFund.</p>
        <div className={styles.controls} role="group" aria-label="Investor categories">
          {categories.map((category, index) => (
            <button
              key={category.name}
              ref={(element) => { controls.current[index] = element; }}
              type="button"
              aria-pressed={selectedCategory === index}
              aria-controls="network-details"
              onClick={() => setSelectedCategory(index)}
              onKeyDown={(event) => navigateCategories(event, index)}
            >
              {category.name}
            </button>
          ))}
        </div>
        {/* Overlapping panels reserve the longest category's height at every width. */}
        <div id="network-details" className={styles.details} aria-live="polite" aria-atomic="true">
          {categories.map((category, index) => (
            <div key={category.name} className={styles.detail} data-selected={selectedCategory === index} aria-hidden={selectedCategory !== index}>
              <h3>{category.name}</h3>
              <p>{category.description}</p>
            </div>
          ))}
        </div>
      </div>
      <figure className={styles.figure}>
        <div className={styles.network}>
          <svg viewBox="0 0 600 480" preserveAspectRatio="none" aria-hidden="true" focusable="false" className={styles.connections}>
            {categories.map((category, index) => (
              <path
                key={category.name}
                d={`M300 240 L${category.x * 6} ${category.y * 4.8}`}
                pathLength="1"
                data-selected={selectedCategory === index}
                className={styles.connection}
              />
            ))}
          </svg>
          <div className={styles.center} aria-hidden="true">nxt<span>fund</span></div>
          {categories.map((category, index) => (
            <button
              key={category.name}
              type="button"
              className={styles.node}
              style={{ left: `${category.x}%`, top: `${category.y}%` }}
              aria-pressed={selectedCategory === index}
              aria-controls="network-details"
              onClick={() => setSelectedCategory(index)}
            >
              {category.name}
            </button>
          ))}
        </div>
        <figcaption>Investor categories, not a directory of confirmed members.</figcaption>
      </figure>
    </section>
  );
}
