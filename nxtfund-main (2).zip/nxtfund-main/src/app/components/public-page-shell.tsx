"use client";

import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import PrivateHistoryBoundary from "./private-history-boundary";
import HomeIntro, { IntroReveal } from "./home-intro";

export default function PublicPageShell({ children, footer }: { children: ReactNode; footer: ReactNode }) {
  const pathname = usePathname();

  // The shared footer participates in the homepage intro; other routes remain immediately usable.
  if (pathname !== "/") return <><PrivateHistoryBoundary>{children}</PrivateHistoryBoundary>{footer}</>;

  return (
    <HomeIntro>
      {children}
      <IntroReveal>{footer}</IntroReveal>
    </HomeIntro>
  );
}
