"use client";
import type { ReactNode } from "react";
import { useScrollReveal } from "./use-scroll-reveal";
import styles from "./activity-pages.module.css";

export default function ActivitySection({ id, children }: { id: string; children: ReactNode }) {
  const { ref, entered } = useScrollReveal<HTMLElement>(true);
  return <section id={id} ref={ref} aria-labelledby={`${id}-heading`} className={styles.section} data-entered={entered}>{children}</section>;
}
