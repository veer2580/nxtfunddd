"use client";

import Link from "next/link";
import { isPublicRouteAvailable, registrationRoutes } from "./site-navigation";
import { useScrollReveal } from "./use-scroll-reveal";
import styles from "./home-closing-cta.module.css";

const actions = [
  { label: "Apply for Funding", href: registrationRoutes.startup },
  { label: "Join as an Investor", href: registrationRoutes.investor },
  { label: "Explore TrueValue", href: registrationRoutes.truevalue },
];

export default function HomeClosingCta() {
  const { ref, entered } = useScrollReveal<HTMLElement>();

  return (
    <section ref={ref} id="next-chapter" aria-labelledby="closing-heading" className={styles.section} data-entered={entered}>
      <div className={styles.container}>
        <div className={styles.editorial}>
          <p className={styles.eyebrow}>YOUR NEXT CHAPTER</p>
          <h2 id="closing-heading">Ready to get started?</h2>
          <p className={styles.description}>Bring your startup, investment interests or business opportunity to NxtFund.</p>
          <div className={styles.actions}>
            {actions.map((action) => isPublicRouteAvailable(action.href) ? (
              <Link key={action.href} href={action.href} className={styles.action}>{action.label} <span aria-hidden="true">↗</span></Link>
            ) : (
              <button key={action.href} type="button" aria-disabled="true" aria-describedby="closing-availability" className={styles.action}>
                {action.label}<span className={styles.status}>Unavailable</span>
              </button>
            ))}
          </div>
          <p id="closing-availability" className={styles.availability}>Startup and investor forms are available for preparation. Submissions and transactions are currently unavailable.</p>
          <Link className={styles.alternative} href="/#process">Review how it works <span aria-hidden="true">↗</span></Link>
        </div>
        <figure className={styles.visual}>
          <svg viewBox="0 0 540 380" role="img" aria-labelledby="closing-visual-title closing-visual-description">
            <title id="closing-visual-title">Ideas, capital and business ownership connect</title>
            <desc id="closing-visual-description">Three illustrated pathways join in a shared direction. This is a concept illustration.</desc>
            <g fill="none" stroke="var(--ink)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M57 106H178V190H481M57 190H481M57 276H178V190" />
              <path d="m460 168 21 22-21 22" stroke="var(--brand)" strokeWidth="3" />
              <circle cx="98" cy="88" r="53" fill="var(--accent-yellow)" stroke="none" />
              <path d="M84 107v-9c-23-18-8-43 11-43s34 25 11 43v9ZM85 115h20M89 122h12" fill="var(--surface)" />
              <rect x="54" y="158" width="118" height="64" fill="var(--surface)" />
              <path d="M79 198v-14h16v14m14 0v-26h16v26m14 0v-34h16v34" stroke="var(--brand)" />
              <path d="M51 255h128v61H51ZM76 255v-15h77v15M51 276h128M105 276v13h21v-13" fill="var(--accent-mint)" />
              <circle cx="298" cy="190" r="27" fill="var(--surface)" />
              <path d="m288 190 7 7 14-15" stroke="var(--brand)" strokeWidth="3" />
            </g>
            <g fill="var(--ink)" fontFamily="inherit" fontSize="25">
              <text x="199" y="72">Ideas</text>
              <text x="199" y="167">Capital</text>
              <text x="199" y="301">Business ownership</text>
            </g>
          </svg>
        </figure>
      </div>
    </section>
  );
}
