export const registrationRoutes = {
  startup: "/startup-registration",
  investor: "/investor-registration",
  truevalue: "/truevalue",
} as const;

export type NavigationItem = {
  label: string;
  href: string;
  children?: { label: string; href: string }[];
};

export const navigation: NavigationItem[] = [
  {
    label: "About Us",
    href: "/about-us",
  },
  {
    label: "Startups",
    href: "/startups",
    children: [
      { label: "Startup overview", href: "/startups" },
      { label: "Startup Registration", href: registrationRoutes.startup },
    ],
  },
  {
    label: "Investors",
    href: "/investors",
    children: [
      { label: "Investor overview", href: "/investors" },
      { label: "Investor Registration", href: registrationRoutes.investor },
    ],
  },
  {
    label: "Due Diligence",
    href: "/due-diligence",
  },
  {
    label: "TrueValue",
    href: registrationRoutes.truevalue,
    children: [
      { label: "Explore TrueValue", href: registrationRoutes.truevalue },
      {
        label: "List Your Business",
        href: "/truevalue/list-your-business",
      },
    ],
  },
  {
    label: "Ecosystem",
    href: "/ecosystem",
    children: [
      { label: "Ecosystem overview", href: "/ecosystem" },
      { label: "Partners", href: "/partners" },
      { label: "Become a Partner", href: "/become-a-partner" },
      { label: "Investor Brief", href: "/investor-brief" },
      { label: "Portfolio", href: "/portfolio" },
      { label: "Events", href: "/events" },
      { label: "Gallery", href: "/gallery" },
    ],
  },
  {
    label: "Contact Us",
    href: "/contact-us",
  },
];

// Route availability stays explicit until the destination pages are implemented.
const availablePublicRoutes = new Set(["/", "/terms-and-conditions", "/privacy-policy", "/investor-brief", "/portfolio", "/about-us", "/startups", "/startup-registration", "/investors", "/investor-registration", "/due-diligence", "/truevalue", "/truevalue/list-your-business", "/ecosystem", "/partners", "/become-a-partner", "/events", "/gallery", "/contact-us", "/login", "/account/investor-registration", "/review/investor-registrations", "/app/investor", "/app/investor/startups", "/app/investor/interests", "/onboarding/investor", "/ops/reviews"]);

export function isPublicRouteAvailable(href: string) {
  return availablePublicRoutes.has(href.split(/[?#]/)[0]);
}

export function getPublicDestination(href: string) {
  return isPublicRouteAvailable(href) ? href : undefined;
}

