type IllustrationKind = "startup" | "investors" | "diligence" | "grants" | "truevalue" | "capital";

// Concept diagrams explain the pathways without implying real deals or participants.
export default function OpportunityIllustration({ kind }: { kind: IllustrationKind }) {
  return (
    <svg viewBox="0 0 480 320" fill="none" aria-hidden="true" focusable="false" style={{ display: "block", width: "100%", height: "100%" }}>
      <g stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        {kind === "startup" && <>
          <path d="M40 262H438" opacity=".25" />
          <rect x="64" y="58" width="208" height="206" rx="4" fill="var(--surface)" />
          <path d="M90 89H183M90 110H225M90 131H157" />
          <path d="M91 229V181H124V229M147 229V157H180V229M204 229V139H237V229" fill="var(--accent-yellow)" />
          <circle cx="328" cy="113" r="48" fill="var(--accent-mint)" />
          <path d="m306 112 16 16 29-30" stroke="var(--brand)" strokeWidth="4" />
          <path d="M272 208H332V171m-8 9 8-9 8 9" />
          <path d="M350 244V194H414V244M369 194V182H395V194" fill="var(--surface)" />
        </>}
        {kind === "investors" && <>
          <circle cx="240" cy="160" r="112" strokeDasharray="4 9" opacity=".35" />
          <path d="M240 160 105 83M240 160 376 80M240 160 389 235M240 160 101 239M240 160V40M240 160V280" />
          <circle cx="240" cy="160" r="49" fill="var(--surface)" />
          <path d="M217 181V150H263V181M226 150V136H254V150" stroke="var(--brand)" />
          {[ [105,83], [376,80], [389,235], [101,239], [240,40], [240,280] ].map(([x,y],index)=><circle key={index} cx={x} cy={y} r="21" fill={index%2 ? "var(--accent-mint)" : "var(--accent-yellow)"} />)}
        </>}
        {kind === "diligence" && <>
          <rect x="112" y="39" width="186" height="244" rx="4" fill="var(--surface)" />
          <path d="M138 73H249M138 93H219M164 134H252M164 174H238M164 214H218" />
          <path d="m136 130 6 6 11-13m-17 47 6 6 11-13m-17 47 6 6 11-13" stroke="var(--brand)" strokeWidth="3" />
          <circle cx="304" cy="201" r="54" fill="var(--accent-mint)" />
          <circle cx="304" cy="201" r="34" />
          <path d="m343 241 49 49M288 201l11 11 23-24" strokeWidth="4" />
        </>}
        {kind === "grants" && <>
          <path d="M70 263H412M127 257V165H277V257M144 165V137H260V165" fill="var(--surface)" />
          <path d="M164 259V212H205V259M235 190V206M151 190V206" />
          <path d="M310 264V103M310 165c-51 0-72-31-72-61 50 0 72 29 72 61ZM310 129c0-44 32-70 64-70 0 45-30 70-64 70Z" fill="var(--accent-mint)" />
          <circle cx="150" cy="76" r="31" fill="var(--accent-yellow)" />
          <path d="M140 76h20m-10-10v20" stroke="var(--brand)" strokeWidth="3" />
        </>}
        {kind === "truevalue" && <>
          <rect x="55" y="96" width="154" height="137" fill="var(--surface)" />
          <path d="M55 96 76 62H188L209 96M82 233V157H122V233M146 139H180V174H146Z" />
          <rect x="291" y="124" width="132" height="109" fill="var(--accent-yellow)" />
          <path d="M322 124V102H390V124M291 160H423M343 160V177H371V160" />
          <path d="M222 118H275m-12-12 12 12-12 12M275 212H222m12-12-12 12 12 12" stroke="var(--brand)" strokeWidth="3" />
          <path d="M46 261H434" opacity=".3" />
        </>}
        {kind === "capital" && <>
          <rect x="41" y="110" width="102" height="102" rx="51" />
          <path d="M67 155H117M67 170H102M155 161H206m-10-10 10 10-10 10" />
          <rect x="222" y="70" width="203" height="186" rx="4" />
          <path d="M250 109H398M250 151H398M250 195H398" opacity=".4" />
          <circle cx="265" cy="109" r="7" fill="var(--accent-yellow)" />
          <circle cx="265" cy="151" r="7" fill="var(--accent-mint)" />
          <circle cx="265" cy="195" r="7" fill="var(--accent-blue)" />
        </>}
      </g>
    </svg>
  );
}
