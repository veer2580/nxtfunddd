"use client";
import SiteHeader from "./site-header";
import SiteLink from "./site-link";
import styles from "./activity-pages.module.css";

export default function ActivityError({ pageName, retry }: { pageName: "Events" | "Gallery"; retry: () => void }) {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page} ${styles.fallback}`}><div className={styles.container}>
    <h1>{pageName} is temporarily unavailable.</h1><p>The page could not be opened. Try again or explore the ecosystem.</p>
    <div className={styles.actions}><button type="button" className={styles.primaryAction} onClick={retry}>Try again</button><SiteLink href="/ecosystem" className={styles.textAction}>Explore the ecosystem</SiteLink></div>
  </div></main></>;
}
