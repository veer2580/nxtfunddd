export default function ActivityVisual({ kind }: { kind: "conversation" | "upcoming" | "past" | "gallery" }) {
  return <svg viewBox="0 0 500 340" aria-hidden="true">
    {kind === "conversation" ? <>
      <path d="M50 66H268V190H144L95 231V190H50Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M237 151H452V272H374L331 310V272H237Z" fill="var(--accent-mint)" stroke="currentColor" strokeWidth="2" />
      <path d="M85 108H229M85 144H198M272 194H413M272 230H378" stroke="currentColor" strokeWidth="2" />
      <circle cx="366" cy="73" r="35" fill="var(--accent-yellow)" /><path d="M366 53V93M346 73H386" stroke="var(--brand)" strokeWidth="2" />
    </> : kind === "upcoming" ? <>
      <path d="M250 62C229 62 218 77 218 96V168C218 210 282 210 282 168V96C282 77 271 62 250 62Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M191 143V167C191 245 309 245 309 167V143M250 229V283M208 283H292" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M218 116H242M258 116H282M218 145H242M258 145H282M218 174H242M258 174H282" stroke="currentColor" />
      <path d="M146 105L113 82M139 148H99M353 106L386 83M361 148H401" stroke="var(--brand)" strokeWidth="3" />
    </> : kind === "past" ? <>
      <path d="M103 96H397V279H103Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M83 61H417V113H83Z" fill="var(--accent-mint)" stroke="currentColor" strokeWidth="2" />
      <path d="M185 152H315V177H185Z" fill="var(--surface-yellow)" stroke="currentColor" />
      <path d="M154 221H346M154 242H297" stroke="currentColor" strokeWidth="2" />
      <path d="M117 300H385" stroke="var(--brand)" strokeWidth="2" />
    </> : <>
      <path d="M101 77H397V267H101Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M132 107H365V237H132Z" fill="var(--surface-blue)" stroke="currentColor" />
      <path d="M132 237L201 168L262 220L317 182L365 237" fill="var(--accent-mint)" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="310" cy="138" r="15" fill="var(--accent-yellow)" />
      <path d="M76 101H58V297H359V285M119 53H422V245H412" fill="none" stroke="var(--brand)" strokeWidth="2" />
    </>}
  </svg>;
}
