"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AccountAuth, { type AccountIdentity } from "./account-auth";
import SiteLink from "./site-link";
import styles from "./registration.module.css";

export default function AccountPage() {
  const router = useRouter();
  const [enabled, setEnabled] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [account, setAccount] = useState<AccountIdentity | null>(null);
  const [error, setError] = useState("");
  const [signingOut, setSigningOut] = useState(false);
  useEffect(() => { fetch("/api/auth/session").then(response => response.json()).then(result => { setEnabled(Boolean(result.enabled)); setAccount(result.account); setLoaded(true); }).catch(() => { setLoaded(true); setError("Unable to load account access. Reload to retry."); }); }, []);
  async function logout() {
    if (signingOut) return;
    setSigningOut(true); setError("");
    try {
      const response = await fetch("/api/auth/session", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "logout" }) });
      if (!response.ok) throw new Error();
      setAccount(null); window.location.replace("/login");
    } catch { setError("Unable to sign out. Try again."); }
    finally { setSigningOut(false); }
  }
  return <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}><div className={styles.container}><div className={styles.introduction}><p className={styles.eyebrow}>ACCOUNT ACCESS</p><h1>Your NxtFund account</h1></div>
    {!loaded ? <p role="status">Checking account access…</p> : !enabled ? <p>Account access is currently unavailable. You can still prepare your investor registration.</p> : account ? <><p>Signed in as {account.email}.</p><div className={styles.actions}><SiteLink href="/app/investor" className={styles.secondary}>Investor workspace</SiteLink>{account.reviewer && <SiteLink href="/review/investor-registrations" className={styles.secondary}>Investor review queue</SiteLink>}<button disabled={signingOut} className={styles.secondary} onClick={logout}>{signingOut ? "Signing out…" : "Sign out"}</button></div></> : <AccountAuth onAuthenticated={(_, destination) => router.push(destination)} returnTo={typeof window === "undefined" ? undefined : new URLSearchParams(window.location.search).get("returnTo") ?? undefined} />}
    {error && <p role="alert">{error}</p>}<SiteLink href="/investor-registration">Prepare investor registration</SiteLink>
  </div></main>;
}
