import type { Block, LegalSection } from "../../lib/legal/content";
import styles from "./legal-document.module.css";

function renderBlock(block: Block, key: number) {
  if (typeof block === "string") return <p key={key}>{block}</p>;
  if (Array.isArray(block)) return <ul key={key}>{block.map((item) => <li key={item}>{item}</li>)}</ul>;
  return <h3 key={key}>{block.h}</h3>;
}

export function LegalContact() {
  return (
    <address className={styles.contact}>
      <strong>NXTFUND</strong>
      <span>An initiative of Celebso Group</span>
      <span>Operated by Celebso Technologies</span>
      <span>Jaipur, Rajasthan, India</span>
      <span>Email: <a href="mailto:celebso54@gmail.com">celebso54@gmail.com</a></span>
      <span>Website: <a href="https://www.nxtfund.in">www.nxtfund.in</a></span>
    </address>
  );
}

export function LegalSections({ sections, prefix, contactTitle }: { sections: LegalSection[]; prefix: string; contactTitle: string }) {
  return (
    <>
      {sections.map((section, index) => {
        const number = String(index + 1).padStart(2, "0");
        return (
          <section key={section.title} id={`${prefix}-${index + 1}`} className={styles.section} aria-labelledby={`${prefix}-${index + 1}-title`}>
            <span className={styles.number} aria-hidden="true">{number}</span>
            <h2 id={`${prefix}-${index + 1}-title`}>{section.title}</h2>
            {section.blocks.map(renderBlock)}
            {section.title === contactTitle && <LegalContact />}
          </section>
        );
      })}
    </>
  );
}

export function LegalToc({ title, sections, prefix }: { title: string; sections: LegalSection[]; prefix: string }) {
  return (
    <nav className={styles.toc} aria-label={title}>
      <h2>{title}</h2>
      <ol>
        {sections.map((section, index) => (
          <li key={section.title}><a href={`#${prefix}-${index + 1}`}>{section.title}</a></li>
        ))}
      </ol>
    </nav>
  );
}
