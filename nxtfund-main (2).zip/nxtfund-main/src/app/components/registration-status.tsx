"use client";
import { investorCategoryOptions, registrationTypeOptions } from "@/lib/investor-registration/validation";
import { investorFieldLabels, investorRoleStatement } from "@/lib/investor-registration/content";
import EmailVerification from "./email-verification";
import { useCallback, useEffect, useState } from "react";
import SiteLink from "./site-link";
import styles from "./registration.module.css";
import statusStyles from "./registration-status.module.css";

type StatusData = { registration: { reference: string; status: string; createdAt: string; statusCode: string; fields: Record<string,string> }; messages: { message: string; createdAt: string }[] };
const explanations: Record<string, string> = {
  pending_review: "Your registration has been received and is awaiting review. No action is needed from you right now.",
  in_review: "Your registration is being reviewed. Check here for updates or requests for more information.",
  needs_information: "Changes have been requested. Read the review message below and update your registration before submitting it again.",
  approved: "Your investor profile has been approved. Explore the available investor pathways from your workspace.",
  rejected: "Your registration was not approved. Read the review message below for more information.",
  suspended: "Your investor access is suspended. Read the review message below for more information.",
};
function displayValue(key: string, value: string) {
  if (key === "investorCategory") return value.split(",").map(category => investorCategoryOptions.find(option => option.value === category)?.label ?? category).join(", ");
  if (key === "registeringAs") return registrationTypeOptions.find(option => option.value === value)?.label ?? value;
  if (["minimumInvestment", "maximumInvestment"].includes(key)) return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(Number(value));
  return value;
}
export default function RegistrationStatus({ workspace = false }: { workspace?: boolean }) {
  const [emailVerified, setEmailVerified] = useState<boolean | null>(null);
  const [data, setData] = useState<StatusData | null>(null);
  const [draftMessage, setDraftMessage] = useState("");
  const [testEnvironment, setTestEnvironment] = useState(false);
  const [pending, setPending] = useState(true);
  const [error, setError] = useState("");
  const load = useCallback(() => fetch("/api/investor-registrations", { cache: "no-store" }).then(async response => {
      const result = await response.json();
      setError("");
      if (response.status === 404) {
        setData(null);
        const draftResponse = await fetch("/api/investor-registrations/draft", { cache: "no-store" });
        const draft = await draftResponse.json();
        if (!draftResponse.ok) throw new Error(draft.message);
        setDraftMessage(draft.draft?.savedAt ? "Your saved draft is ready to continue." : "Prepare your investor profile, verify your email and submit for review.");
      } else {
        if (!response.ok) throw new Error(result.message);
        setDraftMessage(""); setData(result);
      }
    }).catch(error => { setData(null); setDraftMessage(""); setError(error instanceof Error ? error.message : "Unable to load your registration. Try again."); })
      .finally(() => setPending(false)), []);
  useEffect(() => {
    void load();
    fetch("/api/auth/session", { cache: "no-store" }).then(response => response.json()).then(result => { setEmailVerified(result.account?.emailVerified ?? null); setTestEnvironment(Boolean(result.enabled)); }).catch(() => setError("Unable to check account verification. Refresh to retry."));
  }, [load]);
  const registration = data?.registration;
  const groups = [
    { title: "Profile", keys: ["fullName", "email", "phone", "registeringAs", "organisationName", "investorCategory"] },
    { title: "Investment preferences", keys: ["sectors", "stages", "minimumInvestment", "maximumInvestment"] },
  ];
  return <div className={workspace ? undefined : `page-surface ${styles.page}`}><div className={workspace ? undefined : styles.container}>
    <h1>{workspace ? "Investor overview" : "Your registration status"}</h1>
    {testEnvironment && <p className={styles.hint} role="note">Test environment</p>}
    {pending ? <p role="status">Loading your registration…</p> : error ? <p role="alert">{error}</p> : registration ? <>
      <section className={statusStyles.summary} aria-labelledby="registration-status-heading">
        <p className={styles.eyebrow}>REGISTRATION STATUS</p><h2 id="registration-status-heading">{registration.status}</h2>
        <p>{explanations[registration.statusCode] ?? "Check your registration status and any review messages below."}</p>
        <dl className={statusStyles.details}><div><dt>Submission reference</dt><dd>{registration.reference}</dd></div><div><dt>Submitted date</dt><dd><time dateTime={registration.createdAt}>{new Date(registration.createdAt.replace(" ", "T") + (registration.createdAt.includes("Z") ? "" : "Z")).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric", timeZone: "Asia/Kolkata" })}</time></dd></div></dl>
        {data?.messages.map((message, index) => <div key={index}><h3>Review message</h3><p>{message.message}</p></div>)}
        {registration.statusCode === "needs_information" && <SiteLink href="/investor-registration" className={styles.primary}>Make requested changes</SiteLink>}
        {registration.statusCode === "approved" && <SiteLink href="/app/investor/startups" className={styles.secondary}>Explore startup availability</SiteLink>}
      </section>
      <section aria-labelledby="submitted-profile-heading"><h2 id="submitted-profile-heading">Submitted profile — read-only</h2>
        {groups.map(group => <div className={statusStyles.group} key={group.title}><h3>{group.title}</h3><dl className={statusStyles.details}>{group.keys.filter(key => registration.fields[key]?.trim() && (key !== "organisationName" || registration.fields.registeringAs === "organisation")).map(key => <div key={key}><dt>{investorFieldLabels[key as keyof typeof investorFieldLabels]}</dt><dd>{displayValue(key, registration.fields[key])}</dd></div>)}</dl></div>)}
        <p className={styles.hint}>Investment ranges describe preferences, not committed capital. Your profile is not publicly published.</p>
      </section><p>{investorRoleStatement}</p>
    </> : <><p>{draftMessage}</p>{emailVerified === false && <EmailVerification onVerified={() => setEmailVerified(true)} />}<SiteLink href="/investor-registration" className={styles.primary}>Continue registration</SiteLink></>}
    <div className={styles.actions}><button disabled={pending} onClick={() => { setPending(true); setError(""); void load(); }} className={styles.secondary}>Refresh status</button><SiteLink href="/login" className={styles.secondary}>Account access</SiteLink></div>
  </div></div>;
}
