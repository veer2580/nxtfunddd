"use client";

import { useState } from "react";
import styles from "./registration.module.css";

export type AccountIdentity = { id: string; email: string; reviewer: boolean; emailVerified: boolean };
export default function AccountAuth({ onAuthenticated, returnTo }: { onAuthenticated: (account: AccountIdentity, destination: string) => void; returnTo?: string }) {
  const [create, setCreate] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  async function authenticate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending) return;
    setPending(true); setError("");
    try {
      const response = await fetch("/api/auth/session", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: create ? "create" : "login", email, password, returnTo }) });
      const result = await response.json();
      if (!response.ok) { setError(result.message ?? "Unable to sign in. Try again."); return; }
      setPassword(""); onAuthenticated(result.account, result.returnTo);
    } catch { setError("Unable to connect. Your registration entries have been kept; try again."); }
    finally { setPending(false); }
  }
  return <section aria-labelledby="account-auth-heading">
    <h2 id="account-auth-heading">{create ? "Create your account" : "Sign in to continue"}</h2>
    <p>Sign in to save your progress and view your registration status.</p>
    <form onSubmit={authenticate} className={styles.form}>
      <div className={styles.field}><label htmlFor="auth-email">Account email</label><input id="auth-email" type="email" autoComplete="email" required maxLength={254} value={email} onChange={event => setEmail(event.target.value)} /></div>
      <div className={styles.field}><label htmlFor="auth-password">Password</label><input id="auth-password" type="password" autoComplete={create ? "new-password" : "current-password"} required minLength={create ? 15 : 12} maxLength={128} aria-describedby="auth-password-hint" value={password} onChange={event => setPassword(event.target.value)} /><p id="auth-password-hint" className={styles.hint}>Use 15–128 characters for a new account.</p></div>
      {error && <p role="alert" className={styles.error}>{error}</p>}
      <div className={styles.actions}><button type="submit" disabled={pending} className={styles.primary}>{pending ? "Signing in…" : create ? "Create account" : "Sign in"}</button><button type="button" disabled={pending} className={styles.secondary} onClick={() => { setCreate(!create); setError(""); }}>{create ? "Use an existing account" : "Create an account"}</button></div>
    </form>
  </section>;
}
