import SiteLink from "./site-link";
import { navigation, getPublicDestination } from "./site-navigation";
import styles from "./site-footer.module.css";

const ecosystem = navigation.find((item) => item.label === "Ecosystem")!;
const groups = [
  { name: "Explore", items: navigation.filter((item) => ["About Us", "Startups", "Investors", "Due Diligence", "TrueValue"].includes(item.label)) },
  { name: "Ecosystem", items: [ecosystem, ...ecosystem.children!.filter((item) => ["Investor Brief", "Portfolio", "Partners", "Events", "Gallery"].includes(item.label))] },
  { name: "Connect", items: navigation.filter((item) => item.label === "Contact Us") },
  { name: "Legal", items: [
    { label: "Terms & Conditions", href: "/terms-and-conditions" },
    { label: "Privacy Policy", href: "/privacy-policy" },
  ] },
];

export default function SiteFooter() {
  return (
    <footer className={styles.footer}>
      <div className={styles.container}>
        <div className={styles.top}>
          <div className={styles.brand}>
            <SiteLink className={styles.logo} href="/" aria-label="NxtFund home">nxt<span>fund</span></SiteLink>
            <p>Connecting startups, investors and business opportunities.</p>
            <p className={styles.company}>Developed and operated by Markifid Infotech Private Limited.</p>
            <p><a href="mailto:startup.nxtfund@gmail.com">startup.nxtfund@gmail.com</a> · <a href="tel:+919784626443">9784626443</a></p>
            <p>Jaipur, India – 302015</p>
          </div>
          <nav aria-label="Footer navigation" className={styles.navigation}>
            {groups.map((group) => (
              <div key={group.name}>
                <h2>{group.name}</h2>
                <ul>
                  {group.items.map((item) => (
                    <li key={item.href}>
                      <SiteLink href={item.href}>
                        {item.label}{!getPublicDestination(item.href) && <small>Page unavailable</small>}
                      </SiteLink>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>
        <div className={styles.bottom}>
          <p>NxtFund facilitates verification and introductions. Investment and sale agreements are made directly between the parties involved.</p>
          <p>© {new Date().getFullYear()} Markifid Infotech Private Limited.</p>
        </div>
      </div>
    </footer>
  );
}
