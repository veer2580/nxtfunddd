"use client";

import SiteLink from "./site-link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import styles from "./site-header.module.css";

import { navigation, getPublicDestination, type NavigationItem } from "./site-navigation";

export default function SiteHeader() {
  const pathname = usePathname();
  const [signedIn, setSignedIn] = useState(false);
  useEffect(() => { let cancelled = false; fetch("/api/auth/session", { cache: "no-store" }).then(response => response.json()).then(result => { if (!cancelled) setSignedIn(Boolean(result.account)); }).catch(() => {}); return () => { cancelled = true; }; }, [pathname]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const header = useRef<HTMLElement>(null);

  useEffect(() => {
    function dismissOutside(event: PointerEvent) {
      if (event.target instanceof Node && !header.current?.contains(event.target)) {
        setMobileOpen(false);
        setOpenDropdown(null);
      }
    }
    document.addEventListener("pointerdown", dismissOutside);
    return () => document.removeEventListener("pointerdown", dismissOutside);
  }, []);

  const menuButton = useRef<HTMLButtonElement>(null);
  const dropdownButtons = useRef<
    Record<string, HTMLButtonElement | null>
  >({});

  function closeMenus() {
    setMobileOpen(false);
    setOpenDropdown(null);
    header.current?.querySelectorAll("details[open]").forEach((group) => {
      group.removeAttribute("open");
    });
  }

  function isActive(item: NavigationItem) {
    return (
      pathname === item.href ||
      pathname.startsWith(`${item.href}/`) ||
      item.children?.some((child) => pathname === child.href)
    );
  }

  function renderLink(href: string, label: string) {
    return (
      <SiteLink href={href} onClick={closeMenus}
        aria-current={pathname === href ? "page" : undefined}
        className={styles.link}>
        {label}{!getPublicDestination(href) && <small className={styles.unavailableText}>Page unavailable</small>}
      </SiteLink>
    );
  }

  return (
    <header
      ref={header}
      className={styles.header}
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) closeMenus();
      }}
      onKeyDown={(event) => {
        if (event.key !== "Escape") return;
        if (openDropdown) {
          dropdownButtons.current[openDropdown]?.focus();
          setOpenDropdown(null);
        } else if (mobileOpen) {
          setMobileOpen(false);
          menuButton.current?.focus();
        }
      }}
    >
      <a href="#main-content" className={styles.skipLink}>Skip to content</a>
      <div className={styles.bar}>
        <SiteLink href="/" aria-label="NxtFund home" onClick={closeMenus} className={styles.logo}>
          nxt<span>fund</span>
        </SiteLink>
        <nav aria-label="Main navigation" className={styles.desktopNav}>
          {navigation.map((item) => {
            const expanded = openDropdown === item.label;
            const menuId = `desktop-${item.href.slice(1)}`;
            return (
              <div key={item.href} className={styles.navItem} data-active={isActive(item) || undefined}>
                <div className={styles.navLabel}>
                  {renderLink(item.href, item.label)}
                  {item.children && (
                    <button
                      ref={(element) => { dropdownButtons.current[item.label] = element; }}
                      type="button" aria-label={`${item.label} subpages`}
                      aria-expanded={expanded} aria-controls={menuId}
                      onClick={() => setOpenDropdown(expanded ? null : item.label)}
                      onKeyDown={(event) => {
                        if (event.key !== "ArrowDown") return;
                        event.preventDefault();
                        setOpenDropdown(item.label);
                        requestAnimationFrame(() => document.getElementById(menuId)?.querySelector<HTMLAnchorElement>("a")?.focus());
                      }}
                      className={styles.dropdownButton}
                    >
                      <svg aria-hidden="true" viewBox="0 0 20 20" fill="none">
                        <path d="m5 7.5 5 5 5-5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </button>
                  )}
                </div>
                {item.children && (
                  <div id={menuId} hidden={!expanded} className={styles.dropdown}
                    onKeyDown={(event) => {
                      if (!["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) return;
                      const links = [...event.currentTarget.querySelectorAll<HTMLAnchorElement>("a")];
                      if (!links.length) return;
                      event.preventDefault();
                      const index = links.indexOf(document.activeElement as HTMLAnchorElement);
                      const next = event.key === "Home" ? 0 : event.key === "End" ? links.length - 1 : (index + (event.key === "ArrowDown" ? 1 : -1) + links.length) % links.length;
                      links[next].focus();
                    }}>
                    {item.children.map((child) => (
                      <div key={child.href}>{renderLink(child.href, child.label)}</div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>
        <button
          ref={menuButton} type="button" aria-expanded={mobileOpen}
          aria-controls="mobile-navigation"
          onClick={() => setMobileOpen(!mobileOpen)} className={styles.menuButton}
        >
          {mobileOpen ? "Close" : "Menu"}
          <span aria-hidden="true">{mobileOpen ? "×" : "☰"}</span>
        </button>
        
        <SiteLink href={signedIn ? "/app/investor" : "/login"} onClick={closeMenus} className={styles.accountLink}>{signedIn ? "My workspace" : "Login"}</SiteLink>
      </div>
      <nav id="mobile-navigation" aria-label="Mobile navigation" hidden={!mobileOpen} className={styles.mobileNav}>
        {navigation.map((item) => item.children ? (
          <details key={item.href} className={styles.mobileGroup} data-active={isActive(item) || undefined}>
            <summary>{item.label}</summary>
            <div className={styles.mobileChildren}>
              {item.children.map((child) => (
                <div key={child.href}>{renderLink(child.href, child.label)}</div>
              ))}
            </div>
          </details>
        ) : (
          <div key={item.href}>{renderLink(item.href, item.label)}</div>
        ))}
      </nav>
    </header>
  );
}
