"use client";

import { useRef, useState, type KeyboardEvent } from "react";
import SiteLink from "./site-link";
import { useScrollReveal } from "./use-scroll-reveal";
import styles from "./home-truevalue.module.css";

const pathways = [
  {
    id: "sellers",
    label: "For Sellers",
    title: "Introduce your next opportunity.",
    description: "Present what you want to sell. The intended process keeps identifying details out of public previews and shares fuller information after review and access approval.",
  },
  {
    id: "buyers",
    label: "For Buyers",
    title: "Discover what comes next.",
    description: "Explore opportunities by sector and ownership type. The intended process requires verification and seller approval before access to further details.",
  },
] as const;

function TrueValueIllustration({ pathway }: { pathway: "sellers" | "buyers" }) {
  return (
    <svg className={styles.illustration} data-pathway={pathway} viewBox="0 0 560 420" role="img" aria-labelledby="truevalue-visual-title truevalue-visual-description">
      <title id="truevalue-visual-title">Four types of opportunity</title>
      <desc id="truevalue-visual-description">Business, Product, IP and Ownership stake. These are categories, not example listings.</desc>
      <g fill="none" stroke="var(--ink)" strokeWidth="2" strokeLinejoin="round">
        <path d="M26 231H534M275 28V393" opacity=".18" />
        <circle cx="411" cy="105" r="75" fill="var(--accent-mint)" stroke="none" />
        <path d="M33 266H219V352H33Z" fill="var(--accent-yellow)" stroke="none" />
        <g className={styles.business}>
          <path d="M48 93 67 53H207L226 93V183H48Z" fill="var(--surface)" />
          <path d="M48 93H226M66 93V111H92V93M111 93V111H137V93M156 93V111H182V93M201 93V111H226M73 183V136H115V183M147 130H198V157H147Z" />
        </g>
        <g className={styles.product}>
          <path d="m359 71 54-27 54 27v72l-54 27-54-27Z" fill="var(--surface)" />
          <path d="m359 71 54 27 54-27M413 98V170M387 58l54 27v25" />
        </g>
        <g className={styles.stake}>
          <circle cx="127" cy="302" r="44" fill="var(--surface)" />
          <path d="M127 258V302H171A44 44 0 0 0 127 258Z" fill="var(--accent-blue)" />
          <path d="M96 333 127 302" />
        </g>
        <g className={styles.ip}>
          <path d="M360 257H435L464 286V338H360Z" fill="var(--surface)" />
          <path d="M435 257V286H464M380 303H433M380 319H413" />
          <circle cx="343" cy="275" r="21" fill="var(--accent-yellow)" />
          <path d="M349 269a8 8 0 1 0 0 12" />
        </g>
        <g className={styles.direction} stroke="var(--brand)" strokeWidth="3">
          <path d="M239 211H318m-12-12 12 12-12 12" />
        </g>
      </g>
      <g fill="var(--ink)" fontSize="28" fontFamily="inherit" letterSpacing="-0.5">
        <text x="48" y="218">Business</text>
        <text x="356" y="210">Product</text>
        <text x="33" y="388">Ownership stake</text>
        <text x="394" y="388">IP</text>
      </g>
    </svg>
  );
}

export default function HomeTrueValue() {
  const { ref, entered } = useScrollReveal<HTMLElement>();
  const [selectedTab, setSelectedTab] = useState(0);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);

  function navigateTabs(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next: number;
    switch (event.key) {
      case "ArrowRight": next = (index + 1) % pathways.length; break;
      case "ArrowLeft": next = (index + pathways.length - 1) % pathways.length; break;
      case "Home": next = 0; break;
      case "End": next = pathways.length - 1; break;
      default: return;
    }
    event.preventDefault();
    setSelectedTab(next);
    tabs.current[next]?.focus();
  }

  return (
    <section ref={ref} id="truevalue" className={styles.section} aria-labelledby="truevalue-heading" data-entered={entered}>
      <div className={styles.container}>
        <div className={styles.introduction}>
          <p className={styles.eyebrow}>TRUEVALUE</p>
          <h2 id="truevalue-heading">A new chapter for what you’ve built.</h2>
          <p className={styles.description}>Explore a dedicated pathway to sell or acquire a business, product, intellectual property or ownership stake.</p>
        </div>
        <div className={styles.showcase}>
          <figure className={styles.visual}>
            <div className={styles.mask}><TrueValueIllustration pathway={pathways[selectedTab].id} /></div>
          </figure>
          <div>
            <div role="tablist" aria-label="Choose your TrueValue pathway" className={styles.tabs}>
              {pathways.map((pathway, index) => (
                <button
                  key={pathway.id}
                  ref={(element) => { tabs.current[index] = element; }}
                  type="button"
                  role="tab"
                  id={`truevalue-tab-${pathway.id}`}
                  aria-controls={`truevalue-panel-${pathway.id}`}
                  aria-selected={selectedTab === index}
                  tabIndex={selectedTab === index ? 0 : -1}
                  onClick={() => setSelectedTab(index)}
                  onKeyDown={(event) => navigateTabs(event, index)}
                >
                  {pathway.label}
                </button>
              ))}
            </div>
            {/* Both panels participate in sizing so changing pathways cannot move the section below. */}
            <div className={styles.panels}>
              {pathways.map((pathway, index) => (
                <div
                  key={pathway.id}
                  role="tabpanel"
                  id={`truevalue-panel-${pathway.id}`}
                  aria-labelledby={`truevalue-tab-${pathway.id}`}
                  aria-hidden={selectedTab !== index}
                  inert={selectedTab !== index}
                  tabIndex={selectedTab === index ? 0 : -1}
                  className={styles.panel}
                  data-active={selectedTab === index}
                >
                  <h3>{pathway.title}</h3>
                  <p>{pathway.description}</p>
                </div>
              ))}
            </div>
            <p className={styles.availability}>Buying and selling are currently unavailable.</p>
            <SiteLink href="/truevalue" className={styles.action}>Explore TrueValue <span aria-hidden="true">↗</span></SiteLink>
          </div>
        </div>
      </div>
    </section>
  );
}
