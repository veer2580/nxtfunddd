import { getStore } from "@/lib/backend/local-store.mjs";
import { investorPageAccount } from "@/lib/backend/investor-page";
import { requireApprovedInvestor } from "@/lib/backend/investor-persistence.mjs";
import SiteLink from "./site-link";
export default async function InvestorAccessState({ view }: { view: "startups" | "interests" }) {
  const account = await investorPageAccount(`/app/investor/${view}`);
  if (!account) return null;
  let eligible = false;
  try { requireApprovedInvestor(getStore(), account); eligible = true; }
  catch (error) { if (![401,403,503].includes((error as { status: number }).status)) throw error; }
  return <><h1>{view === "startups" ? "Browse startups" : "My interests"}</h1><p>{eligible ? view === "startups" ? "Startup discovery is not connected yet. No private opportunities are currently available here." : "Introduction requests are not connected yet. No interest submissions can be made here." : "Verified email and manual investor approval are required before accessing this area."}</p><SiteLink href="/app/investor">See your investor overview</SiteLink></>;
}
