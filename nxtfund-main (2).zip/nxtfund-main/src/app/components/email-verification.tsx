"use client";
import { useState } from "react";
import styles from "./registration.module.css";
export default function EmailVerification({ onVerified }: { onVerified: () => void }) {
  const [code, setCode] = useState("");
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  async function action(type: "send" | "verify") {
    if (pending) return;
    setPending(true); setError(""); setMessage("");
    try {
      const response = await fetch("/api/auth/verification", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: type, code }) });
      const result = await response.json();
      if (!response.ok) { setError(result.message ?? "Unable to verify. Try again."); return; }
      if (result.verified) { setCode(""); onVerified(); return; }
      setSent(true); setMessage("Your verification email has been queued. Codes expire after five minutes; resend is available after 60 seconds.");
    } catch { setError("Unable to connect. Your registration entries are still here."); }
    finally { setPending(false); }
  }
  return <section className={styles.availability} aria-labelledby="email-verification-heading"><h2 id="email-verification-heading">Verify your account email</h2><p>Email verification confirms your account email. It does not approve your investor profile.</p>
    <form onSubmit={event => { event.preventDefault(); void action("verify"); }}><div className={styles.field}><label htmlFor="email-code">Six-digit verification code</label><input id="email-code" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} required value={code} onChange={event => setCode(event.target.value)} /></div><div className={styles.actions}><button type="button" disabled={pending} className={styles.secondary} onClick={() => void action("send")}>{sent ? "Resend code" : "Send verification code"}</button><button disabled={pending} className={styles.primary}>{pending ? "Checking…" : "Verify email"}</button></div></form>{message && <p role="status">{message}</p>}{error && <p role="alert">{error}</p>}
  </section>;
}
