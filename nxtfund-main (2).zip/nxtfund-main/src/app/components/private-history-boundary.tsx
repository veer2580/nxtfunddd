"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { flushSync } from "react-dom";

function privateHistoryPath(path: string) {
  return path === "/login" || path === "/investor-registration" || path === "/onboarding/investor"
    || path === "/account/investor-registration" || path === "/review/investor-registrations"
    || path === "/ops/reviews" || path === "/app/investor" || path.startsWith("/app/investor/");
}

export default function PrivateHistoryBoundary({ children }: { children: ReactNode }) {
  const [reloading, setReloading] = useState(false);
  const reloadStarted = useRef(false);
  useEffect(() => {
    function revalidateHistory() {
      if (!privateHistoryPath(window.location.pathname) || reloadStarted.current) return;
      reloadStarted.current = true;
      // Router history can retain private React state after cookie revocation. Remove it before paint,
      // then require a fresh server session/ownership check instead of restoring the old snapshot.
      flushSync(() => setReloading(true));
      window.location.reload();
    }
    function restorePage(event: PageTransitionEvent) { if (event.persisted) revalidateHistory(); }
    window.addEventListener("popstate", revalidateHistory);
    window.addEventListener("pageshow", restorePage);
    return () => { window.removeEventListener("popstate", revalidateHistory); window.removeEventListener("pageshow", restorePage); };
  }, []);
  if (reloading) return <main id="main-content" tabIndex={-1}><p role="status">Checking account access…</p></main>;
  return children;
}
