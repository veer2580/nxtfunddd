import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Geist } from "next/font/google";
import PublicPageShell from "./components/public-page-shell";
import SiteFooter from "./components/site-footer";
import "./globals.css";

const geist = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "NxtFund | Startups, Investors & Business Opportunities",
    template: "%s | NxtFund",
  },
  description:
    "Explore NxtFund’s approach to startup funding, investor connections and business ownership opportunities.",
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en" className={`${geist.variable} h-full antialiased`}>
      <body className="min-h-full font-sans">
        <PublicPageShell footer={<SiteFooter />}>{children}</PublicPageShell>
      </body>
    </html>
  );
}
