import type { Metadata } from "next";
import SiteHeader from "../../components/site-header";
import RegistrationStatus from "../../components/registration-status";
export const metadata: Metadata = { title: "Investor Registration Status", robots: { index: false, follow: false } };
export default function Status() { return <><SiteHeader /><main id="main-content" tabIndex={-1}><RegistrationStatus /></main></>; }
