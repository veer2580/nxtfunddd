import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import { LegalSections, LegalToc } from "../components/legal-document";
import { lastUpdated, riskIntro, riskSections, termsSections } from "../../lib/legal/content";
import styles from "../components/legal-document.module.css";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: "The terms and conditions and investment risk disclaimer that govern your use of the NxtFund website.",
};

export default function TermsPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}><div className={styles.container}>
    <header className={styles.head}>
      <p className={styles.eyebrow}>LEGAL CENTRE</p>
      <h1>Terms &amp; Conditions</h1>
      <p>Welcome to NXTFUND, a venture investment and startup ecosystem initiative of Celebso Group, operated by Celebso Technologies. These Terms &amp; Conditions and the Privacy Policy together govern your access to and use of www.nxtfund.in. Please read them carefully before using the Website.</p>
      <p className={styles.updated}>Last Updated: {lastUpdated}</p>
      <div className={styles.switch}><SiteLink href="/terms-and-conditions" aria-current="page">Terms &amp; Conditions</SiteLink><SiteLink href="/privacy-policy">Privacy Policy</SiteLink></div>
    </header>
    <LegalToc title="In this document" sections={termsSections} prefix="t" />
    <LegalSections sections={termsSections} prefix="t" contactTitle="Contact Us" />
    <h2 className={styles.part} id="investment-risk">Investment Risk &amp; Regulatory Disclaimer</h2>
    {riskIntro.map((paragraph) => <p key={paragraph} className={styles.notice}>{paragraph}</p>)}
    <LegalSections sections={riskSections} prefix="r" contactTitle="" />
  </div></main></>;
}
