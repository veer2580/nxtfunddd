import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import styles from "./about.module.css";

export const metadata: Metadata = {
  title: "About Us",
  description: "NXTFUND is a global venture platform that discovers, supports and scales ambitious founders from every corner of the world.",
};

const team = [
  { name: "VEER SINGH", initials: "VS", role: "Founder & CEO Celebso Group | NXTFUND", bio: "Founder and CEO of Celebso Group, leading the vision for NXTFUND and its global startup investment and ecosystem strategy." },
  { name: "HARPREET KAUR", initials: "HK", role: "Co-Founder CelebsoX | NXTFUND", bio: "Co-Founder within the Celebso ecosystem, contributing to founder networks, startup growth and the development of the NXTFUND ecosystem." },
  { name: "ARTI ACHARYA", initials: "AA", role: "Co-Founder | NXTFUND", bio: "Co-Founder of NXTFUND, supporting the platform’s growth and its founder and investor ecosystem." },
];

const pillars = [
  { title: "IDEA", copy: "We back bold ideas that solve real world problems." },
  { title: "CAPITAL", copy: "We provide the right capital at the right time." },
  { title: "BUILD", copy: "We support founders through every stage of building." },
  { title: "SCALE", copy: "We help startups scale globally with the right networks." },
  { title: "IMPACT", copy: "We aim for long-term impact for founders, investors and society." },
];

const stats = [
  { value: "Global Focus", copy: "Backing founders worldwide" },
  { value: "8+ Countries", copy: "Active in key startup ecosystems" },
  { value: "100+ Founders", copy: "Engaged and supported" },
  { value: "Strategic Network", copy: "Investors, mentors & partners globally" },
  { value: "Long-term Vision", copy: "Building enduring value across generations" },
];

export default function AboutUs() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
    <section className={styles.hero} aria-labelledby="about-heading"><div className={styles.container}>
      <p className={styles.eyebrow}>ABOUT NXTFUND</p>
      <h1 id="about-heading">Building the bridge between global capital, exceptional founders and opportunity.</h1>
      <p className={styles.lede}>NXTFUND is a global venture platform that discovers, supports and scales ambitious founders from every corner of the world.</p>
    </div></section>

    <section className={styles.section} aria-labelledby="team-heading"><div className={styles.container}>
      <p className={styles.eyebrow}>THE TEAM BEHIND NXTFUND</p>
      <h2 id="team-heading" className={styles.srOnly}>The team behind NXTFUND</h2>
      <ul className={styles.team}>
        {team.map((member) => (
          <li key={member.name}>
            <span className={styles.avatar} aria-hidden="true">{member.initials}</span>
            <h3>{member.name}</h3>
            <p className={styles.role}>{member.role}</p>
            <p>{member.bio}</p>
          </li>
        ))}
      </ul>
    </div></section>

    <section className={`${styles.section} ${styles.warm}`} aria-labelledby="why-heading"><div className={`${styles.container} ${styles.narrow}`}>
      <p className={styles.eyebrow}>WHY WE EXIST</p>
      <h2 id="why-heading">Why We Built NXTFUND</h2>
      <p>We started building while we were still in college. We experienced firsthand how difficult it can be for ambitious founders to turn an idea into a real business without the right capital, resources and ecosystem around them.</p>
      <p>We believe no ambitious founder should have to give up on a meaningful idea simply because they could not access the right opportunity.</p>
      <blockquote>“Builders should build. NXTFUND should help open the doors.”</blockquote>
      <p>Our ambition is to help exceptional founders — from India and around the world — turn meaningful ideas into enduring companies.</p>
    </div></section>

    <section className={styles.section} aria-label="What we do"><div className={styles.container}>
      <ul className={styles.pillars}>
        {pillars.map((p) => <li key={p.title}><h3>{p.title}</h3><p>{p.copy}</p></li>)}
      </ul>
    </div></section>

    <section className={`${styles.section} ${styles.blue}`} aria-label="NXTFUND at a glance"><div className={styles.container}>
      <ul className={styles.stats}>
        {stats.map((s) => <li key={s.value}><strong>{s.value}</strong><span>{s.copy}</span></li>)}
      </ul>
    </div></section>

    <section className={styles.cta} aria-labelledby="cta-heading"><div className={styles.container}>
      <h2 id="cta-heading">Let’s build the next together.</h2>
      <p>Partner with us to build, scale and create impact across borders.</p>
      <div className={styles.actions}>
        <SiteLink href="/become-a-partner" className={styles.primary}>Partner With Us</SiteLink>
        <SiteLink href="/startup-registration" className={styles.secondary}>Apply for Funding →</SiteLink>
      </div>
    </div></section>
  </main></>;
}
