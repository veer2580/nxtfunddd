export { default, metadata } from "../../review/investor-registrations/page";
