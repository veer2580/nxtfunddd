"use client";
import { useRef, useState, type KeyboardEvent } from "react";
import EcosystemVisual from "./ecosystem-visual";
import EcosystemAction from "./ecosystem-action";
import styles from "./ecosystem.module.css";

const pathways = [
  { name: "Founders", id: "founders", copy: "Explore the startup pathway, from preparing your application to due diligence and investor conversations.", action: "Explore the startup pathway", href: "/startups" },
  { name: "Investors", id: "investors", copy: "Explore investor participation, structured information review and direct conversations with founders.", action: "Explore investor participation", href: "/investors" },
  { name: "Partners", id: "partners", copy: "Explore collaboration with NxtFund around startup readiness, introductions and relevant programmes.", action: "Explore collaboration", href: "/partners" },
] as const;
export default function ParticipationSelector() {
  const [selected, setSelected] = useState(0);
  const buttons = useRef<(HTMLButtonElement | null)[]>([]);
  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next: number;
    switch (event.key) {
      case "ArrowRight": case "ArrowDown": next = (index + 1) % pathways.length; break;
      case "ArrowLeft": case "ArrowUp": next = (index + pathways.length - 1) % pathways.length; break;
      case "Home": next = 0; break;
      case "End": next = pathways.length - 1; break;
      default: return;
    }
    event.preventDefault(); setSelected(next); buttons.current[next]?.focus();
  }
  return <div className={styles.split}>
    <div>
      <div role="group" aria-label="Ways to participate" className={styles.controls}>
        {pathways.map((pathway, index) => <button key={pathway.id} type="button" aria-pressed={selected === index} aria-controls="participation-details"
          ref={button => { buttons.current[index] = button; }} onClick={() => setSelected(index)} onKeyDown={event => navigate(event, index)}>{pathway.name}</button>)}
      </div>
      {/* All panels reserve the longest copy's space without exposing hidden links to focus. */}
      <div id="participation-details" className={styles.details} aria-live="polite" aria-atomic="true">
        {pathways.map((pathway, index) => <div key={pathway.id} data-selected={selected === index} inert={selected !== index} aria-hidden={selected !== index}>
          <h3>{pathway.name}</h3><p>{pathway.copy}</p>
          <EcosystemAction href={pathway.href}>{pathway.action}</EcosystemAction>
        </div>)}
      </div>
    </div>
    <figure className={`${styles.visual} ${styles.network}`}><EcosystemVisual selected={pathways[selected].id} /></figure>
  </div>;
}
