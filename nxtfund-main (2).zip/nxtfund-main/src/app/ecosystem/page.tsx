import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import EcosystemSection from "./ecosystem-section";
import EcosystemVisual from "./ecosystem-visual";
import EcosystemAction from "./ecosystem-action";
import ParticipationSelector from "./participation-selector";
import styles from "./ecosystem.module.css";

export const metadata: Metadata = {
  title: "The NxtFund Ecosystem",
  description: "Explore startup pathways, investor participation and opportunities for ecosystem collaboration with NxtFund.",
};
export default function EcosystemPage() {
  return <>
    <SiteHeader />
    <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
      <section className={styles.hero} aria-labelledby="ecosystem-heading">
        <div className={`${styles.container} ${styles.split}`}>
          <div><p className={styles.eyebrow}>THE NXTFUND ECOSYSTEM</p>
            <h1 id="ecosystem-heading">Better opportunities grow through better connections.</h1>
            <p>Explore the people, organisations and conversations that support the startup journey.</p>
            <p className={styles.note}>The illustration represents ecosystem categories, not confirmed members or partnerships.</p>
          </div>
          <figure className={`${styles.visual} ${styles.network}`}><EcosystemVisual /></figure>
        </div>
      </section>
      <EcosystemSection id="participate">
        <p className={styles.eyebrow}>FIND YOUR PATHWAY</p><h2 id="participate-heading">Ways to participate.</h2>
        <ParticipationSelector />
      </EcosystemSection>
      <EcosystemSection id="partner-ecosystem" className={styles.partners}>
        <div className={styles.split}>
          <figure className={styles.visual}><EcosystemVisual kind="partners" /></figure>
          <div><p className={styles.eyebrow}>PARTNER ECOSYSTEM</p><h2 id="partner-ecosystem-heading">Build around the startup journey.</h2>
            <p>Incubators, accelerators, institutions and industry organisations can explore collaboration around startup introductions, readiness and relevant programmes.</p>
            <ul className={styles.topics}><li>Startup introductions</li><li>Founder readiness</li><li>Relevant programmes</li></ul>
            <EcosystemAction href="/partners">Explore partners</EcosystemAction>
          </div>
        </div>
      </EcosystemSection>
      <EcosystemSection id="ecosystem-conversations">
        <div className={styles.teasers}>
          <article aria-labelledby="ecosystem-conversations-heading">
            <div className={styles.teaserVisual}><EcosystemVisual kind="conversation" /></div>
            <p className={styles.eyebrow}>EVENTS AND CONVERSATIONS</p><h2 id="ecosystem-conversations-heading">Make room for useful conversations.</h2>
            <p>A place to explore founder readiness, investor perspectives and opportunities for collaboration. No verified event schedule is available to show.</p>
            <EcosystemAction href="/events">Explore events</EcosystemAction>
          </article>
          <article aria-labelledby="ecosystem-gallery-heading">
            <div className={`${styles.teaserVisual} ${styles.galleryVisual}`}><EcosystemVisual kind="gallery" /></div>
            <p className={styles.eyebrow}>GALLERY</p><h2 id="ecosystem-gallery-heading">A view of the ecosystem.</h2>
            <p>Approved photographs can document real conversations and gatherings. No verified gallery photographs are available to preview.</p>
            <EcosystemAction href="/gallery">Explore gallery</EcosystemAction>
          </article>
        </div>
      </EcosystemSection>
      <EcosystemSection id="ecosystem-invitation" className={styles.invitation}>
        <div className={styles.split}>
          <div><p className={styles.eyebrow}>THE NEXT CONNECTION</p><h2 id="ecosystem-invitation-heading">Help build the next connection.</h2>
            <p>Explore how your organisation could contribute to startup readiness and meaningful introductions.</p>
            <EcosystemAction href="/become-a-partner" primary>Become a Partner</EcosystemAction>
          </div>
          <figure className={styles.visual}><EcosystemVisual kind="invitation" /></figure>
        </div>
      </EcosystemSection>
    </main>
  </>;
}
