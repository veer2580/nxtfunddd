type VisualKind = "connections" | "partners" | "conversation" | "gallery" | "invitation";
const categories = [
  { label: "Founders", x: 30, y: 36, group: "founders" },
  { label: "Investors", x: 290, y: 36, group: "investors" },
  { label: "Incubators", x: 30, y: 280, group: "partners" },
  { label: "Accelerators", x: 290, y: 280, group: "partners" },
];
export default function EcosystemVisual({ kind = "connections", selected }: { kind?: VisualKind; selected?: string }) {
  if (kind === "connections") return <svg viewBox="0 0 500 440" aria-hidden="true" data-emphasis={selected}>
    <g fill="none" stroke="currentColor" strokeWidth="1.5">
      {categories.map(node => <path key={node.label} data-highlighted={selected === node.group} d={`M${node.x + 90} ${node.y + 42} L250 202`} />)}
      <path data-highlighted={selected === "partners"} d="M250 202V390" />
    </g>
    {categories.map(node => <g key={node.label} data-highlighted={selected === node.group}>
      <rect x={node.x} y={node.y} width="180" height="84" fill={node.group === "partners" ? "var(--surface-yellow)" : "var(--surface)"} stroke="currentColor" />
      <text x={node.x + 90} y={node.y + 48} textAnchor="middle" fontSize="22" fill="currentColor">{node.label}</text>
    </g>)}
    <circle cx="250" cy="202" r="59" fill="var(--surface)" stroke="currentColor" />
    <text x="250" y="195" textAnchor="middle" fontSize="21" fill="currentColor">NxtFund</text>
    <text x="250" y="220" textAnchor="middle" fontSize="14" fill="currentColor">Connections</text>
    <g data-highlighted={selected === "partners"}><rect x="126" y="380" width="248" height="48" fill="var(--surface-yellow)" stroke="currentColor" /><text x="250" y="411" textAnchor="middle" fontSize="21" fill="currentColor">Institutional partners</text></g>
  </svg>;
  return <svg viewBox="0 0 500 340" aria-hidden="true">
    {kind === "partners" ? <>
      <path d="M65 255H445M105 255V121H245V255M275 255V94H415V255" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M83 121L175 56L267 121M255 94L345 38L435 94" fill="var(--surface-yellow)" stroke="currentColor" strokeWidth="2" />
      <path d="M140 156H210M140 181H210M315 129H375M315 155H375M315 181H375" stroke="currentColor" strokeWidth="2" />
      <path d="M174 255V216H204V255M331 255V216H361V255" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M204 280H331M318 269L331 280L318 291" fill="none" stroke="var(--brand)" strokeWidth="3" />
    </> : kind === "conversation" ? <>
      <path d="M62 57H310V185H165L109 227V185H62Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M228 151H439V281H379L337 317V281H228Z" fill="var(--accent-mint)" stroke="currentColor" strokeWidth="2" />
      <path d="M101 99H262M101 133H224M268 197H399M268 231H361" stroke="currentColor" strokeWidth="2" />
      <circle cx="380" cy="72" r="28" fill="var(--accent-yellow)" /><path d="M380 56V88M364 72H396" stroke="var(--brand)" strokeWidth="2" />
    </> : kind === "gallery" ? <>
      <path d="M95 63H405V274H95Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M126 95H374V241H126Z" fill="var(--surface-blue)" stroke="currentColor" />
      <path d="M126 241L206 160L270 215L320 175L374 241" fill="var(--accent-mint)" stroke="currentColor" />
      <circle cx="324" cy="127" r="17" fill="var(--accent-yellow)" />
      <path d="M69 91H54V301H362V288" fill="none" stroke="var(--brand)" strokeWidth="2" />
    </> : <>
      <path d="M70 245L193 122H311L431 245" fill="none" stroke="currentColor" strokeWidth="2" />
      <rect x="174" y="65" width="150" height="121" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M208 98H289M208 122H264M208 147H279" stroke="currentColor" strokeWidth="2" />
      <circle cx="70" cy="245" r="34" fill="var(--accent-mint)" stroke="currentColor" /><circle cx="431" cy="245" r="34" fill="var(--accent-yellow)" stroke="currentColor" />
      <path d="M231 245H270M250 226V264" stroke="var(--brand)" strokeWidth="3" />
    </>}
  </svg>;
}
