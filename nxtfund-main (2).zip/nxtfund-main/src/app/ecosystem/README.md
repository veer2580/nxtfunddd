# Ecosystem route and content availability

`/ecosystem` is the public overview. Header overview and footer use the canonical page. Founder and Investor participation actions use `/startups` and `/investors`.

`/partners` and `/become-a-partner` now exist and their teasers link to those pages. The partner enquiry form is usable through review; submission remains unavailable. `/events` and `/gallery` now exist with illustrated empty states and working teaser links. No verified event records or approved activity photos are connected. No fake event dates or partner logos/counts were added.

Local brand imagery is not verified as real ecosystem activity or approved gallery photographs. This page uses code-native SVG illustrations of categories, collaboration, conversations and a gallery frame; no photographic preview or member directory is shown. Approved partner records, verified event details and consented gallery assets would be needed for those features.

The participation controls use pressed states, click/touch, arrow/Home/End navigation and stable overlapping panels. Inactive panels are inert and hidden from accessibility APIs. Scroll reveals are optional, with content initially visible and reduced motion disabling transitions.
