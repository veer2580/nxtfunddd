import SiteLink from "../components/site-link";
import { isPublicRouteAvailable } from "../components/site-navigation";
import styles from "./ecosystem.module.css";

export default function EcosystemAction({ href, children, primary = false }: { href: string; children: string; primary?: boolean }) {
  if (isPublicRouteAvailable(href)) return <SiteLink href={href} className={primary ? styles.primaryAction : styles.textAction}>{children}<span aria-hidden="true">↗</span></SiteLink>;
  return <div className={styles.unavailable} aria-disabled="true"><span>{children}</span><small>Page unavailable</small></div>;
}
