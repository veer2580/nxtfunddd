"use client";
import type { ReactNode } from "react";
import { useScrollReveal } from "../components/use-scroll-reveal";
import styles from "./ecosystem.module.css";

export default function EcosystemSection({ id, children, className = "" }: { id: string; children: ReactNode; className?: string }) {
  const { ref, entered } = useScrollReveal<HTMLElement>(true);
  return <section id={id} ref={ref} aria-labelledby={`${id}-heading`} className={`${styles.section} ${className}`} data-entered={entered}>
    <div className={styles.container}>{children}</div>
  </section>;
}
