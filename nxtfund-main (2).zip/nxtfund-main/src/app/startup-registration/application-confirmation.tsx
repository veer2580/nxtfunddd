import SiteLink from "../components/site-link";
import styles from "../components/registration-confirmation.module.css";

// This receipt must come from a committed backend response, never client input.
export type SavedApplicationReceipt = {
  reference: string;
  status: string;
};

const reviewStages = ["Application received", "Initial review", "Due diligence", "Pitch consideration", "Investor introductions"];

export default function ApplicationConfirmation({ application }: { application: SavedApplicationReceipt }) {
  if (!application.reference.trim() || !application.status.trim()) return null;

  return (
    <section className={styles.confirmation} aria-labelledby="application-received-heading">
      <h2 id="application-received-heading" tabIndex={-1}>Application received.</h2>
      <p>Your application has been saved and will be reviewed.</p>
      <dl className={styles.receipt}>
        <div><dt>Application reference</dt><dd>{application.reference}</dd></div>
        <div><dt>Current status</dt><dd>{application.status}</dd></div>
      </dl>
      <h3>What comes next</h3>
      <ol className={styles.stages}>
        {reviewStages.map((stage, index) => <li key={stage}><span aria-hidden="true">0{index + 1}</span>{stage}</li>)}
      </ol>
      <p>Later stages depend on review outcomes. Submission does not imply approval or guarantee funding. Investment decisions are made by individual investors.</p>
      <div className={styles.actions}>
        <SiteLink href="/" className={styles.action}>Back to Home</SiteLink>
        <SiteLink href="/due-diligence" className={styles.action}>Explore the Due Diligence Process</SiteLink>
      </div>
    </section>
  );
}
