import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import StartupVisual from "../startups/startup-visual";
import ApplicationForm from "./application-form";
import styles from "../components/registration.module.css";

export const metadata: Metadata = {
  title: "Apply for Funding",
  description: "Prepare your startup, founder, funding and document information for NxtFund. Applications are currently unavailable.",
};

export default function StartupRegistration() {
  return <>
    <SiteHeader />
    <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
      <div className={styles.container}>
        <div className={styles.introduction}>
          <p className={styles.eyebrow}>STARTUP APPLICATION</p>
          <h1>Apply for Funding</h1>
          <p>Tell us about your startup, your team and the funding you need.</p>
        </div>
        <div className={styles.layout}>
          <aside className={styles.aside}>
            <div className={styles.visual}><StartupVisual kind="funding" /></div>
            <h2>Prepare for a meaningful conversation.</h2>
            <p>Submitting an application does not guarantee funding. Investment decisions are made by individual investors.</p>
          </aside>
          <ApplicationForm />
        </div>
      </div>
    </main>
  </>;
}
