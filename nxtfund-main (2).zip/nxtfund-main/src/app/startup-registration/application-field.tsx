import type { ComponentProps } from "react";
import RegistrationField from "../components/registration-field";
import { fieldLimits, type ApplicationFields } from "@/lib/startup-application/validation";

type ApplicationFieldProps = Omit<ComponentProps<typeof RegistrationField>, "name" | "maxLength" | "options" | "required"> & { name: keyof ApplicationFields };

export default function ApplicationField({ name, ...props }: ApplicationFieldProps) {
  return <RegistrationField name={name} maxLength={fieldLimits[name]} {...props} />;
}
