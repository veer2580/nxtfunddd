"use client";

import { useEffect, useRef, useState } from "react";
import { applicationUnavailableMessage } from "@/lib/startup-application/availability";
import { initialFields, validateFields, type ApplicationFields, type ApplicationErrors } from "@/lib/startup-application/validation";
import { validatePdf } from "@/lib/startup-application/documents";
import ApplicationField from "./application-field";
import styles from "../components/registration.module.css";

const steps = ["Startup and founder", "Funding requirements", "Documents and review"];
const labels: Record<keyof ApplicationFields, string> = {
  companyName: "Company/startup name", founderName: "Founder name", email: "Email", phone: "Phone",
  sector: "Sector", stage: "Stage", fundingAsk: "Funding ask in INR", useOfFunds: "Proposed use of funds", financialExplanation: "Why financial information is unavailable",
};

export default function ApplicationForm() {
  const [fields, setFields] = useState(initialFields);
  const [step, setStep] = useState(0);
  const [review, setReview] = useState(false);
  const [financialUnavailable, setFinancialUnavailable] = useState(false);
  const [pitchDeck, setPitchDeck] = useState<File | null>(null);
  const [financialDocument, setFinancialDocument] = useState<File | null>(null);
  const [errors, setErrors] = useState<ApplicationErrors>({});
  const [checking, setChecking] = useState(false);
  const heading = useRef<HTMLHeadingElement>(null);
  const errorSummary = useRef<HTMLDivElement>(null);
  const moved = useRef(false);

  useEffect(() => {
    if (moved.current) heading.current?.focus();
    moved.current = true;
  }, [step, review]);

  function update(name: keyof ApplicationFields, value: string) {
    setFields(current => ({ ...current, [name]: value }));
    clearError(name);
  }

  function clearError(name: keyof ApplicationErrors) {
    setErrors(current => {
      const remaining = { ...current };
      delete remaining[name];
      return remaining;
    });
  }

  async function next() {
    if (checking) return;
    const issues = validateFields(fields, financialUnavailable, step);
    if (step === 2) {
      setChecking(true);
      const [pitchError, financialError] = await Promise.all([
        validatePdf(pitchDeck, true),
        financialUnavailable ? Promise.resolve(undefined) : validatePdf(financialDocument, true),
      ]);
      if (pitchError) issues.pitchDeck = pitchError;
      if (financialError) issues.financialDocument = financialError;
      setChecking(false);
    }
    setErrors(issues);
    if (Object.keys(issues).length) {
      requestAnimationFrame(() => errorSummary.current?.focus());
      return;
    }
    if (step === 2) setReview(true);
    else setStep(current => current + 1);
  }

  function back() {
    setErrors({});
    if (review) setReview(false);
    else setStep(current => Math.max(0, current - 1));
  }

  function field(name: keyof ApplicationFields, example: string, options: { multiline?: boolean; inputMode?: "email" | "tel" | "decimal"; autoComplete?: string } = {}) {
    return <ApplicationField key={name} name={name} label={labels[name]} value={fields[name]} onChange={value => update(name, value)} error={errors[name]} example={example} {...options} />;
  }

  function documentInput(name: "pitchDeck" | "financialDocument", label: string, file: File | null, setFile: (file: File | null) => void) {
    return <div className={styles.field}>
      <label htmlFor={`field-${name}`}>{label}</label>
      <input id={`field-${name}`} name={name} type="file" accept=".pdf,application/pdf" aria-invalid={Boolean(errors[name])} aria-describedby={`${name}-hint${errors[name] ? ` ${name}-error` : ""}`} onChange={event => { setFile(event.target.files?.[0] ?? null); clearError(name); }} />
      <p id={`${name}-hint`} className={styles.hint}>PDF only, up to 5 MiB. {file ? `Selected: ${file.name}` : "Export your document as an unencrypted PDF."}</p>
      {errors[name] && <p id={`${name}-error`} className={styles.error}>{errors[name]}</p>}
    </div>;
  }

  return <form className={styles.form} noValidate onSubmit={event => { event.preventDefault(); }}>
    <div className={styles.availability} role="note">
      <strong>Submission unavailable</strong>
      <p>Applications are currently unavailable. Prepare and review your details below.</p>
      <p>Entries and documents stay in this tab’s memory. Refreshing or leaving clears them; nothing is uploaded.</p>
    </div>
    <ol className={styles.progress} aria-label="Application progress">
      {steps.map((label, index) => <li key={label} aria-current={index === step ? "step" : undefined}><span aria-hidden="true">0{index + 1}</span><span>{label}</span></li>)}
    </ol>
    <h2 ref={heading} tabIndex={-1}>{review ? "Review your application" : steps[step]}</h2>
    {Object.keys(errors).length > 0 && <div ref={errorSummary} className={styles.errorSummary} role="alert" tabIndex={-1}>
      <strong>Check these details before continuing.</strong>
      <ul>{Object.entries(errors).map(([name, message]) => <li key={name}><a href={`#field-${name}`}>{labels[name as keyof ApplicationFields] ?? (name === "pitchDeck" ? "Pitch deck" : "Financial information")}: {message}</a></li>)}</ul>
    </div>}
    {review ? <div className={styles.review}>
      <dl>{Object.entries(fields).filter(([name]) => name !== "financialExplanation").map(([name, value]) => <div key={name}><dt>{labels[name as keyof ApplicationFields]}</dt><dd>{name === "fundingAsk" ? new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(Number(value)) : value}</dd></div>)}
        <div><dt>Pitch deck</dt><dd>{pitchDeck?.name}</dd></div>
        <div><dt>Financial information</dt><dd>{financialUnavailable ? `Unavailable: ${fields.financialExplanation}` : financialDocument?.name}</dd></div>
      </dl>
      <p>Submitting an application does not guarantee funding. Investment decisions are made by individual investors.</p>
    </div> : <fieldset disabled={checking} className={styles.fields} key={step}>
      <legend className="visually-hidden">{steps[step]}</legend>
      {step === 0 && <>
        {field("companyName", "For example, Example Technologies", { autoComplete: "organization" })}
        {field("founderName", "Your full name", { autoComplete: "name" })}
        {field("email", "For example, founder@example.com", { inputMode: "email", autoComplete: "email" })}
        {field("phone", "Include country code where applicable, for example +91 98765 43210", { inputMode: "tel", autoComplete: "tel" })}
        {field("sector", "For example, fintech, healthtech or clean energy")}
        {field("stage", "For example, idea, prototype, early revenue or growth")}
      </>}
      {step === 1 && <>
        {field("fundingAsk", "Amount in INR without commas, for example 2500000. Up to two decimal places.", { inputMode: "decimal" })}
        {field("useOfFunds", "Explain the intended use, for example product development, hiring or market expansion.", { multiline: true })}
      </>}
      {step === 2 && <>
        {documentInput("pitchDeck", "Pitch deck", pitchDeck, setPitchDeck)}
        <label className={styles.checkbox}><input type="checkbox" checked={financialUnavailable} onChange={event => { setFinancialUnavailable(event.target.checked); clearError("financialDocument"); clearError("financialExplanation"); }} />Financial documents are not available yet</label>
        {financialUnavailable ? field("financialExplanation", "Explain your startup’s stage and why financial information is not available. Any previously selected financial file is excluded while this option is selected.", { multiline: true }) : documentInput("financialDocument", "Financial information", financialDocument, setFinancialDocument)}
        <p className={styles.hint}>Maximum 10 MiB across both documents. Files remain private in this browser tab and are not sent to the server.</p>
      </>}
    </fieldset>}
    <div className={styles.actions}>
      {(step > 0 || review) && <button type="button" onClick={back} disabled={checking} className={styles.secondary}>{review ? "Edit documents" : "Back"}</button>}
      {review ? <>
        <button type="button" className={styles.secondary} onClick={() => { setStep(0); setReview(false); }}>Edit startup details</button>
        <button type="submit" disabled className={styles.primary} aria-describedby="submission-status">Submit application — unavailable</button>
      </> : <button type="button" onClick={next} disabled={checking} className={styles.primary}>{checking ? "Checking documents…" : step === 2 ? "Review application" : "Next"}</button>}
    </div>
    <p id="submission-status" className={styles.hint} aria-live="polite">{checking ? "Checking document contents on your device." : applicationUnavailableMessage}</p>
  </form>;
}
