import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import PortfolioGrid, { type Venture } from "./portfolio-grid";
import styles from "./portfolio.module.css";

export const metadata: Metadata = {
  title: "Startup Portfolio",
  description: "Startups and technology ventures backed, incubated and supported by NxtFund.",
};

const ventures: Venture[] = [
  { name: "ANTELLAY Space", initials: "A", tags: ["SpaceTech", "AI"], stage: "Venture", blurb: "AI-native intelligence and infrastructure for the next generation of space operations." },
  { name: "Volimy", initials: "V", tags: ["Technology", "AI"], stage: "Early Stage", blurb: "An emerging technology venture building intelligent digital solutions." },
  { name: "Byizon.ai", initials: "b", tags: ["AI", "SaaS"], stage: "Venture", blurb: "AI-powered technology solutions designed to simplify and accelerate modern business." },
  { name: "Grehni.ai", initials: "g.", tags: ["AI", "Technology"], stage: "Early Stage", blurb: "An emerging AI venture focused on intelligent digital experiences and automation." },
  { name: "Numerixx.ai", initials: "N", tags: ["AI", "Predictive Intelligence"], stage: "Venture", blurb: "An AI-driven predictive intelligence platform combining data, mathematics and intelligent insights." },
  { name: "UncoverdDeals", initials: "UD", tags: ["Consumer", "Technology"], stage: "Early Stage", blurb: "A discovery platform helping users uncover products, deals and opportunities." },
  { name: "ANTELLAY-X.io", initials: "X", tags: ["DeepTech", "Technology"], stage: "Venture", blurb: "An experimental technology venture focused on next-generation digital and intelligent infrastructure." },
];

export default function PortfolioPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
    <section className={styles.hero} aria-labelledby="portfolio-title"><div className={styles.container}>
      <h1 id="portfolio-title">Startup Portfolio</h1>
      <p>Backing ambitious founders building the next generation of technology companies.</p>
    </div></section>
    <section className={styles.listing} aria-labelledby="portfolio-heading"><div className={styles.container}>
      <PortfolioGrid ventures={ventures} />
    </div></section>
    <section className={styles.cta}><div className={styles.container}><div className={styles.ctaBox}>
      <h2>Building the next big thing?</h2>
      <p>If you’re building an ambitious technology company, we want to hear from you.</p>
      <SiteLink className={styles.button} href="/startup-registration">Apply for Funding →</SiteLink>
    </div></div></section>
  </main></>;
}
