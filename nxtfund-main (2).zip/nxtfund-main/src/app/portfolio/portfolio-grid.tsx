"use client";

import { useState } from "react";
import SiteLink from "../components/site-link";
import styles from "./portfolio.module.css";

export type Venture = { name: string; tags: string[]; stage: string; blurb: string; initials: string };

export default function PortfolioGrid({ ventures }: { ventures: Venture[] }) {
  const filters = ["All", ...Array.from(new Set(ventures.flatMap((v) => v.tags)))];
  const [active, setActive] = useState("All");
  const shown = ventures.filter((v) => active === "All" || v.tags.includes(active));
  return (
    <>
      <div className={styles.listHead}>
        <h2 id="portfolio-heading">Our Portfolio</h2>
        <span className={styles.count}>{ventures.length} Startups</span>
      </div>
      <p className={styles.sub}>Startups and technology ventures backed, incubated and supported by NXTFUND.</p>
      <div className={styles.filters} role="group" aria-label="Filter by sector">
        {filters.map((f) => (
          <button key={f} type="button" aria-pressed={active === f} className={active === f ? styles.chipActive : styles.chip} onClick={() => setActive(f)}>{f}</button>
        ))}
      </div>
      <ul className={styles.grid}>
        {shown.map((v) => (
          <li key={v.name} className={styles.card}>
            <div className={styles.cardTop}>
              <span className={styles.mark} aria-hidden="true">{v.initials}</span>
              <span className={styles.stage}>{v.stage}</span>
            </div>
            <h3>{v.name}</h3>
            <p className={styles.tags}>{v.tags.join(" • ")}</p>
            <p className={styles.blurb}>{v.blurb}</p>
            <div className={styles.status}><span>Status</span><strong>Portfolio Company</strong></div>
          </li>
        ))}
        {active === "All" && (
          <li className={styles.card}>
            <div className={styles.cardTop}><span className={styles.mark} aria-hidden="true">+</span></div>
            <h3>More Ventures Coming Soon</h3>
            <p className={styles.blurb}>Our portfolio continues to grow as we back the next generation of ambitious founders.</p>
            <div className={styles.status}><span>Status</span><strong>Upcoming</strong></div>
            <SiteLink className={styles.inline} href="/startup-registration">Become a Portfolio Company →</SiteLink>
          </li>
        )}
      </ul>
    </>
  );
}
