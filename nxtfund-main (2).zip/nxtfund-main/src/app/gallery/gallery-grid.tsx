"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import styles from "./gallery.module.css";

export type Photo = { src: string; width: number; height: number; alt: string; caption: string; tag: string };

export default function GalleryGrid({ photos }: { photos: Photo[] }) {
  const tags = ["All", ...Array.from(new Set(photos.map((p) => p.tag)))];
  const [tag, setTag] = useState("All");
  const [open, setOpen] = useState<number | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const shown = photos.filter((p) => tag === "All" || p.tag === tag);

  useEffect(() => {
    const el = dialog.current;
    if (!el) return;
    if (open !== null && !el.open) el.showModal();
    if (open === null && el.open) el.close();
  }, [open]);

  function step(delta: number) {
    setOpen((i) => (i === null ? i : (i + delta + shown.length) % shown.length));
  }
  const current = open !== null ? shown[open] : null;

  return (
    <>
      <div className={styles.filters} role="group" aria-label="Filter photos">
        {tags.map((t) => (
          <button key={t} type="button" aria-pressed={tag === t} className={tag === t ? styles.chipActive : styles.chip} onClick={() => setTag(t)}>{t}</button>
        ))}
      </div>
      <ul className={styles.grid}>
        {shown.map((p, i) => (
          <li key={p.src}>
            <button type="button" className={styles.thumb} onClick={() => setOpen(i)} aria-label={`Open photo: ${p.caption}`}>
              <Image src={p.src} alt={p.alt} width={p.width} height={p.height} sizes="(max-width: 640px) 100vw, (max-width: 980px) 50vw, 33vw" loading="lazy" />
              <span>{p.caption}</span>
            </button>
          </li>
        ))}
      </ul>
      <dialog
        ref={dialog}
        className={styles.lightbox}
        aria-label="Photo viewer"
        onClose={() => setOpen(null)}
        onClick={(e) => { if (e.target === dialog.current) setOpen(null); }}
        onKeyDown={(e) => { if (e.key === "ArrowRight") step(1); if (e.key === "ArrowLeft") step(-1); }}
      >
        {current && (
          <figure>
            <Image src={current.src} alt={current.alt} width={current.width} height={current.height} sizes="100vw" priority />
            <figcaption>{current.caption} <small>{(open ?? 0) + 1} / {shown.length}</small></figcaption>
          </figure>
        )}
        <div className={styles.controls}>
          <button type="button" onClick={() => step(-1)} aria-label="Previous photo">←</button>
          <button type="button" onClick={() => step(1)} aria-label="Next photo">→</button>
          <button type="button" onClick={() => setOpen(null)} aria-label="Close viewer">✕</button>
        </div>
      </dialog>
    </>
  );
}
