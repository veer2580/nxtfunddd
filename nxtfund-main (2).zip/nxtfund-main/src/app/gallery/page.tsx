import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import ActivitySection from "../components/activity-section";
import ActivityVisual from "../components/activity-visual";
import GalleryGrid, { type Photo } from "./gallery-grid";
import styles from "../components/activity-pages.module.css";

export const metadata: Metadata = { title: "Gallery", description: "Photographs from NxtFund events, founder sessions, recognition moments and the community." };

const photos: Photo[] = [
  { src: "/images/gallery/02.jpg", width: 1280, height: 853, alt: "Speaker addressing the audience with a microphone during a panel session", caption: "Panel session at a startup event", tag: "Events" },
  { src: "/images/gallery/04.jpg", width: 960, height: 1280, alt: "Attendees seated on sofas in a blue and white co-working space during a session", caption: "Attendees during a session", tag: "Events" },
  { src: "/images/gallery/09.jpg", width: 1280, height: 853, alt: "Full auditorium of attendees listening to a startup session", caption: "Audience at a startup session", tag: "Events" },
  { src: "/images/gallery/11.jpg", width: 1600, height: 1200, alt: "Panel of speakers seated in front of a Founders Connect banner hosted by Celebso", caption: "Founders Connect, hosted by Celebso", tag: "Events" },
  { src: "/images/gallery/17.jpg", width: 1500, height: 1000, alt: "Six people presenting a bouquet in front of a projector screen at The Startup session", caption: "Speakers welcomed with a bouquet", tag: "Events" },
  { src: "/images/gallery/14.jpg", width: 1200, height: 1600, alt: "Speaker holding a microphone and addressing attendees in a yellow-accent workspace", caption: "Speaker addressing attendees", tag: "Events" },
  { src: "/images/gallery/15.jpg", width: 1200, height: 1600, alt: "Woman speaking to attendees in a conference room", caption: "Speaker addressing attendees", tag: "Events" },
  { src: "/images/gallery/01.jpg", width: 1280, height: 960, alt: "Group photo of attendees with one person holding a certificate", caption: "Group photo with certificate", tag: "Recognition" },
  { src: "/images/gallery/06.jpg", width: 1600, height: 1200, alt: "Group of eight people holding a framed Certificate of Recognition", caption: "Certificate of Recognition presentation", tag: "Recognition" },
  { src: "/images/gallery/08.jpg", width: 1200, height: 1600, alt: "Two people holding a framed Certificate of Recognition", caption: "Certificate of Recognition presented", tag: "Recognition" },
  { src: "/images/gallery/10.jpg", width: 1600, height: 1200, alt: "Group photo of founders and community members at an evening gathering under string lights", caption: "Evening community gathering", tag: "Community" },
  { src: "/images/gallery/13.jpg", width: 1600, height: 1200, alt: "Group photo of attendees standing together in the office after a session", caption: "Group photo after a session", tag: "Community" },
  { src: "/images/gallery/05.jpg", width: 1600, height: 1200, alt: "Attendees talking and networking in the office", caption: "Networking after a session", tag: "Community" },
  { src: "/images/gallery/03.jpg", width: 1280, height: 960, alt: "Chairs arranged in two rows facing two armchairs for a fireside-style session", caption: "Seating set up for a session", tag: "Workspace" },
  { src: "/images/gallery/12.jpg", width: 1280, height: 960, alt: "Meeting room with an illustrated idea and innovation wall mural", caption: "Meeting room", tag: "Workspace" },
  { src: "/images/gallery/16.jpg", width: 1204, height: 1600, alt: "Lounge corner with armchairs, a side table and large windows", caption: "Lounge area", tag: "Workspace" },
];

export default function GalleryPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
    <section className={styles.galleryHero} aria-labelledby="gallery-heading"><div className={`${styles.container} ${styles.split}`}>
      <div><p className={styles.eyebrow}>THE NXTFUND GALLERY</p><h1 id="gallery-heading">Moments from the ecosystem.</h1><p>Photographs from founder sessions, events, recognition moments and our community.</p></div>
      <figure className={styles.visual}><ActivityVisual kind="gallery" /></figure>
    </div></section>
    <div className={`${styles.container} ${styles.content}`}><ActivitySection id="activity-photos">
      <h2 id="activity-photos-heading">Gallery</h2>
      <GalleryGrid photos={photos} />
      <p><SiteLink href="/ecosystem" className={styles.textAction}>Explore the ecosystem <span aria-hidden="true">↗</span></SiteLink></p>
    </ActivitySection></div>
  </main></>;
}
