"use client";
import ActivityError from "../components/activity-error";
export default function GalleryError({ retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return <ActivityError pageName="Gallery" retry={retry} />;
}
