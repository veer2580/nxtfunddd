import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getRegistration, getStore, localBackendEnabled, sessionAccount, sessionCookie } from "@/lib/backend/local-store.mjs";
import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import OpportunityIllustration from "../components/opportunity-illustration";
import { investorRoleStatement } from "@/lib/investor-registration/content";
import InvestorForm from "./investor-form";
import styles from "../components/registration.module.css";

export const metadata: Metadata = {
  title: "Join as an Investor",
  robots: { index: false, follow: false },
  description: "Prepare your profile and investment preferences for NxtFund. Prepare your profile for manual investor review.",
};

export default async function InvestorRegistration() {
  let correction = false;
  if (localBackendEnabled()) {
    const account = sessionAccount(getStore(), (await cookies()).get(sessionCookie)?.value);
    if (account) {
      let status: string | undefined;
      try { status = getRegistration(getStore(), account).statusCode; }
      catch (error) { if ((error as { status?: number }).status !== 404) throw error; }
      correction = status === "needs_information";
      if (status && status !== "needs_information") redirect("/app/investor");
    }
  }
  return <>
    <SiteHeader />
    <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
      <div className={styles.container}>
        <div className={styles.introduction}>
          <p className={styles.eyebrow}>INVESTOR REGISTRATION</p>
          <h1>{correction ? "Update your investor registration" : "Join as an Investor"}</h1>
          <p>{correction ? "Make the requested changes and submit your updated profile for review." : "Share your profile and investment preferences to begin the investor registration process."}</p>
        </div>
        <div className={styles.layout}>
          <aside className={styles.aside}>
            <div className={styles.visual}><OpportunityIllustration kind="investors" /></div>
            <h2>A clearer starting point.</h2>
            <p>{investorRoleStatement}</p>
          </aside>
          <InvestorForm />
        </div>
      </div>
    </main>
  </>;
}
