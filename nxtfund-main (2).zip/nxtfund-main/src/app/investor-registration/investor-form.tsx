"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import RegistrationField from "../components/registration-field";
import SiteLink from "../components/site-link";
import { isPublicRouteAvailable } from "../components/site-navigation";
import { initialInvestorFields, investorFieldLimits, investorCategoryOptions, registrationTypeOptions, validateInvestorFields, type InvestorFields, type InvestorErrors } from "@/lib/investor-registration/validation";
import EmailVerification from "../components/email-verification";
import AccountAuth, { type AccountIdentity } from "../components/account-auth";
import InvestorConfirmation, { type SavedInvestorReceipt } from "./investor-confirmation";
import { investorSubmissionUnavailable, investorFieldLabels } from "@/lib/investor-registration/content";
import styles from "../components/registration.module.css";

const steps = ["Your profile", "Investment preferences", "Review"];
const labels = investorFieldLabels;

export default function InvestorForm() {
  const router = useRouter();
  const [resolved, setResolved] = useState(false);
  const [resolutionAttempt, setResolutionAttempt] = useState(0);
  const [fields, setFields] = useState(initialInvestorFields);
  const [step, setStep] = useState(0);
  const [errors, setErrors] = useState<InvestorErrors>({});
  const [enabled, setEnabled] = useState(false);
  const [account, setAccount] = useState<AccountIdentity | null>(null);
  const [pending, setPending] = useState(false);
  const [serverError, setServerError] = useState("");
  const [receipt, setReceipt] = useState<SavedInvestorReceipt | null>(null);
  const [draftVersion, setDraftVersion] = useState(0);
  const [savedAt, setSavedAt] = useState("");
  const [dirty, setDirty] = useState(false);
  const dirtyRef = useRef(false);
  const [restorable, setRestorable] = useState<{ fields: InvestorFields; version: number; savedAt: string | null } | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [uncertain, setUncertain] = useState(false);
  const submissionKey = useRef("");
  const receiptHeading = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let cancelled = false;
    fetch("/api/auth/session").then(async response => { if (!response.ok) throw new Error(); return response.json(); }).then(result => {
      if (!cancelled) { setEnabled(Boolean(result.enabled)); setRestoring(Boolean(result.account)); setAccount(result.account ?? null); if (!result.account) setResolved(true); }
    }).catch(() => { if (!cancelled) setServerError("Unable to check account access. Try again; your entries have been kept."); });
    return () => { cancelled = true; };
  }, [resolutionAttempt]);
  useEffect(() => { if (receipt) receiptHeading.current?.querySelector<HTMLElement>("h2")?.focus(); }, [receipt]);
  useEffect(() => {
    if (!account?.id) return;
    let cancelled = false;
    fetch("/api/investor-registrations/draft", { cache: "no-store" }).then(async response => {
      const result = await response.json();
      if (cancelled) return;
      if (!response.ok) { setRestoring(false); setServerError(result.message ?? "Unable to restore your draft. Retry loading it before saving."); return; }
      if (result.editable === false) { router.replace("/app/investor"); return; }
      setResolved(true);
      if (result.draft) {
        setDraftVersion(result.draft.version);
        if (dirtyRef.current) setRestorable(result.draft);
        else { setFields({ ...initialInvestorFields, ...result.draft.fields }); setSavedAt(result.draft.savedAt ?? ""); }
      }
      if (!result.draft) setDraftVersion(0);
      setRestoring(false);
    }).catch(() => { if (!cancelled) { setRestoring(false); setServerError("Unable to load your draft. Retry before saving."); } });
    return () => { cancelled = true; };
  }, [account?.id, router, resolutionAttempt]);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); };
    const leave = (event: MouseEvent) => {
      const target = (event.target as Element).closest("a[href]") as HTMLAnchorElement | null;
      if (target && target.origin === location.origin && target.pathname !== location.pathname && !window.confirm("Leave with unsaved registration changes?")) { event.preventDefault(); event.stopPropagation(); }
    };
    window.addEventListener("beforeunload", warn); document.addEventListener("click", leave, true);
    return () => { window.removeEventListener("beforeunload", warn); document.removeEventListener("click", leave, true); };
  }, [dirty]);
  async function loadSavedDraft() {
    setRestoring(true); setServerError("");
    try {
      const response = await fetch("/api/investor-registrations/draft", { cache: "no-store" }); const result = await response.json();
      if (!response.ok) { setServerError(result.message); return; }
      if (result.editable === false) { router.replace("/app/investor"); return; }
      setFields({ ...initialInvestorFields, ...result.draft?.fields }); setDraftVersion(result.draft?.version ?? 0); setSavedAt(result.draft?.savedAt ?? ""); setRestorable(null); setDirty(false); dirtyRef.current = false; submissionKey.current = "";
    } catch { setServerError("Unable to load your saved draft. Your current entries are still here."); }
    finally { setRestoring(false); }
  }
  async function saveDraft() {
    if (!account || pending || restoring) return;
    setPending(true); setServerError("");
    try {
      const response = await fetch("/api/investor-registrations/draft", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fields, expectedVersion: draftVersion }) }); const result = await response.json();
      if (!response.ok) { setServerError(result.message); return; }
      setDraftVersion(result.draft.version); setSavedAt(result.draft.savedAt); setDirty(false); dirtyRef.current = false;
    } catch { setServerError("Unable to confirm the draft save. Your entries remain here; load the saved draft before retrying."); }
    finally { setPending(false); }
  }
  async function reconcileSubmission() {
    setPending(true);
    try {
      const response = await fetch("/api/investor-registrations", { cache: "no-store" }); const result = await response.json();
      if (response.ok && result.registration.submissionKey === submissionKey.current) { setReceipt({ reference: result.registration.reference, status: result.registration.status }); setDirty(false); dirtyRef.current = false; }
      else if (response.status === 404 || response.ok) { setUncertain(false); setServerError("No saved registration was found. You can retry submitting your retained entries."); }
      else setServerError(result.message);
    } catch { setServerError("Unable to check the result. Keep your entries and check status again before retrying."); }
    finally { setPending(false); }
  }
  function showErrors(issues: InvestorErrors) {
    setErrors(issues);
    const profile = ["fullName", "email", "phone", "registeringAs", "organisationName", "investorCategory"];
    setStep(Object.keys(issues).some(name => profile.includes(name)) ? 0 : issues.riskAcknowledged && Object.keys(issues).length === 1 ? 2 : 1);
    requestAnimationFrame(() => errorSummary.current?.focus());
  }
  async function submit() {
    if (!enabled || !account?.emailVerified || pending || restoring || uncertain) return;
    const issues = validateInvestorFields(fields);
    if (fields.riskAcknowledged !== "true") issues.riskAcknowledged = "Acknowledge investment risk before submitting.";
    if (Object.keys(issues).length) { showErrors(issues); return; }
    submissionKey.current ||= crypto.randomUUID();
    setPending(true); setServerError("");
    try {
      const response = await fetch("/api/investor-registrations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fields, idempotencyKey: submissionKey.current, expectedVersion: draftVersion }) });
      const result = await response.json();
      if (!response.ok) {
        setServerError(result.message ?? "Unable to save. Your entries have been kept; try again.");
        if (result.errors) showErrors(result.errors);
        if (response.status === 401) setAccount(null);
        return;
      }
      if (typeof result.reference !== "string" || !result.reference.trim() || typeof result.status !== "string" || !result.status.trim()) { setServerError("The save could not be confirmed. Keep your entries and retry safely."); return; }
      setReceipt({ reference: result.reference, status: result.status }); setDirty(false); dirtyRef.current = false;
    } catch { setUncertain(true); setServerError("We could not confirm the result. Check the status before trying again. Your entries remain here."); }
    finally { setPending(false); }
  }
  const heading = useRef<HTMLHeadingElement>(null);
  const errorSummary = useRef<HTMLDivElement>(null);
  const moved = useRef(false);

  useEffect(() => {
    if (moved.current) heading.current?.focus();
    moved.current = true;
  }, [step]);

  function update(name: keyof InvestorFields, value: string) {
    setFields(current => ({ ...current, [name]: value })); setDirty(true); dirtyRef.current = true; submissionKey.current = "";
    setErrors(current => {
      const remaining = { ...current };
      delete remaining[name];
      if (name === "registeringAs") delete remaining.organisationName;
      if (name === "minimumInvestment") delete remaining.maximumInvestment;
      return remaining;
    });
  }
  function next() {
    const issues = validateInvestorFields(fields, step === 1 ? undefined : 0);
    setErrors(issues);
    if (Object.keys(issues).length) {
      requestAnimationFrame(() => errorSummary.current?.focus());
      return;
    }
    setStep(current => Math.min(2, current + 1));
  }
  function edit(target: number) {
    setErrors({});
    setStep(target);
  }
  function field(name: keyof InvestorFields, example: string, options: { inputMode?: "email" | "tel" | "decimal"; autoComplete?: string; multiline?: boolean; options?: readonly { value: string; label: string }[] } = {}) {
    return <RegistrationField key={name} name={name} label={labels[name]} value={fields[name]} maxLength={investorFieldLimits[name]} example={example} error={errors[name]} onChange={value => update(name, value)} {...options} />;
  }
  function displayValue(name: keyof InvestorFields) {
    if (name === "riskAcknowledged") return fields[name] === "true" ? "Acknowledged" : "Not acknowledged";
    if (name === "registeringAs") return registrationTypeOptions.find(option => option.value === fields[name])?.label;
    if (name === "investorCategory") return fields[name].split(",").map(value => investorCategoryOptions.find(option => option.value === value)?.label).filter(Boolean).join(", ");
    if (name === "minimumInvestment" || name === "maximumInvestment") return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(Number(fields[name]));
    return fields[name];
  }

  if (!resolved) return <div><p role="status">Loading your investor registration…</p>{serverError && <p role="alert">{serverError} <button type="button" className={styles.secondary} onClick={() => { setServerError(""); setResolutionAttempt(current => current + 1); }}>Retry</button></p>}</div>;
  if (receipt) return <div ref={receiptHeading}><InvestorConfirmation registration={receipt} /><SiteLink href="/app/investor">Open investor overview</SiteLink></div>;
  return <>
    {enabled && !account && <AccountAuth onAuthenticated={identity => { setResolved(false); setRestoring(true); setAccount(identity); setServerError(""); }} />}
    {enabled && account && !account.emailVerified && <EmailVerification onVerified={() => setAccount(current => current ? { ...current, emailVerified: true } : null)} />}
    {restorable && <div className={styles.availability}><p>A saved draft exists. Your entries from before sign-in are still here.</p><button type="button" className={styles.secondary} onClick={() => void loadSavedDraft()}>Load saved draft</button><button type="button" className={styles.secondary} onClick={() => setRestorable(null)}>Keep current entries</button></div>}
    <form className={styles.form} noValidate onSubmit={event => { event.preventDefault(); if (step < 2) next(); else void submit(); }}>
    {enabled ? <p className={styles.hint} role="note">Test environment</p> : <p role="note">You can prepare your profile. Submission is currently unavailable.</p>}
    {account && <p className={styles.hint}>Signed in as {account.email}.</p>}
    <ol className={styles.progress} aria-label="Investor registration progress">
      {steps.map((label, index) => <li key={label} aria-current={step === index ? "step" : undefined}><span aria-hidden="true">0{index + 1}</span><span>{label}</span></li>)}
    </ol>
    <h2 ref={heading} tabIndex={-1}>{steps[step]}</h2>
    {Object.keys(errors).length > 0 && <div ref={errorSummary} className={styles.errorSummary} role="alert" tabIndex={-1}>
      <strong>Check these details before continuing.</strong>
      <ul>{Object.entries(errors).map(([name, message]) => <li key={name}><a href={`#field-${name}`}>{labels[name as keyof InvestorFields]}: {message}</a></li>)}</ul>
    </div>}
    {step === 2 ? <div className={styles.review}>
      <dl>{(Object.keys(labels) as (keyof InvestorFields)[]).filter(name => name !== "organisationName" || fields.registeringAs === "organisation").map(name => <div key={name}><dt>{labels[name]}</dt><dd>{displayValue(name)}</dd></div>)}</dl>
      <label className={styles.checkbox}><input id="field-riskAcknowledged" type="checkbox" disabled={pending || restoring} checked={fields.riskAcknowledged === "true"} onChange={event => update("riskAcknowledged", String(event.target.checked))} /><span>I understand that opportunities involve risk and require my independent assessment. An expression of interest or budget announcement does not complete an investment.</span></label>
      <p>Submitting does not mean investor approval is complete. Public profile publication requires a separate consent process; this form does not publish a profile.</p>
      <p>Your typical investment range describes preferences, not committed capital. It is not added to public investment totals.</p>
    </div> : <fieldset className={styles.fields} key={step} disabled={pending || restoring}>
      <legend className="visually-hidden">{steps[step]}</legend>
      {step === 0 && <>
        {field("fullName", "Your full name", { autoComplete: "name" })}
        {field("email", "For example, investor@example.com", { inputMode: "email", autoComplete: "email" })}
        {field("phone", "Include country code where applicable, for example +91 98765 43210", { inputMode: "tel", autoComplete: "tel" })}
        {field("registeringAs", "Choose whether you are registering individually or for an organisation.", { options: registrationTypeOptions })}
        {fields.registeringAs === "organisation" && field("organisationName", "The name of the organisation you represent", { autoComplete: "organization" })}
        <fieldset className={styles.choiceGroup} id="field-investorCategory" aria-describedby="investorCategory-hint"><legend>Investor categories (required)</legend><p id="investorCategory-hint" className={styles.hint}>Choose one or more categories that describe your investor profile.</p>{investorCategoryOptions.map(option => <label key={option.value} className={styles.checkbox}><input id={`category-${option.value}`} type="checkbox" checked={fields.investorCategory.split(",").includes(option.value)} onChange={event => update("investorCategory", event.target.checked ? [...fields.investorCategory.split(",").filter(Boolean), option.value].join(",") : fields.investorCategory.split(",").filter(value => value !== option.value).join(","))} /><span>{option.label}</span></label>)}{errors.investorCategory && <p className={styles.error}>{errors.investorCategory}</p>}</fieldset>
      </>}
      {step === 1 && <>
        {field("sectors", "For example, fintech, healthtech or clean energy. Separate multiple interests with commas.", { multiline: true })}
        {field("stages", "For example, prototype, early revenue or growth. Separate multiple preferences with commas.", { multiline: true })}
        {field("minimumInvestment", "Typical minimum in INR without commas, for example 500000. Up to two decimal places.", { inputMode: "decimal" })}
        {field("maximumInvestment", "Typical maximum in INR without commas, for example 2500000. Must be at least the minimum.", { inputMode: "decimal" })}
        <p className={styles.hint}>These amounts are preferences, not a capital commitment.</p>
      </>}
    </fieldset>}
    <div className={styles.actions}>
      {step > 0 && <button type="button" disabled={pending || restoring} onClick={() => edit(step - 1)} className={styles.secondary}>{step === 2 ? "Edit preferences" : "Back"}</button>}
      {step === 2 ? <>
        <button type="button" disabled={pending || restoring} onClick={() => edit(0)} className={styles.secondary}>Edit profile</button>
        <button type="submit" disabled={!enabled || !account?.emailVerified || pending || restoring || uncertain} className={styles.primary} aria-describedby="investor-submission-status">{pending ? "Saving registration…" : enabled ? "Submit registration" : "Submit registration — unavailable"}</button>
      </> : <button type="button" disabled={pending || restoring} onClick={next} className={styles.primary}>{step === 1 ? "Review registration" : "Next"}</button>}
    </div>
    {enabled && account && <div className={styles.actions}><button type="button" className={styles.secondary} disabled={pending || restoring} onClick={() => void saveDraft()}>{pending ? "Saving…" : "Save draft"}</button><button type="button" className={styles.secondary} disabled={pending || restoring} onClick={() => void loadSavedDraft()}>Load saved draft</button></div>}
    {savedAt && <p role="status">Draft last saved: {savedAt} UTC.</p>}{restoring && <p role="status">Loading your saved draft…</p>}
    {uncertain && <button type="button" className={styles.secondary} disabled={pending} onClick={() => void reconcileSubmission()}>Check saved submission</button>}
    {serverError && <p role="alert" className={styles.error}>{serverError}</p>}
    <p id="investor-submission-status" className={styles.hint}>{enabled ? account ? "Save your draft to continue later. Verify your email before submitting." : "Complete the steps, then sign in above to submit without losing your entries." : investorSubmissionUnavailable}</p>
    {isPublicRouteAvailable("/privacy-policy") && <SiteLink href="/privacy-policy">Privacy Policy</SiteLink>}
  </form></>;
}
