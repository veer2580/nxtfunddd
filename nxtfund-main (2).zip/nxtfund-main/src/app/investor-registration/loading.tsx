export default function RegistrationLoading() {
  return <main id="main-content" tabIndex={-1} className="page-surface"><p role="status">Loading your investor registration…</p></main>;
}
