import SiteLink from "../components/site-link";
import styles from "../components/registration-confirmation.module.css";

// Supplied only after a durable backend commit; never construct receipts from form entries.
export type SavedInvestorReceipt = { reference: string; status: string };

export default function InvestorConfirmation({ registration }: { registration: SavedInvestorReceipt }) {
  if (!registration.reference.trim() || !registration.status.trim()) return null;
  return <section className={styles.confirmation} aria-labelledby="investor-received-heading">
    <h2 id="investor-received-heading" tabIndex={-1}>Registration received.</h2>
    <p>Your registration has been saved for review.</p>
    <dl className={styles.receipt}>
      <div><dt>Registration reference</dt><dd>{registration.reference}</dd></div>
      <div><dt>Current status</dt><dd>{registration.status}</dd></div>
    </dl>
    <h3>What comes next</h3>
    <p>Your profile and preferences will be reviewed. Any further verification requirements will be communicated through the review process. Submission does not mean verification or access approval is complete.</p>
    <div className={styles.actions}><SiteLink href="/" className={styles.action}>Back to Home</SiteLink><SiteLink href="/investors" className={styles.action}>Explore the investor pathway</SiteLink></div>
  </section>;
}
