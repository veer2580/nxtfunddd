import SiteHeader from "../components/site-header";
import styles from "./truevalue.module.css";

export default function TrueValueLoading() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.fallback}`}><div className={styles.container}><h1>TrueValue</h1><p role="status">Opening the TrueValue pathway…</p></div></main></>;
}
