"use client";

import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import TrueValueVisual from "./truevalue-visual";
import styles from "./truevalue.module.css";

export default function TrueValueError({ retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.fallback}`}>
    <div className={`${styles.container} ${styles.split}`}>
      <div>
        <h1>TrueValue is temporarily unavailable.</h1>
        <p>The page could not be opened. Try again or return to the homepage.</p>
        <div className={styles.actions}><button type="button" onClick={retry} className={styles.primaryAction}>Try again</button><SiteLink href="/" className={styles.textAction}>Back to Home</SiteLink></div>
      </div>
      <figure className={styles.visual}><TrueValueVisual kind="browse" /></figure>
    </div>
  </main></>;
}
