export default function TrueValueVisual({ kind }: { kind: "opportunity" | "browse" | "access" }) {
  return <svg viewBox="0 0 540 380" fill="none" aria-hidden="true" focusable="false">
    <g stroke="var(--ink)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {kind === "opportunity" && <>
        <path d="M35 331H506" opacity=".3" />
        <path d="M56 105h165l27 29h230v196H56Z" fill="var(--accent-yellow)" />
        <rect x="92" y="58" width="143" height="216" fill="var(--surface)" />
        <rect x="190" y="32" width="143" height="242" fill="var(--accent-mint)" />
        <rect x="288" y="82" width="143" height="192" fill="var(--surface)" />
        <path d="M115 99l12-21h69l13 21v59h-94ZM115 99h94M130 158v-32h24v32M178 121h15v15h-15" />
        <path d="m228 85 32-18 32 18v42l-32 18-32-18ZM228 85l32 18 32-18M260 103v42" />
        <path d="M312 115h59l23 23v69h-82ZM371 115v23h23M330 163h45M330 182h31" />
        <path d="M56 225h422v105H56Z" fill="var(--surface-yellow)" />
        <path d="M84 259h132M84 282h85" />
        <circle cx="351" cy="268" r="39" fill="var(--surface)" />
        <path d="M351 229v39h39a39 39 0 0 0-39-39Z" fill="var(--accent-mint)" />
        <path d="M427 53h66m-17-17 17 17-17 17" stroke="var(--brand)" strokeWidth="3" />
      </>}
      {kind === "browse" && <>
        <path d="M62 277h365v57H62Z" fill="var(--accent-yellow)" />
        <path d="M104 64h181l30 30v203H104ZM285 64v30h30" fill="var(--surface)" />
        <path d="M132 117h107M132 141h146M132 165h70M132 229h88" />
        <circle cx="340" cy="220" r="65" fill="var(--accent-mint)" />
        <circle cx="340" cy="220" r="43" />
        <path d="m387 267 57 57" strokeWidth="6" />
        <path d="M331 204c13-9 29 4 17 15-7 6-11 9-11 16m0 13v2" stroke="var(--brand)" strokeWidth="3" />
      </>}
      {kind === "access" && <>
        <rect x="54" y="102" width="174" height="193" fill="var(--surface)" />
        <path d="M80 134h111M80 158h73M80 218h104M80 242h62" />
        <rect x="303" y="102" width="174" height="193" fill="var(--accent-mint)" />
        <path d="M330 136h121M330 162h73" />
        <rect x="353" y="205" width="72" height="58" fill="var(--surface)" />
        <path d="M368 205v-17a21 21 0 0 1 42 0v17M389 231v12" />
        <path d="M228 198h75" stroke="var(--brand)" strokeDasharray="4 8" />
        <circle cx="265" cy="198" r="18" fill="var(--surface-yellow)" />
        <path d="M265 188v13m0 7v1" stroke="var(--brand)" />
      </>}
    </g>
  </svg>;
}

export function SellerStepVisual({ step }: { step: "share" | "review" | "request" | "approval" | "negotiate" }) {
  return <svg viewBox="0 0 180 130" fill="none" aria-hidden="true" focusable="false">
    <g stroke="var(--ink)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {step === "share" && <><path d="M31 108V26h76l24 24v58ZM107 26v24h24" fill="var(--surface)" /><path d="M51 66h48M51 82h35M135 89h29m-8-8 8 8-8 8" stroke="var(--brand)" /></>}
      {step === "review" && <><rect x="24" y="19" width="86" height="91" fill="var(--surface)" /><path d="M41 40h51M41 59h39" /><circle cx="112" cy="76" r="27" fill="var(--accent-mint)" /><path d="m132 98 25 23" stroke="var(--brand)" strokeWidth="4" /></>}
      {step === "request" && <><path d="M22 25h116v63H77l-27 25V88H22Z" fill="var(--surface)" /><path d="M43 47h71M43 65h43" /><circle cx="138" cy="92" r="22" fill="var(--accent-yellow)" /><path d="M138 80v24M126 92h24" stroke="var(--brand)" /></>}
      {step === "approval" && <><rect x="32" y="21" width="90" height="92" fill="var(--surface)" /><path d="M49 43h55M49 60h39M49 90h57" /><path d="m114 76 26-26 12 12-26 26-19 7ZM140 50l8-8 12 12-8 8" fill="var(--accent-yellow)" /></>}
      {step === "negotiate" && <><path d="M17 24h86v50H52L33 91V74H17ZM83 58h80v49h-15v17l-22-17H83Z" fill="var(--surface)" /><path d="M34 42h51M34 57h31M99 78h44M99 94h29" stroke="var(--brand)" /></>}
    </g>
  </svg>;
}
