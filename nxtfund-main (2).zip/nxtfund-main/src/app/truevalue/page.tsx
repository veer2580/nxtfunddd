import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import { isPublicRouteAvailable } from "../components/site-navigation";
import TrueValueSection from "./truevalue-section";
import TrueValueVisual, { SellerStepVisual } from "./truevalue-visual";
import TrueValueOpportunities from "./truevalue-opportunities";
import styles from "./truevalue.module.css";

export const metadata: Metadata = {
  title: "TrueValue",
  description: "Explore NxtFund’s intended pathway to sell or acquire a business, product, intellectual property or ownership stake. Opportunity browsing and seller submission are currently unavailable.",
};
const sellerSteps = [
  { kind: "share", title: "Share what you’re selling", copy: "The intended entry process will capture the opportunity and supporting information privately." },
  { kind: "review", title: "Platform review", copy: "Public previews will use approved anonymous information." },
  { kind: "request", title: "Buyer access requests", copy: "Verified buyers will be able to request fuller information when the access process is available." },
  { kind: "approval", title: "Seller approval", copy: "Seller approval will be required before private information is shared." },
  { kind: "negotiate", title: "Direct negotiation", copy: "Buyers and sellers negotiate and agree transactions directly." },
] as const;
const sellerEntry = "/truevalue/list-your-business";

export default function TrueValue() {
  return <>
    <SiteHeader />
    <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
      <section className={styles.hero} aria-labelledby="truevalue-page-heading">
        <div className={`${styles.container} ${styles.split}`}>
          <div>
            <p className={styles.eyebrow}>TRUEVALUE</p>
            <h1 id="truevalue-page-heading">Where Businesses Find Their Right Buyer</h1>
            <p>Explore a pathway to sell or acquire a business, product, intellectual property or ownership stake.</p>
            <div className={styles.actions}>
              <a href="#opportunities" className={styles.primaryAction}>For Buyers <span aria-hidden="true">↓</span></a>
              <a href="#seller-pathway" className={styles.secondaryAction}>For Sellers <span aria-hidden="true">↓</span></a>
            </div>
            <p className={styles.note}>This is the intended pathway. Buying, selling and access requests are not yet operational.</p>
          </div>
          <figure className={styles.visual}><TrueValueVisual kind="opportunity" /></figure>
        </div>
      </section>
      <TrueValueSection id="opportunities">
        <p className={styles.eyebrow}>FOR BUYERS</p>
        <h2 id="opportunities-heading">Explore opportunities.</h2>
        <TrueValueOpportunities />
      </TrueValueSection>
      <TrueValueSection id="buyer-access" className={styles.access}>
        <div className={styles.split}>
          <figure className={styles.visual}><TrueValueVisual kind="access" /></figure>
          <div>
            <p className={styles.eyebrow}>PUBLIC PREVIEWS, CONTROLLED ACCESS</p>
            <h2 id="buyer-access-heading">More information, with permission.</h2>
            <p>Planned public previews will include sector, an approved anonymous summary, an asking-price range and what’s being sold.</p>
            <p>Business names, logos, identifying photos, financial documents and contact information are intended to remain private. Fuller information will require authentication, verification and seller approval.</p>
            <p className={styles.note}>These controls are planned. Access requests and private-detail access are not yet available.</p>
          </div>
        </div>
      </TrueValueSection>
      <TrueValueSection id="seller-pathway">
        <p className={styles.eyebrow}>FOR SELLERS</p>
        <h2 id="seller-pathway-heading">Introduce the next chapter.</h2>
        <p>Identifying details are intended to be withheld from public previews. Buyers and sellers agree transactions directly.</p>
        <ol className={styles.steps}>
          {sellerSteps.map((step, index) => <li key={step.kind}>
            <div className={styles.stepVisual}><SellerStepVisual step={step.kind} /></div>
            <span className={styles.number} aria-hidden="true">0{index + 1}</span>
            <h3>{step.title}</h3><p>{step.copy}</p>
          </li>)}
        </ol>
        <p id="seller-availability" className={styles.note}>This sequence describes the intended process. You can prepare a seller entry for review. Saving submissions, verification and buyer access requests are currently unavailable.</p>
        <div className={styles.actions}>
          {isPublicRouteAvailable(sellerEntry) ? <SiteLink href={sellerEntry} className={styles.primaryAction}>Start a listing</SiteLink>
            : <button type="button" disabled className={styles.primaryAction} aria-describedby="seller-availability">Start a listing — unavailable</button>}
        </div>
      </TrueValueSection>
    </main>
  </>;
}
