"use client";

import { useEffect, type ReactNode } from "react";
import { useScrollReveal } from "../components/use-scroll-reveal";
import styles from "./truevalue.module.css";

export default function TrueValueSection({ id, children, className = "" }: { id: string; children: ReactNode; className?: string }) {
  const { ref, entered } = useScrollReveal<HTMLElement>(true);
  useEffect(() => {
    let cancelled = false;
    let frame = 0;
    // The loading boundary can restore a hash before the full section exists.
    // Align once after hydration and font layout, without changing history.
    void document.fonts.ready.then(() => {
      if (cancelled) return;
      frame = requestAnimationFrame(() => {
        if (window.location.hash === `#${id}`) {
          ref.current?.scrollIntoView({ behavior: "instant", block: "start" });
        }
      });
    });
    return () => {
      cancelled = true;
      cancelAnimationFrame(frame);
    };
  }, [id, ref]);
  return <section id={id} ref={ref} aria-labelledby={`${id}-heading`} className={`${styles.section} ${className}`} data-entered={entered}>
    <div className={styles.container}>{children}</div>
  </section>;
}
