import { getPublicOpportunityState } from "@/lib/truevalue/public-opportunities";
import TrueValueVisual from "./truevalue-visual";
import styles from "./truevalue.module.css";

export default function TrueValueOpportunities() {
  const state = getPublicOpportunityState();
  return <div data-opportunity-state={state.status}>
    <p id="opportunities-availability" className={styles.note}>Opportunity browsing and filters are currently unavailable.</p>
    <fieldset disabled aria-describedby="opportunities-availability" className={styles.filters}>
      <legend>Opportunity filters — unavailable</legend>
      <div className={styles.filterField}>
        <label htmlFor="opportunity-sector">Sector</label>
        <select id="opportunity-sector" defaultValue=""><option value="">Sectors unavailable</option></select>
      </div>
      <div className={styles.filterField}>
        <label htmlFor="opportunity-type">What’s available</label>
        <select id="opportunity-type" defaultValue="">
          <option value="">Unavailable</option>
          {["Full ownership", "Majority stake", "Minority stake", "Product", "IP"].map(type => <option key={type} value={type}>{type}</option>)}
        </select>
      </div>
      <div className={styles.filterField}>
        <label htmlFor="opportunity-minimum">Minimum asking price (INR)</label>
        <input id="opportunity-minimum" type="text" inputMode="decimal" placeholder="Unavailable" />
      </div>
      <div className={styles.filterField}>
        <label htmlFor="opportunity-maximum">Maximum asking price (INR)</label>
        <input id="opportunity-maximum" type="text" inputMode="decimal" placeholder="Unavailable" />
      </div>
      <button type="button" className={styles.secondaryAction}>Clear filters</button>
    </fieldset>
    <div className={styles.emptyState}>
      <div className={styles.emptyVisual}><TrueValueVisual kind="browse" /></div>
      <div>
        <h3>Opportunities aren’t available to browse yet.</h3>
        <p>You can explore the intended buyer and seller pathways while opportunity browsing remains unavailable.</p>
        <a href="#buyer-access" className={styles.textAction}>How access is intended to work <span aria-hidden="true">↓</span></a>
      </div>
    </div>
  </div>;
}
