"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import RegistrationField from "../../components/registration-field";
import SiteLink from "../../components/site-link";
import { isPublicRouteAvailable } from "../../components/site-navigation";
import { financialOptions, initialSellerFields, saleOptions, sellerLabels, sellerLimits, validateSellerFields, type SellerFields, type SellerErrors } from "@/lib/truevalue/seller-entry/validation";
import styles from "../../components/registration.module.css";

const steps = ["Seller and business", "What’s available", "Supporting information", "Review"];
const groups: (keyof SellerFields)[][] = [
  ["sellerName", "email", "phone", "sellerRole", "businessName", "sector", "location", "description"],
  ["saleType", "stake", "askingPrice", "included"],
  ["financialAvailability", "revenue", "profit", "period", "financialExplanation"],
];
export default function SellerForm() {
  const [fields, setFields] = useState(initialSellerFields);
  const [step, setStep] = useState(0);
  const [errors, setErrors] = useState<SellerErrors>({});
  const heading = useRef<HTMLHeadingElement>(null);
  const errorSummary = useRef<HTMLDivElement>(null);
  const moved = useRef(false);
  useEffect(() => {
    if (moved.current) heading.current?.focus();
    moved.current = true;
  }, [step]);
  function update(name: keyof SellerFields, value: string) {
    setFields(current => ({ ...current, [name]: value }));
    setErrors(name === "publicDescription" ? validateSellerFields({ ...fields, [name]: value }, 3) : {});
  }
  function next() {
    const issues = validateSellerFields(fields, step);
    setErrors(issues);
    if (Object.keys(issues).length) {
      requestAnimationFrame(() => errorSummary.current?.focus());
      return;
    }
    setStep(current => Math.min(3, current + 1));
  }
  function edit(target: number) { setErrors({}); setStep(target); }
  function field(name: keyof SellerFields, example: string, options: {
    inputMode?: "email" | "tel" | "decimal"; autoComplete?: string; multiline?: boolean;
    required?: boolean; options?: readonly { value: string; label: string }[];
  } = {}) {
    return <RegistrationField key={name} name={name} label={sellerLabels[name]} value={fields[name]} maxLength={sellerLimits[name]} example={example} error={errors[name]} onChange={value => update(name, value)} {...options} />;
  }
  function visible(name: keyof SellerFields) {
    if (name === "stake") return ["majority", "minority"].includes(fields.saleType);
    if (["revenue", "profit", "period"].includes(name)) return fields.financialAvailability === "available";
    if (name === "financialExplanation") return fields.financialAvailability === "unavailable";
    return true;
  }
  function display(name: keyof SellerFields) {
    if (name === "saleType") return saleOptions.find(option => option.value === fields.saleType)?.label;
    if (name === "financialAvailability") return financialOptions.find(option => option.value === fields.financialAvailability)?.label;
    return fields[name] || "Not provided";
  }
  return <form className={styles.form} noValidate onSubmit={event => { event.preventDefault(); if (step < 3) next(); }}>
    <div className={styles.availability} role="note">
      <strong>Submission unavailable</strong>
      <p>You can complete all four steps and review your opportunity. Seller listings cannot be saved or published yet.</p>
      <p>Entries stay in this tab’s memory. Refreshing or leaving clears them; nothing is sent to the server.</p>
    </div>
    <ol className={styles.progress} style={{ "--registration-steps": 4 } as CSSProperties} aria-label="Seller entry progress">
      {steps.map((label, index) => <li key={label} aria-current={step === index ? "step" : undefined}><span aria-hidden="true">0{index + 1}</span><span>{label}</span></li>)}
    </ol>
    <h2 ref={heading} tabIndex={-1}>{steps[step]}</h2>
    {Object.keys(errors).length > 0 && <div ref={errorSummary} className={styles.errorSummary} role="alert" tabIndex={-1}>
      <strong>Check these details before continuing.</strong>
      <ul>{Object.entries(errors).map(([name, message]) => <li key={name}><a href={`#field-${name}`}>{sellerLabels[name as keyof SellerFields]}: {message}</a></li>)}</ul>
    </div>}
    {step === 3 ? <div className={styles.review}>
      {groups.map((names, index) => <section key={steps[index]} aria-label={steps[index]}>
        <h3>{steps[index]}</h3>
        <dl>{names.filter(visible).map(name => <div key={name}><dt>{sellerLabels[name]}</dt><dd>{display(name)}</dd></div>)}</dl>
        <button type="button" className={styles.secondary} onClick={() => edit(index)}>Edit {steps[index].toLowerCase()}</button>
      </section>)}
      <h3>Proposed anonymous public preview</h3>
      <p>Do not include business or personal names, contact details, websites, exact addresses or other identifying information. Removing contact details alone does not ensure anonymity; platform review will be required.</p>
      {field("publicDescription", "Describe the sector, offering and opportunity without identifying the business or seller.", { multiline: true })}
      <dl aria-label="Proposed public preview">
        <div><dt>Sector</dt><dd>{fields.sector}</dd></div>
        <div><dt>What’s available</dt><dd>{display("saleType")}</dd></div>
        <div><dt>Proposed asking price (INR)</dt><dd>{fields.askingPrice}</dd></div>
        <div><dt>Anonymous description</dt><dd>{fields.publicDescription || "Add your proposed anonymous description above."}</dd></div>
      </dl>
      <p>This is a proposed preview, not a published listing. Seller identity, business name, financial information and documents are intended to remain private. Nothing is saved by this form.</p>
    </div> : <fieldset className={styles.fields} key={step}>
      <legend className="visually-hidden">{steps[step]}</legend>
      {step === 0 && <>
        {field("sellerName", "Your full name", { autoComplete: "name" })}
        {field("email", "For example, seller@example.com", { inputMode: "email", autoComplete: "email" })}
        {field("phone", "Include country code where applicable, for example +91 98765 43210", { inputMode: "tel", autoComplete: "tel" })}
        {field("sellerRole", "For example, owner, founder or authorised representative")}
        {field("businessName", "Private business name; do not repeat it in the public description", { autoComplete: "organization" })}
        {field("sector", "For example, manufacturing or software")}
        {field("location", "City, state and country; this field is private")}
        {field("description", "Describe the business and its offering. This field is private.", { multiline: true })}
      </>}
      {step === 1 && <>
        {field("saleType", "Choose what you are offering.", { options: saleOptions })}
        {visible("stake") && field("stake", "Percentage with up to two decimal places; majority is above 50%, minority is up to 50%.", { inputMode: "decimal" })}
        {field("askingPrice", "INR without commas, for example 2500000. Up to two decimal places.", { inputMode: "decimal" })}
        {field("included", "Describe the assets, rights or ownership included, without assuming a legal agreement is final.", { multiline: true })}
      </>}
      {step === 2 && <>
        {field("financialAvailability", "Use information you have; do not invent figures.", { options: financialOptions })}
        {fields.financialAvailability === "available" ? <>
          {field("revenue", "Optional if profit information is provided. INR without commas; zero is allowed.", { inputMode: "decimal", required: false })}
          {field("profit", "Optional if revenue is provided. Use a negative INR amount for a loss.", { inputMode: "decimal", required: false })}
          {field("period", "For example, financial year 2025–26 or April–September 2026")}
        </> : field("financialExplanation", "Explain why figures are unavailable or what information could be provided later.", { multiline: true })}
        <div className={styles.field}>
          <label htmlFor="seller-documents">Optional supporting documents</label>
          <input id="seller-documents" type="file" disabled aria-describedby="seller-documents-status" />
          <p id="seller-documents-status" className={styles.hint}>Attachments are currently unavailable. You can prepare and review this form without documents.</p>
        </div>
      </>}
    </fieldset>}
    <div className={styles.actions}>
      {step > 0 && <button type="button" onClick={() => edit(step - 1)} className={styles.secondary}>Back</button>}
      {step === 3 ? <button type="submit" disabled className={styles.primary} aria-describedby="seller-submission-status">Submit for review — unavailable</button>
        : <button type="button" onClick={next} className={styles.primary}>{step === 2 ? "Review opportunity" : "Next"}</button>}
    </div>
    <p id="seller-submission-status" className={styles.hint}>Seller submission is currently unavailable. No listing has been saved or published.</p>
    <SiteLink href="/truevalue">Back to TrueValue</SiteLink>
    {isPublicRouteAvailable("/privacy-policy") && <SiteLink href="/privacy-policy">Privacy Policy</SiteLink>}
  </form>;
}
