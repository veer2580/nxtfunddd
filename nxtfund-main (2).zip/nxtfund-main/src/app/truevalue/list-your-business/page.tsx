import type { Metadata } from "next";
import SiteHeader from "../../components/site-header";
import TrueValueVisual from "../truevalue-visual";
import SellerForm from "./seller-form";
import styles from "../../components/registration.module.css";

export const metadata: Metadata = {
  title: "List Your Business",
  description: "Prepare your business opportunity for TrueValue review. Seller submission and document uploads are currently unavailable.",
};
export default function SellerEntryPage() {
  return <>
    <SiteHeader />
    <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
      <div className={styles.container}>
        <div className={styles.introduction}>
          <p className={styles.eyebrow}>TRUEVALUE · FOR SELLERS</p>
          <h1>List Your Business</h1>
          <p>Tell us what you’re offering and how you’d like to move forward.</p>
        </div>
        <div className={styles.layout}>
          <aside className={styles.aside}>
            <div className={styles.visual}><TrueValueVisual kind="opportunity" /></div>
            <h2>Prepare a considered opportunity.</h2>
            <p>Submission is intended for review, not immediate publication. Buyers and sellers negotiate and agree transactions directly.</p>
          </aside>
          <SellerForm />
        </div>
      </div>
    </main>
  </>;
}
