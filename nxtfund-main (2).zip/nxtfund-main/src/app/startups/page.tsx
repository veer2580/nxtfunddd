import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import OpportunityIllustration from "../components/opportunity-illustration";
import { registrationRoutes } from "../components/site-navigation";
import StartupSection from "./startup-section";
import StartupVisual, { StepIcon } from "./startup-visual";
import StartupPathway from "./startup-pathway";
import StartupFaq from "./startup-faq";
import styles from "./startups.module.css";

export const metadata: Metadata = {
  title: "For Startups",
  description: "Explore NxtFund’s intended startup pathway, from application preparation and due diligence to pitching and direct investor conversations.",
};

const documents = ["Pitch deck", "Business plan", "Founder/team details", "Financial information", "Funding ask and proposed use of funds"];
const benefits = [
  { kind: "investors", title: "Access across six investor categories.", copy: "VCs, HNIs/UHNIs, angels, strategic investors, global investor partners and family offices." },
  { kind: "diligence", title: "Structured verification before investor introductions.", copy: "A review of financials, legal standing and market claims beyond your pitch deck." },
  { kind: "grants", title: "Government grant support where eligible.", copy: "Explore support based on the requirements of relevant government schemes." },
] as const;

function ApplicationAction({ descriptionId }: { descriptionId: string }) {
  return <SiteLink href={registrationRoutes.startup} aria-describedby={descriptionId} className={styles.primaryAction}>Apply for Funding</SiteLink>;
}

export default function Startups() {
  return (
    <>
      <SiteHeader />
      <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
        <section className={styles.hero} aria-labelledby="startup-heading">
          <div className={`${styles.container} ${styles.split}`}>
            <div>
              <p className={styles.eyebrow}>FOR STARTUPS</p>
              <h1 id="startup-heading">Funding for Startups, Done Right.</h1>
              <p>Give your startup a structured path to investor conversations — from application and due diligence to pitching and direct connections.</p>
              <div className={styles.actions}>
                <ApplicationAction descriptionId="hero-availability" />
                <a href="#startup-process" className={styles.textAction}>See the process <span aria-hidden="true">↓</span></a>
              </div>
              <p id="hero-availability" className={styles.note}>Open the form to prepare your application. Submission is currently unavailable.</p>
            </div>
            <div className={styles.heroVisual}><StartupVisual kind="funding" /></div>
          </div>
        </section>

        <StartupPathway />

        <StartupSection id="startup-documents" className={styles.documentsSection}>
          <div className={styles.split}>
            <div className={styles.documentVisual}><StartupVisual kind="documents" /></div>
            <div>
              <p className={styles.eyebrow}>PREPARE YOUR APPLICATION</p>
              <h2 id="startup-documents-heading">Bring the details that matter.</h2>
              <ul className={styles.checklist}>
                {documents.map(document => <li key={document}><span aria-hidden="true">✓</span>{document}</li>)}
              </ul>
              <p className={styles.note}>Additional documents may be requested during review. This information page does not collect or upload documents.</p>
            </div>
          </div>
        </StartupSection>

        <StartupSection id="startup-benefits">
          <p className={styles.eyebrow}>WHY APPLY</p>
          <h2 id="startup-benefits-heading">A clearer basis for the conversation.</h2>
          <ul className={styles.benefits}>
            {benefits.map(benefit => (
              <li key={benefit.kind}>
                <div className={styles.benefitVisual}><OpportunityIllustration kind={benefit.kind} /></div>
                <h3>{benefit.title}</h3>
                <p>{benefit.copy}</p>
              </li>
            ))}
          </ul>
        </StartupSection>

        <StartupFaq />

        <StartupSection id="startup-next-step" className={styles.closing}>
          <div className={styles.closingLayout}>
            <div className={styles.closingVisual}><StepIcon kind="connection" /></div>
            <div>
              <p className={styles.eyebrow}>YOUR NEXT STEP</p>
              <h2 id="startup-next-step-heading">Get your startup ready.</h2>
              <p id="closing-availability">You can prepare your information in the application form. Submission is currently unavailable.</p>
              <div className={styles.actions}>
                <ApplicationAction descriptionId="closing-availability" />
                <a href="#startup-documents" className={styles.textAction}>Review the checklist <span aria-hidden="true">↑</span></a>
              </div>
            </div>
          </div>
        </StartupSection>
      </main>
    </>
  );
}
