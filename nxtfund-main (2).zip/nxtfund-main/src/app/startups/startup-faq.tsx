import StartupSection from "./startup-section";
import StartupVisual from "./startup-visual";
import styles from "./startups.module.css";

const questions = [
  { question: "Does applying guarantee funding?", answer: "No. Funding decisions and terms are agreed by individual investors and founders." },
  { question: "How long does review take?", answer: "Timing depends on application completeness and review needs." },
  { question: "Can I explore government grants?", answer: "Support depends on the eligibility requirements of relevant schemes." },
  { question: "What should I prepare?", answer: "Your pitch, business information, team details, financials and proposed funding use." },
];

export default function StartupFaq() {
  return (
    <StartupSection id="startup-faq">
      <div className={styles.faqLayout}>
        <div>
          <p className={styles.eyebrow}>COMMON QUESTIONS</p>
          <h2 id="startup-faq-heading">Before you take the next step.</h2>
          <div className={styles.faqVisual}><StartupVisual kind="questions" /></div>
        </div>
        <div className={styles.questions}>
          {questions.map(({ question, answer }) => (
            <details key={question}>
              <summary>{question}<span aria-hidden="true" className={styles.accordionMark} /></summary>
              <p>{answer}</p>
            </details>
          ))}
        </div>
      </div>
    </StartupSection>
  );
}
