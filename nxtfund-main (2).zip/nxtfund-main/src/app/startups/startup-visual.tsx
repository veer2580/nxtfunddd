export type StepKind = "apply" | "screening" | "diligence" | "pitch" | "connection";

export function StepIcon({ kind }: { kind: StepKind }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" aria-hidden="true" focusable="false">
      <g stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        {kind === "apply" && <><path d="M16 8h24l8 8v40H16ZM40 8v10h8M24 28h16M24 36h16M24 44h10" /><path d="m30 53 6-6 6 6" stroke="var(--brand)" /></>}
        {kind === "screening" && <><path d="M10 13h44L37 33v17l-10 5V33Z" fill="var(--accent-mint)" /><path d="M19 22h26" stroke="var(--brand)" /></>}
        {kind === "diligence" && <><circle cx="27" cy="27" r="17" /><path d="m39 39 15 15M18 27l6 6 12-13" stroke="var(--brand)" strokeWidth="2" /></>}
        {kind === "pitch" && <><path d="M10 12h44v31H10ZM32 43v11M22 56l10-8 10 8M17 34l9-8 8 4 12-11" /><path d="M42 19h4v4" stroke="var(--brand)" /></>}
        {kind === "connection" && <><circle cx="13" cy="32" r="9" /><circle cx="51" cy="32" r="9" /><path d="M22 32h20m-7-7 7 7-7 7" stroke="var(--brand)" strokeWidth="2" /></>}
      </g>
    </svg>
  );
}

export default function StartupVisual({ kind }: { kind: "funding" | "documents" | "questions" }) {
  return (
    <svg viewBox="0 0 560 360" fill="none" aria-hidden="true" focusable="false">
      {kind === "funding" ? <>
        <circle cx="360" cy="180" r="136" fill="var(--accent-mint)" />
        <path d="M55 297h455M280 295v-57h67v-63h67v-63h75" stroke="var(--ink)" strokeWidth="2" />
        <path d="M303 208 453 66m-34 0h34v34" stroke="var(--brand)" strokeWidth="3" />
        <rect x="67" y="89" width="170" height="208" fill="white" stroke="var(--ink)" strokeWidth="2" />
        <rect x="82" y="69" width="170" height="208" fill="var(--accent-yellow)" stroke="var(--ink)" strokeWidth="2" />
        <path d="M106 104h115M106 124h81M106 170h115M106 192h92M106 214h115" stroke="var(--ink)" strokeWidth="2" />
        <circle cx="360" cy="173" r="29" fill="white" stroke="var(--ink)" strokeWidth="2" />
        <path d="m347 173 9 9 18-20" stroke="var(--brand)" strokeWidth="3" />
      </> : kind === "documents" ? <>
        <rect x="108" y="48" width="242" height="266" fill="var(--accent-mint)" stroke="var(--ink)" strokeWidth="2" />
        <path d="M134 30h168l65 65v201H134Z" fill="white" stroke="var(--ink)" strokeWidth="2" />
        <path d="M302 30v65h65M185 133h127M185 181h102M185 229h127" stroke="var(--ink)" strokeWidth="2" />
        <path d="m151 129 8 8 15-18m-23 58 8 8 15-18m-23 58 8 8 15-18" stroke="var(--brand)" strokeWidth="3" />
        <circle cx="384" cy="254" r="51" fill="var(--accent-yellow)" stroke="var(--ink)" strokeWidth="2" />
        <path d="M364 254h40m-20-20v40" stroke="var(--brand)" strokeWidth="3" />
      </> : <>
        <circle cx="280" cy="180" r="133" fill="var(--accent-mint)" />
        <path d="M125 73h243v146H234l-48 37v-37h-61Z" fill="white" stroke="var(--ink)" strokeWidth="2" />
        <path d="M278 241h142V135h-35M376 241l37 35v-35" stroke="var(--ink)" strokeWidth="2" />
        <path d="M228 121c0-28 42-29 42-3 0 17-20 18-20 37M250 174v3" stroke="var(--brand)" strokeWidth="5" strokeLinecap="round" />
      </>}
    </svg>
  );
}
