import SiteLink from "../components/site-link";
import OpportunityIllustration from "../components/opportunity-illustration";
import StartupSection from "./startup-section";
import { StepIcon, type StepKind } from "./startup-visual";
import styles from "./startups.module.css";

const steps: { kind: StepKind; title: string; copy: string }[] = [
  { kind: "apply", title: "Apply", copy: "Share your pitch deck, business plan, financials and founder details." },
  { kind: "screening", title: "Screening", copy: "Review of your sector, stage and funding ask." },
  { kind: "diligence", title: "Due diligence", copy: "Review of financials, legal standing and market claims." },
  { kind: "pitch", title: "Pitch round", copy: "Present to a relevant investor panel." },
  { kind: "connection", title: "Direct connection", copy: "Discuss investment terms directly with interested investors." },
];

export default function StartupPathway() {
  return (
    <StartupSection id="startup-process">
      <div className={styles.sectionIntro}>
        <p className={styles.eyebrow}>THE STARTUP PATHWAY</p>
        <h2 id="startup-process-heading">From your pitch to a direct conversation.</h2>
        <p className={styles.note}>These steps describe the intended process. The application form is available for preparation; submission is currently unavailable.</p>
      </div>
      <ol className={styles.journey}>
        {steps.map((step, index) => (
          <li key={step.kind}>
            <span className={styles.number} aria-hidden="true">0{index + 1}</span>
            <StepIcon kind={step.kind} />
            <div>
              <h3>{step.title}</h3>
              <p>{step.copy}</p>
              {step.kind === "diligence" && <SiteLink href="/due-diligence" className={styles.textAction}>Explore due diligence <span aria-hidden="true">↗</span></SiteLink>}
            </div>
          </li>
        ))}
      </ol>
      <aside className={styles.grants} aria-labelledby="grants-heading">
        <div className={styles.grantVisual}><OpportunityIllustration kind="grants" /></div>
        <div>
          <p className={styles.eyebrow}>AN OPTIONAL PATHWAY</p>
          <h3 id="grants-heading">Explore government grant support.</h3>
          <p>Support depends on the eligibility requirements of relevant schemes. This is separate from the investor pathway and does not guarantee a grant.</p>
        </div>
      </aside>
    </StartupSection>
  );
}
