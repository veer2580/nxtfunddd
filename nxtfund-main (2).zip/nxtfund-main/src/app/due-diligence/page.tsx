import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import { registrationRoutes } from "../components/site-navigation";
import DiligenceSection from "./diligence-section";
import DiligenceVisual, { ReviewAreaVisual } from "./diligence-visual";
import styles from "./due-diligence.module.css";

export const metadata: Metadata = {
  title: "Our Due Diligence Process",
  description: "Explore NxtFund’s intended due-diligence process: financial, legal, founder, market and reference checks, and the information founders should prepare.",
};
const reviewAreas = [
  { kind: "financial", title: "Financial verification", description: "Review financial information and projections for consistency and supporting evidence." },
  { kind: "legal", title: "Legal checks", description: "Review incorporation, compliance information, existing agreements and disclosed liabilities." },
  { kind: "founder", title: "Founder background", description: "Review founder history and prior ventures." },
  { kind: "market", title: "Market validation", description: "Assess evidence supporting market, customer and traction claims." },
  { kind: "references", title: "Reference checks", description: "Seek relevant customer, partner or prior-investor references where appropriate." },
] as const;
const preparation = ["Incorporation documents, where applicable", "Financial statements or available financial information", "Ownership/cap table information", "Existing material agreements", "Evidence supporting customer and traction claims"];

export default function DueDiligence() {
  return <>
    <SiteHeader />
    <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
      <section className={styles.hero} aria-labelledby="diligence-heading">
        <div className={`${styles.container} ${styles.split}`}>
          <div>
            <p className={styles.eyebrow}>DUE DILIGENCE</p>
            <h1 id="diligence-heading">Our Due Diligence Process</h1>
            <p>A pitch starts the conversation. Structured review helps founders and investors assess the information behind it.</p>
            <p className={styles.note}>This is the intended process. Review workflows and summaries are not yet available.</p>
            <div className={styles.actions}>
              <a href="#review-areas" className={styles.textAction}>Explore the review areas <span aria-hidden="true">↓</span></a>
              <a href="#founder-preparation" className={styles.textAction}>What to prepare <span aria-hidden="true">↓</span></a>
            </div>
          </div>
          <figure className={styles.visual}><DiligenceVisual kind="review" /></figure>
        </div>
      </section>
      <DiligenceSection id="review-areas">
        <p className={styles.eyebrow}>FIVE REVIEW AREAS</p>
        <h2 id="review-areas-heading">A closer look at the information that matters.</h2>
        <ol className={styles.reviewAreas}>
          {reviewAreas.map((area, index) => <li key={area.kind}>
            <span className={styles.number} aria-hidden="true">0{index + 1}</span>
            <div className={styles.areaVisual}><ReviewAreaVisual area={area.kind} /></div>
            <div><h3>{area.title}</h3><p>{area.description}</p></div>
          </li>)}
        </ol>
      </DiligenceSection>
      <DiligenceSection id="founder-preparation" className={styles.preparation}>
        <div className={styles.split}>
          <figure className={styles.visual}><DiligenceVisual kind="documents" /></figure>
          <div>
            <p className={styles.eyebrow}>WHAT FOUNDERS SHOULD PREPARE</p>
            <h2 id="founder-preparation-heading">Bring the evidence behind your story.</h2>
            <ul className={styles.checklist}>{preparation.map(item => <li key={item}><span aria-hidden="true">↗</span>{item}</li>)}</ul>
            <p className={styles.note}>Required documents depend on the startup’s stage and review needs. This page does not collect documents.</p>
          </div>
        </div>
      </DiligenceSection>
      <DiligenceSection id="investor-expectations">
        <div className={styles.split}>
          <div>
            <p className={styles.eyebrow}>WHAT INVESTORS CAN EXPECT</p>
            <h2 id="investor-expectations-heading">A clearer picture, with questions made visible.</h2>
            <p>The intended review summary describes the information reviewed, supporting evidence, outstanding questions and identified concerns.</p>
            <p className={styles.note}>Review summaries are not yet available. This describes their intended structure, rather than a completed report or review outcome.</p>
            <p>Review is not a guarantee of accuracy, funding or returns.</p>
          </div>
          <figure className={`${styles.visual} ${styles.summaryVisual}`}><DiligenceVisual kind="summary" /></figure>
        </div>
      </DiligenceSection>
      <DiligenceSection id="diligence-next-step" className={styles.closing}>
        <h2 id="diligence-next-step-heading">Choose your next step.</h2>
        <p>Due diligence supports assessment; investors remain responsible for their own investment decisions.</p>
        <div className={styles.nextActions}>
          <div><p className={styles.eyebrow}>FOR FOUNDERS</p><SiteLink href={registrationRoutes.startup} className={styles.primaryAction}>Prepare your application</SiteLink></div>
          <div><p className={styles.eyebrow}>FOR INVESTORS</p><SiteLink href={registrationRoutes.investor} className={styles.primaryAction}>Join the investor pathway</SiteLink></div>
        </div>
        <p className={styles.note}>Both forms are available for preparation and review. Final submission is currently unavailable.</p>
      </DiligenceSection>
    </main>
  </>;
}
