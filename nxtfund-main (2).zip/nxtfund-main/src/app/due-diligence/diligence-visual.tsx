type ReviewArea = "financial" | "legal" | "founder" | "market" | "references";

export function ReviewAreaVisual({ area }: { area: ReviewArea }) {
  return <svg viewBox="0 0 180 130" fill="none" aria-hidden="true" focusable="false">
    <g stroke="var(--ink)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {area === "financial" && <>
        <rect x="27" y="18" width="92" height="96" fill="var(--surface)" />
        <path d="M42 36H96M42 48H77M44 96V78H60V96M71 96V63H87V96M98 96V53H114V96" />
        <circle cx="122" cy="81" r="25" fill="var(--accent-yellow)" /><path d="M122 70v22m-7-16h10c8 0 8 11 0 11h-10" stroke="var(--brand)" />
      </>}
      {area === "legal" && <>
        <path d="M29 108V20H108L130 43V108ZM108 20v23h22M46 58h60M46 74h47M46 90h35" fill="var(--surface)" />
        <path d="M125 58h23v43h-23ZM120 104h33" stroke="var(--brand)" />
      </>}
      {area === "founder" && <>
        <path d="M26 104H156M47 104V83M91 104V69M137 104V46" />
        <circle cx="47" cy="65" r="17" fill="var(--accent-mint)" />
        <circle cx="91" cy="49" r="17" fill="var(--surface)" />
        <circle cx="137" cy="27" r="17" fill="var(--accent-yellow)" />
        <path d="M62 60 76 54M106 42l15-9" stroke="var(--brand)" />
      </>}
      {area === "market" && <>
        <path d="M24 111V39H113V111M24 39l15-20h59l15 20M38 111V68H67V111M81 59h17v20H81Z" fill="var(--surface)" />
        <circle cx="122" cy="67" r="27" fill="var(--accent-mint)" />
        <path d="m143 87 23 24M110 68h24M122 56v24" stroke="var(--brand)" />
      </>}
      {area === "references" && <>
        <path d="M23 25h86v51H53L35 93V76H23Z" fill="var(--surface)" />
        <path d="M86 58h71v50h-13v16l-20-16H86Z" fill="var(--accent-yellow)" />
        <path d="M38 43h55M38 58h36M102 76h38M102 91h28" stroke="var(--brand)" />
      </>}
    </g>
  </svg>;
}

export default function DiligenceVisual({ kind }: { kind: "review" | "documents" | "summary" }) {
  return <svg viewBox="0 0 540 390" fill="none" aria-hidden="true" focusable="false">
    <g stroke="var(--ink)" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round">
      {kind === "review" && <>
        <path d="M42 340H504" opacity=".3" />
        <rect x="59" y="63" width="212" height="253" fill="var(--accent-yellow)" />
        <path d="M86 35h176l34 34v218H86ZM262 35v34h34" fill="var(--surface)" />
        <path d="M113 99h146M113 123h98M113 171h141M113 195h112M113 219h75" />
        <circle cx="335" cy="180" r="86" fill="var(--accent-mint)" />
        <circle cx="335" cy="180" r="56" /><path d="m396 241 68 68" strokeWidth="9" />
        <path d="M313 174c0-30 45-28 45-1 0 15-23 17-23 32m0 12v3" stroke="var(--brand)" strokeWidth="4" />
        <path d="M393 63h61M412 87h42M395 112h59" strokeDasharray="3 6" />
      </>}
      {kind === "documents" && <>
        <path d="M47 124h158l25 25h250v190H47Z" fill="var(--accent-yellow)" />
        <rect x="93" y="45" width="165" height="228" fill="var(--surface)" />
        <rect x="161" y="73" width="165" height="228" fill="var(--accent-mint)" />
        <rect x="229" y="103" width="165" height="228" fill="var(--surface)" />
        <path d="M119 76h108M119 95h70M187 108h107M187 127h71M253 142h111M253 163h80M253 201h111M253 221h98M253 241h68" />
        <path d="M47 189h433v150H47Z" fill="var(--surface-yellow)" />
        <path d="M84 224h131M84 245h83" stroke="var(--brand)" />
      </>}
      {kind === "summary" && <>
        <path d="M60 50h70v286H60M94 77h65M94 150h65M94 223h65M94 296h65" />
        {[77, 150, 223, 296].map((y, index) => <circle key={y} cx="94" cy={y} r="15" fill={index % 2 ? "var(--accent-mint)" : "var(--accent-yellow)"} />)}
        <path d="M180 103h296M180 176h296M180 249h296M180 322h296" opacity=".3" />
      </>}
    </g>
    {kind === "summary" && <g fill="var(--ink)" fontFamily="inherit" fontSize="23">
      <text x="178" y="82">Information reviewed</text>
      <text x="178" y="155">Supporting evidence</text>
      <text x="178" y="228">Outstanding questions</text>
      <text x="178" y="301">Identified concerns</text>
    </g>}
  </svg>;
}
