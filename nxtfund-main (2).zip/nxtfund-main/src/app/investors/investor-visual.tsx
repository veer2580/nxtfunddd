export default function InvestorVisual({ selectedCategory }: { selectedCategory?: number }) {
  return <svg viewBox="0 0 560 400" aria-hidden="true" focusable="false" fill="none">
    <g stroke="var(--ink)" strokeWidth="2" strokeLinejoin="round">
      <path d="M30 330H530" opacity=".25" />
      <rect x="40" y="90" width="150" height="206" fill="var(--accent-yellow)" />
      <rect x="64" y="66" width="150" height="206" fill="var(--surface)" />
      <path d="M89 104H182M89 123H156M89 162H182M89 181H171M89 200H151" />
      <path d="M89 240h24v-20h24v-28h24" stroke="var(--brand)" />
      <path d="M214 167H286M365 167H426" />
      <circle cx="289" cy="167" r="63" fill="var(--accent-mint)" />
      <circle cx="289" cy="167" r="42" />
      <path d="m275 166 10 10 20-21m28 51 38 38" strokeWidth="4" />
      {[80, 116, 152, 188, 224, 260].map((y, index) => <g key={y} data-highlighted={selectedCategory === index}>
        <path d={`M408 167V${y}H451`} stroke={selectedCategory === index ? "var(--brand)" : "var(--ink)"} />
        <circle cx="472" cy={y} r="14" fill={selectedCategory === index ? "var(--brand)" : index % 2 ? "var(--accent-mint)" : "var(--surface)"} />
      </g>)}
    </g>
    <g fill="var(--ink)" fontFamily="inherit" fontSize="19">
      <text x="53" y="365">Founder information</text>
      <text x="254" y="292">Review</text>
      <text x="391" y="317">Investor lens</text>
    </g>
  </svg>;
}
