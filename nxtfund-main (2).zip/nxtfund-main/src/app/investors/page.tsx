import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import OpportunityIllustration from "../components/opportunity-illustration";
import { isPublicRouteAvailable, registrationRoutes } from "../components/site-navigation";
import InvestorSection from "./investor-section";
import InvestorVisual from "./investor-visual";
import InvestorCategorySelector from "./investor-category-selector";
import styles from "./investors.module.css";

export const metadata: Metadata = {
  title: "For Investors",
  description: "Explore NxtFund’s approach to startup discovery, structured due diligence and direct founder connections across six investor categories.",
};
const connectionSteps = [
  { title: "Register and get verified.", description: "Share your investor profile and preferences through the intended registration and verification process.", kind: "investors" },
  { title: "Explore reviewed startups.", description: "Explore startups that have completed due diligence, when verified opportunities are available.", kind: "diligence" },
  { title: "Connect directly.", description: "Speak with founders and negotiate your own investment terms.", kind: "startup" },
] as const;
const reviewAreas = ["Financial information", "Legal standing", "Founder background", "Market claims", "Relevant references"];

export default function Investors() {
  return <>
    <SiteHeader />
    <main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
      <section className={styles.hero} aria-labelledby="investor-heading">
        <div className={`${styles.container} ${styles.split}`}>
          <div>
            <p className={styles.eyebrow}>FOR INVESTORS</p>
            <h1 id="investor-heading">Discover founders. Explore possibilities.</h1>
            <p>Explore NxtFund’s approach to startup discovery, structured due diligence and direct founder connections.</p>
            <div className={styles.actions}>
              <SiteLink href={registrationRoutes.investor} className={styles.primaryAction}>Join as an Investor</SiteLink>
              <a href="#investor-categories" className={styles.textAction}>Explore investor categories <span aria-hidden="true">↓</span></a>
            </div>
            <p className={styles.note}>You can prepare your investor registration. Submission is currently unavailable.</p>
          </div>
          <figure className={styles.visual}><InvestorVisual /></figure>
        </div>
      </section>
      <InvestorSection id="investor-categories">
        <p className={styles.eyebrow}>INVESTOR CATEGORIES</p>
        <h2 id="investor-categories-heading">Different perspectives. A shared possibility.</h2>
        <InvestorCategorySelector />
      </InvestorSection>
      <InvestorSection id="investor-connections" className={styles.connections}>
        <p className={styles.eyebrow}>HOW CONNECTIONS WORK</p>
        <h2 id="investor-connections-heading">From a clearer picture to a direct conversation.</h2>
        <ol className={styles.steps}>
          {connectionSteps.map((step, index) => <li key={step.title}>
            <div className={styles.stepVisual}><OpportunityIllustration kind={step.kind} /></div>
            <span className={styles.number} aria-hidden="true">0{index + 1}</span>
            <h3>{step.title}</h3><p>{step.description}</p>
          </li>)}
        </ol>
        <p className={styles.note}>This is the intended process. Access to opportunities depends on verification and availability.</p>
      </InvestorSection>
      <InvestorSection id="investor-review">
        <div className={styles.split}>
          <figure className={`${styles.visual} ${styles.reviewVisual}`}><OpportunityIllustration kind="diligence" /></figure>
          <div>
            <p className={styles.eyebrow}>DUE DILIGENCE</p>
            <h2 id="investor-review-heading">Look beyond the pitch.</h2>
            <p>Structured due diligence considers the information behind a startup’s claims.</p>
            <ul className={styles.reviewAreas}>{reviewAreas.map(area => <li key={area}><span aria-hidden="true">↗</span>{area}</li>)}</ul>
            <p className={styles.note}>Review does not guarantee investment performance.</p>
            {isPublicRouteAvailable("/due-diligence") && <SiteLink href="/due-diligence" className={styles.textAction}>Explore due diligence</SiteLink>}
          </div>
        </div>
      </InvestorSection>
      <InvestorSection id="investor-next-step" className={styles.closing}>
        <h2 id="investor-next-step-heading">Explore your next connection.</h2>
        <p>NxtFund facilitates verification and introductions. Investment agreements are made directly between investors and founders. Funding and returns are not guaranteed.</p>
        <div className={styles.actions}><SiteLink href={registrationRoutes.investor} className={styles.primaryAction}>Join as an Investor</SiteLink></div>
      </InvestorSection>
    </main>
  </>;
}
