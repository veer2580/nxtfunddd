"use client";

import { useRef, useState, type KeyboardEvent } from "react";
import { investorCategories } from "@/lib/investor-categories";
import InvestorVisual from "./investor-visual";
import styles from "./investors.module.css";

export default function InvestorCategorySelector() {
  const [selected, setSelected] = useState(0);
  const buttons = useRef<(HTMLButtonElement | null)[]>([]);
  function navigate(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let next: number;
    switch (event.key) {
      case "ArrowRight": case "ArrowDown": next = (index + 1) % investorCategories.length; break;
      case "ArrowLeft": case "ArrowUp": next = (index + investorCategories.length - 1) % investorCategories.length; break;
      case "Home": next = 0; break;
      case "End": next = investorCategories.length - 1; break;
      default: return;
    }
    event.preventDefault();
    setSelected(next);
    buttons.current[next]?.focus();
  }
  return <div className={styles.split}>
    <div>
      <div className={styles.categories} role="group" aria-label="Investor categories">
        {investorCategories.map((category, index) => <button key={category.name} type="button"
          ref={element => { buttons.current[index] = element; }} aria-pressed={selected === index}
          aria-controls="investor-category-details" onClick={() => setSelected(index)} onKeyDown={event => navigate(event, index)}>
          <span aria-hidden="true">0{index + 1}</span>{category.name}
        </button>)}
      </div>
      {/* Overlapping descriptions reserve space for the longest category at every width. */}
      <div id="investor-category-details" className={styles.details} aria-live="polite" aria-atomic="true">
        {investorCategories.map((category, index) => <div key={category.name} data-selected={selected === index} aria-hidden={selected !== index}>
          <h3>{category.name}</h3><p>{category.description}</p>
        </div>)}
      </div>
    </div>
    <figure className={`${styles.visual} ${styles.categoryVisual}`}>
      <InvestorVisual selectedCategory={selected} />
      <figcaption>Categories describe the intended network, not confirmed membership.</figcaption>
    </figure>
  </div>;
}
