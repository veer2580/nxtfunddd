import type { Metadata } from "next";
import SiteHeader from "./components/site-header";
import { IntroReveal } from "./components/home-intro";
import HomeHero from "./components/home-hero";
import HomeProcess from "./components/home-process";
import HomeBenefits from "./components/home-benefits";
import HomeInvestorNetwork from "./components/home-investor-network";
import HomeTrueValue from "./components/home-truevalue";
import HomeClosingCta from "./components/home-closing-cta";

export const metadata: Metadata = {
  title: {
    absolute: "NxtFund | Startups, Investors & Business Opportunities",
  },
  description:
    "Explore startup and business opportunities, find your pathway with NxtFund.",
};

export default function Home() {
  return (
    <>
      <IntroReveal className="header-reveal"><SiteHeader /></IntroReveal>

      <main id="main-content" tabIndex={-1} className="page-surface">
        <HomeHero />

        <IntroReveal>
          <HomeProcess />
          <HomeBenefits />
          <HomeInvestorNetwork />
          <HomeTrueValue />

          <HomeClosingCta />
        </IntroReveal>
      </main>
    </>
  );
}
