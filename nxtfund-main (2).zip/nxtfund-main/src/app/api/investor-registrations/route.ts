import { validateInvestorRegistration } from "@/lib/investor-registration/server";
import { BackendError, applicantMessages, getRegistration, getStore, rateLimit, saveRegistration } from "@/lib/backend/local-store.mjs";
import { authenticatedAccount, checkOrigin, ensureLocalBackend, failure, json, readJson } from "@/lib/backend/http";

export const runtime = "nodejs";
export async function POST(request: Request) {
  try {
    ensureLocalBackend();
    checkOrigin(request);
    const account = await authenticatedAccount();
    const data = await readJson(request);
    const form = new FormData();
    if (!data.fields || typeof data.fields !== "object" || Array.isArray(data.fields)) throw new BackendError(422, "Check your registration details.");
    for (const [key, value] of Object.entries(data.fields)) {
      if (typeof value !== "string") throw new BackendError(422, "Enter text values for your registration.");
      form.append(key, value);
    }
    const validated = validateInvestorRegistration(form);
    if (!validated.ok) return json({ errors: validated.errors, message: "Check your registration details." }, 422);
    const db = getStore();
    rateLimit(db, `submission:${account.id}`);
    const saved = saveRegistration(db, account, validated.fields, data.idempotencyKey, typeof data.expectedVersion === "number" ? data.expectedVersion : -1);
    return json({ reference: saved.reference, status: saved.status, id: saved.id }, 201);
  } catch (error) { return failure(error); }
}
export async function GET(request: Request) {
  try {
    ensureLocalBackend();
    const account = await authenticatedAccount();
    const db = getStore();
    const registration = getRegistration(db, account, new URL(request.url).searchParams.get("id"));
    return json({ registration, messages: applicantMessages(db, account, registration.id) });
  } catch (error) { return failure(error); }
}
