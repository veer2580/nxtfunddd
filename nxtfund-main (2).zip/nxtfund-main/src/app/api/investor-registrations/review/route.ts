import { getStore, reviewQueue, reviewRegistration, rateLimit } from "@/lib/backend/local-store.mjs";
import { authenticatedAccount, checkOrigin, ensureLocalBackend, failure, json, readJson } from "@/lib/backend/http";

export async function GET() {
  try { ensureLocalBackend(); return json({ registrations: reviewQueue(getStore(), await authenticatedAccount(true)) }); }
  catch (error) { return failure(error); }
}
export async function POST(request: Request) {
  try {
    ensureLocalBackend(); checkOrigin(request);
    const account = await authenticatedAccount(true);
    const data = await readJson(request);
    const db = getStore(); rateLimit(db, `review:${account.id}`);
    reviewRegistration(db, account, data.id, data.status, data.message, data.expectedStatus, data.expectedVersion, typeof data.internalNote === "string" ? data.internalNote : "");
    return json({ saved: true });
  } catch (error) { return failure(error); }
}
