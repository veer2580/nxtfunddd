import { getStore } from '@/lib/backend/local-store.mjs';
import { restoreInvestorDraft, saveDraft, readDraft } from '@/lib/backend/investor-drafts.mjs';
import { authenticatedAccount, checkOrigin, ensureLocalBackend, failure, json, readJson } from '@/lib/backend/http';
export async function GET(request: Request) {
  try { ensureLocalBackend(); const account = await authenticatedAccount(); const id = new URL(request.url).searchParams.get('id'); if (id) readDraft(getStore(), account, id); const record = getStore().prepare("SELECT status,decision FROM investor_registrations WHERE account_id=?").get(account.id); return json({ draft: restoreInvestorDraft(getStore(), account), editable: !record || (record.decision === "pending" && record.status === "needs_information") }); }
  catch (error) { return failure(error); }
}
export async function PUT(request: Request) {
  try { ensureLocalBackend(); checkOrigin(request); const account = await authenticatedAccount(); const data = await readJson(request); return json({ draft: saveDraft(getStore(), account, data.fields, data.expectedVersion) }); }
  catch (error) { return failure(error); }
}
