export async function POST() {
  // Do not ingest confidential submissions before durable storage and access checks exist.
  return Response.json({ error: "SUBMISSION_UNAVAILABLE", message: "Seller submissions cannot be saved yet. Private storage and authenticated access are not configured." }, {
    status: 503, headers: { "Cache-Control": "no-store" },
  });
}
