export async function POST() {
  // Do not ingest contact information until durable persistence and access controls exist.
  return Response.json({ error: "SUBMISSION_UNAVAILABLE", message: "Partner enquiries cannot be saved yet. Persistence and authenticated record access are not configured." }, {
    status: 503, headers: { "Cache-Control": "no-store" },
  });
}
