import { applicationUnavailableMessage } from "@/lib/startup-application/availability";

export async function POST() {
  // Do not parse or collect private data until durable storage and authorization exist.
  return Response.json({ error: "SUBMISSION_UNAVAILABLE", message: applicationUnavailableMessage }, {
    status: 503,
    headers: { "Cache-Control": "no-store" },
  });
}
