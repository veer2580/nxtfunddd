import { BackendError, getStore } from '@/lib/backend/local-store.mjs';
import { requireApprovedInvestor } from '@/lib/backend/investor-persistence.mjs';
import { authenticatedAccount, ensureLocalBackend, failure, json } from '@/lib/backend/http';
export async function GET(request: Request) {
  try {
    ensureLocalBackend(); const account = await authenticatedAccount(); requireApprovedInvestor(getStore(), account);
    const view = new URL(request.url).searchParams.get('view');
    if (!['startups','interests'].includes(view ?? '')) throw new BackendError(422, 'Choose a workspace destination.');
    // There is no approved dealflow/interest data source yet. Approval never manufactures opportunities.
    return json({ available: false, message: view === 'startups' ? 'Startup discovery is not connected yet. No private opportunities are currently available here.' : 'Introduction requests are not connected yet. No interest submissions can be made here.' });
  } catch (error) { return failure(error); }
}
