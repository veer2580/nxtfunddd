export async function POST() {
  // Reject without reading personal information until storage and access protection exist.
  return Response.json({ error: "SUBMISSION_UNAVAILABLE", message: "Contact enquiries cannot be saved yet. Persistence and authenticated record access are not configured." }, {
    status: 503, headers: { "Cache-Control": "no-store" },
  });
}
