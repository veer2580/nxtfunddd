import { cookies } from "next/headers";
import { BackendError, getRegistration, authenticate, getStore, localBackendEnabled, rateLimit, revokeSession, sessionAccount, sessionCookie } from "@/lib/backend/local-store.mjs";
import { checkOrigin, ensureLocalBackend, failure, json, readJson, safeReturnUrl } from "@/lib/backend/http";

export const runtime = "nodejs";
export async function GET() {
  if (!localBackendEnabled()) return json({ enabled: false, account: null });
  try { return json({ enabled: true, account: sessionAccount(getStore(), (await cookies()).get(sessionCookie)?.value) }); }
  catch (error) { return failure(error); }
}
export async function POST(request: Request) {
  try {
    ensureLocalBackend();
    checkOrigin(request);
    const data = await readJson(request);
    if (!["login", "create", "logout"].includes(String(data.action))) throw new BackendError(422, "Choose a valid account action.");
    const jar = await cookies();
    const db = getStore();
    if (data.action === "logout") {
      revokeSession(db, jar.get(sessionCookie)?.value);
      jar.delete(sessionCookie);
      return json({ signedOut: true });
    }
    rateLimit(db, "auth-global");
    const result = authenticate(db, data.email, data.password, data.action === "create");
    jar.set(sessionCookie, result.token, { httpOnly: true, sameSite: "lax", secure: false, path: "/", maxAge: 28800 });
    let destination = safeReturnUrl(data.returnTo);
    if (data.returnTo !== destination) {
      try { getRegistration(db, result.account); destination = "/app/investor"; }
      catch (error) { if ((error as { status?: number }).status !== 404) throw error; }
    }
    return json({ account: result.account, returnTo: destination });
  } catch (error) { return failure(error); }
}
