import { BackendError, getStore } from '@/lib/backend/local-store.mjs';
import { requestVerification, verifyEmail } from '@/lib/backend/email-verification.mjs';
import { authenticatedAccount, checkOrigin, ensureLocalBackend, failure, json, readJson } from '@/lib/backend/http';
export async function POST(request: Request) {
  try {
    ensureLocalBackend(); checkOrigin(request); const account = await authenticatedAccount(); const data = await readJson(request);
    if (data.action === 'send') return json(requestVerification(getStore(), account));
    if (data.action === 'verify') { const result = verifyEmail(getStore(), account, data.code); return json(result, result.verified ? 200 : 422); }
    throw new BackendError(422, 'Choose a verification action.');
  } catch (error) { return failure(error); }
}
