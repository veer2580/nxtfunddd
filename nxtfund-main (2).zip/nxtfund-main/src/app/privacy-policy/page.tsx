import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import { LegalSections, LegalToc } from "../components/legal-document";
import { lastUpdated, privacySections } from "../../lib/legal/content";
import styles from "../components/legal-document.module.css";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How NxtFund collects, uses and protects your personal information.",
};

export default function PrivacyPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}><div className={styles.container}>
    <header className={styles.head}>
      <p className={styles.eyebrow}>LEGAL CENTRE</p>
      <h1>Privacy Policy</h1>
      <p>Our commitment to protecting your personal information when you use www.nxtfund.in.</p>
      <p className={styles.updated}>Last Updated: {lastUpdated}</p>
      <div className={styles.switch}><SiteLink href="/terms-and-conditions">Terms &amp; Conditions</SiteLink><SiteLink href="/privacy-policy" aria-current="page">Privacy Policy</SiteLink></div>
    </header>
    <LegalToc title="In this document" sections={privacySections} prefix="p" />
    <LegalSections sections={privacySections} prefix="p" contactTitle="Contact Us" />
  </div></main></>;
}
