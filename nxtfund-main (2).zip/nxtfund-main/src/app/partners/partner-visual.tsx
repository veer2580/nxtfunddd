export type PartnerVisualKind = "connections" | "readiness" | "research" | "community" | "services";
export default function PartnerVisual({ kind = "connections" }: { kind?: PartnerVisualKind }) {
  return <svg viewBox="0 0 500 340" aria-hidden="true">
    {kind === "readiness" ? <>
      <path d="M73 272V153H168V272M203 272V111H298V272M333 272V69H428V272" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M68 106L192 64H308L431 26M412 22L431 26L424 45" fill="none" stroke="var(--brand)" strokeWidth="3" />
      <path d="M103 187H138M233 147H268M363 105H398" stroke="currentColor" strokeWidth="2" />
    </> : kind === "research" ? <>
      <path d="M75 99Q163 57 250 102Q337 57 425 99V264Q337 222 250 267Q163 222 75 264Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M250 102V267M106 132H207M106 160H207M106 188H185" stroke="currentColor" strokeWidth="2" />
      <circle cx="339" cy="166" r="35" fill="var(--accent-mint)" stroke="currentColor" strokeWidth="2" /><path d="M364 191L394 221" stroke="var(--brand)" strokeWidth="3" />
    </> : kind === "community" ? <>
      <circle cx="250" cy="165" r="70" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M181 165H95M319 165H405M250 95V45M250 235V295" stroke="currentColor" strokeWidth="2" />
      {[ [80,165], [420,165], [250,40], [250,300] ].map(([x,y]) => <circle key={`${x}-${y}`} cx={x} cy={y} r="22" fill="var(--accent-yellow)" stroke="currentColor" />)}
      <path d="M215 135H285V178H256L235 198V178H215Z" fill="var(--accent-mint)" stroke="currentColor" strokeWidth="2" />
    </> : kind === "services" ? <>
      <path d="M120 54H331L385 108V287H120Z" fill="var(--surface)" stroke="currentColor" strokeWidth="2" />
      <path d="M331 54V108H385M160 137H330M160 177H290M160 217H270" fill="none" stroke="currentColor" strokeWidth="2" />
      <circle cx="361" cy="248" r="41" fill="var(--accent-yellow)" stroke="currentColor" strokeWidth="2" /><path d="M338 248L354 265L386 231" fill="none" stroke="var(--brand)" strokeWidth="3" />
    </> : <>
      <path d="M113 93L250 171L387 93M113 247L250 171L387 247" fill="none" stroke="currentColor" strokeWidth="2" />
      <circle cx="250" cy="171" r="54" fill="var(--surface)" stroke="currentColor" strokeWidth="2" /><path d="M226 171H274M250 147V195" stroke="var(--brand)" strokeWidth="3" />
      {[ [113,93], [387,93], [113,247], [387,247] ].map(([x,y], index) => <g key={index}><rect x={x-48} y={y-36} width="96" height="72" fill={index % 2 ? "var(--accent-mint)" : "var(--accent-yellow)"} stroke="currentColor" /><path d={`M${x-24} ${y-8}H${x+24}M${x-24} ${y+10}H${x+12}`} stroke="currentColor" strokeWidth="2" /></g>)}
    </>}
  </svg>;
}
