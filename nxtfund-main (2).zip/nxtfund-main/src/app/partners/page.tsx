import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import PartnerVisual from "./partner-visual";
import PartnerSection from "./partner-section";
import styles from "./partners.module.css";

export const metadata: Metadata = { title: "Partners", description: "Explore potential collaboration with NxtFund around startup readiness, investor introductions and ecosystem programmes." };
export default function PartnersPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}>
    <section className={styles.hero} aria-labelledby="partners-heading"><div className={`${styles.container} ${styles.split}`}>
      <div><p className={styles.eyebrow}>COLLABORATION WITH NXTFUND</p><h1 id="partners-heading">Build stronger connections, together.</h1>
        <p>Explore collaboration with NxtFund across startup readiness, investor introductions and ecosystem programmes.</p>
        <p className={styles.note}>These are potential ways to collaborate, not existing partnerships or promised outcomes.</p>
      </div><figure className={styles.visual}><PartnerVisual /></figure>
    </div></section>
    <PartnerSection id="incubators" className={styles.warm}><div className={styles.split}>
      <figure className={styles.visual}><PartnerVisual kind="readiness" /></figure><div><p className={styles.eyebrow}>READINESS AND MENTORING</p><h2 id="incubators-heading">Incubators and accelerators</h2>
        <p>Explore ways to help founders prepare their business information, sharpen their pitch and approach relevant investor conversations.</p><ul className={styles.topics}><li>Founder mentoring</li><li>Application readiness</li><li>Relevant introductions</li></ul>
      </div></div></PartnerSection>
    <PartnerSection id="institutions"><div className={styles.split}>
      <div><p className={styles.eyebrow}>RESEARCH INTO POSSIBILITY</p><h2 id="institutions-heading">Educational and research institutions</h2>
        <p>Discuss ways to connect entrepreneurship programmes, research-led ideas and founder development with a structured startup pathway.</p><ul className={styles.topics}><li>Entrepreneurship programmes</li><li>Research-led startup readiness</li><li>Knowledge exchange</li></ul>
      </div><figure className={styles.visual}><PartnerVisual kind="research" /></figure></div></PartnerSection>
    <PartnerSection id="communities" className={styles.blue}><div className={styles.split}>
      <figure className={styles.visual}><PartnerVisual kind="community" /></figure><div><p className={styles.eyebrow}>CONVERSATIONS THAT CONNECT</p><h2 id="communities-heading">Industry bodies and founder communities</h2>
        <p>Explore conversations, sector perspectives and relevant programmes that bring founders and investors closer to useful information.</p><ul className={styles.topics}><li>Sector knowledge</li><li>Founder and investor introductions</li><li>Events and programmes</li></ul>
      </div></div></PartnerSection>
    <PartnerSection id="services"><div className={styles.split}>
      <div><p className={styles.eyebrow}>INFORMATION WITH GREATER CLARITY</p><h2 id="services-heading">Professional and service organisations</h2>
        <p>Discuss support for founder readiness, financial information and relevant professional services, with clear roles and expectations.</p><ul className={styles.topics}><li>Document readiness</li><li>Relevant professional expertise</li><li>Clear collaboration scope</li></ul>
      </div><figure className={styles.visual}><PartnerVisual kind="services" /></figure></div></PartnerSection>
    <PartnerSection id="partner-invitation" className={styles.warm}><div className={styles.split}>
      <div><p className={styles.eyebrow}>START WITH YOUR ORGANISATION</p><h2 id="partner-invitation-heading">Explore a shared direction.</h2><p>Prepare your organisation’s details and proposed collaboration for review. Enquiry submission is not yet available.</p><SiteLink href="/become-a-partner" className={styles.primaryAction}>Become a Partner <span aria-hidden="true">↗</span></SiteLink></div>
      <figure className={styles.visual}><PartnerVisual /></figure>
    </div></PartnerSection>
  </main></>;
}
