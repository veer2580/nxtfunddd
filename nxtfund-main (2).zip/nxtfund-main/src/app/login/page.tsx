import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import AccountPage from "../components/account-page";
export const metadata: Metadata = { title: "Account Access", robots: { index: false, follow: false } };
export default function Login() { return <><SiteHeader /><AccountPage /></>; }
