"use client";
import { useRef, useState } from "react";
import RegistrationField from "../components/registration-field";
import { contactCategoryOptions, contactFieldLimits, contactLabels, initialContactFields, validateContactFields, type ContactFields, type ContactErrors } from "@/lib/contact-enquiry/validation";
import styles from "../components/registration.module.css";

export default function ContactForm() {
  const [fields, setFields] = useState(initialContactFields);
  const [errors, setErrors] = useState<ContactErrors>({});
  const summary = useRef<HTMLDivElement>(null);
  function update(name: keyof ContactFields, value: string) {
    setFields(current => ({ ...current, [name]: value }));
    setErrors(current => { const remaining = { ...current }; delete remaining[name]; return remaining; });
  }
  function field(name: keyof ContactFields, example: string, options: {
    inputMode?: "email" | "tel"; autoComplete?: string; multiline?: boolean; options?: readonly { value: string; label: string }[];
  } = {}) {
    return <RegistrationField key={name} name={name} label={`${contactLabels[name]} — ${name === "phone" ? "optional" : "required"}`} value={fields[name]} maxLength={contactFieldLimits[name]} required={name !== "phone"} example={example} error={errors[name]} onChange={value => update(name, value)} {...options} />;
  }
  return <form className={styles.form} noValidate onSubmit={event => {
    event.preventDefault();
    const issues = validateContactFields(fields);
    setErrors(issues);
    if (Object.keys(issues).length) requestAnimationFrame(() => summary.current?.focus());
  }} onBlur={event => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement)) return;
    const name = target.name as keyof ContactFields;
    if (!(name in contactFieldLimits)) return;
    const error = validateContactFields(fields)[name];
    setErrors(current => { const remaining = { ...current }; if (error) remaining[name] = error; else delete remaining[name]; return remaining; });
  }}>
    <h2>Your enquiry</h2>
    <div className={styles.availability} role="note"><strong>Submission unavailable</strong><p>You can prepare your message, but contact enquiries cannot be saved yet.</p><p>Entries stay in this tab’s memory. Refreshing or leaving clears them; nothing is sent to the server.</p></div>
    {Object.keys(errors).length > 0 && <div ref={summary} role="alert" tabIndex={-1} className={styles.errorSummary}><strong>Check your enquiry details.</strong><ul>{Object.entries(errors).map(([name, message]) => <li key={name}><a href={`#field-${name}`}>{contactLabels[name as keyof ContactFields]}: {message}</a></li>)}</ul></div>}
    <fieldset className={styles.fields}><legend className="visually-hidden">Your enquiry details</legend>
      {field("name", "Your full name", { autoComplete: "name" })}
      {field("email", "For example, name@example.com", { inputMode: "email", autoComplete: "email" })}
      {field("phone", "Optional. Include country code where applicable, for example +91 98765 43210", { inputMode: "tel", autoComplete: "tel" })}
      {field("category", "Choose the category that best describes your enquiry.", { options: contactCategoryOptions })}
      {field("message", "Tell us what you would like to ask about. Up to 3,000 characters.", { multiline: true })}
    </fieldset>
    <div className={styles.actions}><button type="submit" disabled className={styles.primary} aria-describedby="contact-submission-status">Submit enquiry — unavailable</button></div>
    <p id="contact-submission-status" className={styles.hint}>Enquiry submission is currently unavailable. No message has been saved or sent.</p>
  </form>;
}
