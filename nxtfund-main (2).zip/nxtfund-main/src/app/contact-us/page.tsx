import type { Metadata } from "next";
import SiteHeader from "../components/site-header";
import SiteLink from "../components/site-link";
import ActivityVisual from "../components/activity-visual";
import ContactForm from "./contact-form";
import styles from "../components/registration.module.css";
import contactStyles from "./contact-us.module.css";

export const metadata: Metadata = { title: "Contact Us", description: "Have a question about startups, investing, partnerships or TrueValue? Prepare your enquiry for NxtFund. Message submission is currently unavailable." };
export default function ContactPage() {
  return <><SiteHeader /><main id="main-content" tabIndex={-1} className={`page-surface ${styles.page}`}><div className={styles.container}>
    <div className={styles.introduction}><p className={styles.eyebrow}>CONTACT NXTFUND</p><h1>Let’s start a conversation.</h1><p>Have a question about startups, investing, partnerships or TrueValue? Tell us how we can help.</p></div>
    <div className={styles.layout}><aside className={styles.aside} aria-label="Dedicated application pathways">
      <div className={styles.visual}><ActivityVisual kind="conversation" /></div><h2>Find your starting point.</h2>
      <p>Funding applications and investor registrations have dedicated forms. You can open and review them while submission setup is pending.</p>
      <div className={contactStyles.pathways}><SiteLink href="/startup-registration" className={contactStyles.textAction}>Apply for Funding <span aria-hidden="true">↗</span></SiteLink><SiteLink href="/investor-registration" className={contactStyles.textAction}>Join as an Investor <span aria-hidden="true">↗</span></SiteLink></div>
      <div className={contactStyles.details}>
        <h3>Contact details</h3>
        <ul>
          <li><span>Phone</span><a href="tel:+919784626443">9784626443</a></li>
          <li><span>Email</span><a href="mailto:startup.nxtfund@gmail.com">startup.nxtfund@gmail.com</a></li>
          <li><span>Email</span><a href="mailto:info@celebso.com">info@celebso.com</a></li>
          <li><span>Email</span><a href="mailto:info@markifid.com">info@markifid.com</a></li>
          <li><span>Address</span><address>Jaipur, India – 302015</address></li>
        </ul>
      </div>
    </aside><ContactForm /></div>
  </div></main></>;
}
