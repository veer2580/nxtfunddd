import "server-only";
import { cookies } from "next/headers";
import { BackendError, getStore, localBackendEnabled, requireAccount, sessionCookie } from "./local-store.mjs";

export function safeReturnUrl(value: unknown) {
  const allowed = new Set(["/investor-registration", "/account/investor-registration", "/review/investor-registrations", "/app/investor", "/app/investor/startups", "/app/investor/interests", "/onboarding/investor", "/ops/reviews"]);
  return typeof value === "string" && allowed.has(value) ? value : "/investor-registration";
}
export function ensureLocalBackend() {
  if (!localBackendEnabled()) throw new BackendError(503, "Submission is currently unavailable.");
}
export function checkOrigin(request: Request) {
  const configured = process.env.APP_NIVESH_LOCAL_ORIGIN ?? "http://localhost:3101";
  const origin = new URL(configured);
  if (!["localhost", "127.0.0.1", "[::1]"].includes(origin.hostname) || request.headers.get("origin") !== origin.origin || new URL(request.url).origin !== origin.origin) throw new BackendError(403, "This request is not permitted.");
}
export async function readJson(request: Request): Promise<Record<string, unknown>> {
  if (!request.headers.get("content-type")?.startsWith("application/json")) throw new BackendError(415, "Use a JSON request.");
  const reader = request.body?.getReader();
  if (!reader) throw new BackendError(422, "Enter the required details.");
  let size = 0;
  const chunks: Uint8Array[] = [];
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 32768) { await reader.cancel(); throw new BackendError(413, "The submitted information is too large."); }
      chunks.push(value);
    }
    const result = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!result || typeof result !== "object" || Array.isArray(result)) throw new Error();
    return result;
  } catch (error) {
    if (error instanceof BackendError) throw error;
    throw new BackendError(422, "Check the submitted information.");
  }
}
export async function authenticatedAccount(reviewer = false) {
  return requireAccount(getStore(), (await cookies()).get(sessionCookie)?.value, reviewer);
}
export function json(data: unknown, status = 200, retryAfter = 60) {
  return Response.json(data, { status, headers: { "Cache-Control": "private, no-store", "Vary": "Cookie", ...(status === 429 ? { "Retry-After": String(Math.max(1, Math.ceil(retryAfter))) } : {}) } });
}
export function failure(error: unknown) {
  if (error instanceof BackendError) return json({ error: error.status === 503 ? "SUBMISSION_UNAVAILABLE" : "REQUEST_FAILED", message: error.message }, error.status, error.retryAfter);
  // Database errors can contain personal fields; return generic recovery copy and never log payloads.
  return json({ error: "SERVER_ERROR", message: "Unable to save or load information. Your entries have been kept; try again." }, 503);
}
