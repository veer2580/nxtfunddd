import "server-only";
import { redirect } from "next/navigation";
import { localBackendEnabled } from "./local-store.mjs";
import { authenticatedAccount, safeReturnUrl } from "./http";
export async function investorPageAccount(destination: string) {
  if (!localBackendEnabled()) return null;
  try { return await authenticatedAccount(); }
  catch (error) {
    if ((error as { status?: number }).status === 401) redirect(`/login?returnTo=${encodeURIComponent(safeReturnUrl(destination))}`);
    throw error;
  }
}
