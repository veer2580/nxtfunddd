# Startup application integration

The project currently has no database, authentication provider, private file store or deployment configuration. No application or document is persisted. The form retains entries and File objects only in React memory. Refreshing or leaving the page clears them. It never uses browser storage or uploads files.

`POST /api/startup-applications` returns 503 without reading the body. It never returns a success/reference. `server.ts` is the server-only validation boundary to call before future persistence; it is deliberately not a collection endpoint while infrastructure is unavailable.

Run the validation tests with `npm run test:application`. They exercise the actual server validator and render the confirmation with isolated test receipts. They do not test database or storage integrations or demonstrate a successful saved submission.

## Validation limits

- Company name 160 characters; founder name 120; email 254; phone 25 (7–15 digits); sector and stage 100 each.
- Funding ask is a positive decimal INR amount, at most two decimal places and a technical upper bound of 999,999,999,999.99. This is an input limit, not a funding eligibility rule.
- Proposed use of funds 3,000 characters; financial explanation 10–2,000 characters when documents are unavailable.
- Pitch deck required; financial PDF required unless an explanation is selected. PDF only; 5 MiB each, 10 MiB combined; filenames at most 200 characters. Validate MIME/extension, header, objects, root reference, startxref and EOF. Reject encrypted PDFs, scripts and embedded files. These checks do not replace a complete PDF parser or malware scan.
- Duplicate field/document entries and non-text field values are rejected on the server.

## Required setup before enabling submissions

1. Select and configure a durable database and private object storage appropriate to the deployment. Add migrations for applications, document references and a unique idempotency key. Store INR precisely as decimal or integer paise. Do not store documents in public assets or deployment-local files.
2. Configure authenticated applicant identity and authorized reviewer roles. Define ownership/access rules. Every download must authorize the caller against the application/document on the server; no public object URLs. Use private storage credentials only on the server.
3. Connect an ingestion handler to `validateStartupApplication`, with streaming/request-size enforcement (two 5 MiB files plus bounded fields and multipart overhead), request-origin/CSRF protection, abuse controls, complete PDF parsing and malware scanning. Limits must also be configured at the deployment gateway.
4. Implement staged private uploads, database transaction and unique idempotency enforcement. On any failed upload or transaction, remove newly staged objects; add reconciliation for interrupted requests and orphaned uploads. Respond with a non-sensitive random application reference only after a committed application and all document references exist. Repeated requests must return the original committed reference without duplicating files/applications.
5. Verify valid commits, invalid server fields, rejected documents, storage/database failure rollback, concurrent duplicate requests and unauthorized document reads against the actual infrastructure. Define document retention/deletion and provide the real privacy policy before production collection.
6. Only after those checks pass, connect the client submit handler and enable the submission button. Navigation to the form is independent of submission availability: the current handler always returns 503 and the form intentionally has no submission transport. No email delivery is implemented.

## Confirmation integration

`src/app/startup-registration/application-confirmation.tsx` is intentionally not mounted or exposed through a route, query parameter or preview. The current 503 endpoint cannot produce a confirmation.

After the ingestion handler commits the application and its private document references, return a receipt containing `reference` (the non-sensitive backend reference) and `status` (the actual backend status label). Pass that trusted receipt to `ApplicationConfirmation` in place of the form and focus its heading after rendering. Do not construct a receipt from client fields, validation results, URL parameters or browser storage. Failed requests retain the form and entries and never render confirmation. Idempotent retries return the same committed receipt. The overview is explanatory, not a claim that later stages have been reached; no tracking endpoint exists.
