export const maxDocumentBytes = 5 * 1024 * 1024;

export async function validatePdf(file: File | null, required: boolean): Promise<string | undefined> {
  if (!file || file.size === 0) return required ? "Choose a PDF document." : undefined;
  if (file.size > maxDocumentBytes) return "Use a PDF of 5 MiB or less.";
  if (file.name.length > 200) return "Use a filename of 200 characters or fewer.";
  if (!/\.pdf$/i.test(file.name) || (file.type && file.type !== "application/pdf")) return "Only PDF documents are accepted. Export your document as a PDF.";
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const decoder = new TextDecoder("latin1");
    const content = decoder.decode(bytes);
    // A signature alone is insufficient: require PDF trailer and object structure too.
    const trailer = /startxref\s+(\d+)\s+%%EOF\s*$/.exec(content.slice(-1024));
    const offset = Number(trailer?.[1]);
    const xref = Number.isSafeInteger(offset) && offset >= 0 && offset < bytes.length ? content.slice(offset, offset + 2048) : "";
    const validXref = xref.startsWith("xref") || /^\d+\s+\d+\s+obj\b/.test(xref) && /\/Type\s*\/XRef\b/.test(xref);
    if (!/^%PDF-(1\.[0-7]|2\.0)(\r\n|\r|\n)/.test(content) || !trailer || !validXref || !/\b\d+\s+\d+\s+obj\b/.test(content) || !/\/Root\s+\d+\s+\d+\s+R/.test(content)) return "This file does not have the expected PDF structure. Export a fresh PDF.";
    if (/\/(JavaScript|JS|Launch|EmbeddedFile|Encrypt)\b/.test(content)) return "Use an unencrypted PDF without scripts or embedded files.";
  } catch {
    return "The document could not be read. Choose it again or export a fresh PDF.";
  }
}
