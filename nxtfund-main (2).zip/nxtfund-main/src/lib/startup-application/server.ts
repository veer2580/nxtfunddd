import "server-only";
import { fieldLimits, validateFields, type ApplicationFields, type ApplicationErrors } from "./validation";
import { validatePdf } from "./documents";

// Integration boundary: validate again on the server before any future database/storage writes.
export async function validateStartupApplication(data: FormData) {
  const fields = Object.fromEntries(Object.keys(fieldLimits).map(key => [key, data.get(key) ?? ""])) as ApplicationFields;
  const mode = data.get("financialUnavailable");
  const financialUnavailable = mode === "true";
  const errors: ApplicationErrors = validateFields(fields, financialUnavailable);
  for (const field of Object.keys(fieldLimits) as (keyof ApplicationFields)[]) {
    if (typeof fields[field] !== "string" || fields[field].length > fieldLimits[field] || data.getAll(field).length > 1) errors[field] = "Enter one text value within the field limit.";
  }
  if (mode !== "true" && mode !== "false") errors.financialExplanation = "Choose whether financial information is available.";
  const pitch = data.get("pitchDeck");
  const financial = data.get("financialDocument");
  if (pitch !== null && !(pitch instanceof File)) errors.pitchDeck = "Choose a PDF document.";
  else errors.pitchDeck = await validatePdf(pitch as File | null, true);
  if (financial !== null && !(financial instanceof File)) errors.financialDocument = "Choose a PDF document.";
  else if (financialUnavailable && financial instanceof File && financial.size > 0) errors.financialDocument = "Remove the financial document or choose the upload option.";
  else if (!financialUnavailable) {
    if (financial !== null && !(financial instanceof File)) errors.financialDocument = "Choose a PDF document.";
    else errors.financialDocument = await validatePdf(financial as File | null, true);
  }
  if (data.getAll("pitchDeck").length > 1) errors.pitchDeck = "Choose one pitch deck.";
  if (data.getAll("financialDocument").length > 1) errors.financialDocument = "Choose one financial document.";
  if (data.getAll("financialUnavailable").length > 1) errors.financialExplanation = "Choose one financial document option.";
  const issues = Object.fromEntries(Object.entries(errors).filter(([, message]) => message)) as ApplicationErrors;
  if (Object.keys(issues).length) return { ok: false as const, errors: issues };
  const normalized = Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, value.trim()])) as ApplicationFields;
  return { ok: true as const, fields: normalized, financialUnavailable, pitchDeck: pitch as File, financialDocument: financialUnavailable ? null : financial as File };
}
