export const fieldLimits = {
  companyName: 160, founderName: 120, email: 254, phone: 25,
  sector: 100, stage: 100, fundingAsk: 18, useOfFunds: 3000, financialExplanation: 2000,
} as const;

export type ApplicationFields = Record<keyof typeof fieldLimits, string>;
export type ApplicationErrors = Partial<Record<keyof ApplicationFields | "pitchDeck" | "financialDocument", string>>;
export const initialFields: ApplicationFields = {
  companyName: "", founderName: "", email: "", phone: "", sector: "", stage: "",
  fundingAsk: "", useOfFunds: "", financialExplanation: "",
};

export function validateFields(values: ApplicationFields, financialUnavailable: boolean, step?: number): ApplicationErrors {
  const errors: ApplicationErrors = {};
  const groups: (keyof ApplicationFields)[][] = [
    ["companyName", "founderName", "email", "phone", "sector", "stage"],
    ["fundingAsk", "useOfFunds"],
    financialUnavailable ? ["financialExplanation"] : [],
  ];
  for (const field of step === undefined ? groups.flat() : groups[step]) {
    const value = values[field];
    if (typeof value !== "string" || !value.trim()) errors[field] = "Enter this information.";
    else if (value.length > fieldLimits[field]) errors[field] = `Use ${fieldLimits[field]} characters or fewer.`;
  }
  if ((step === undefined || step === 0) && !errors.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) errors.email = "Enter a valid email address, for example founder@example.com.";
  if ((step === undefined || step === 0) && !errors.phone && (!/^\+?[\d\s().-]+$/.test(values.phone) || !/^\d{7,15}$/.test(values.phone.replace(/\D/g, "")))) errors.phone = "Enter a phone number with 7–15 digits, including country code where applicable.";
  if ((step === undefined || step === 1) && !errors.fundingAsk) {
    const amount = values.fundingAsk;
    if (!/^\d+(\.\d{1,2})?$/.test(amount) || Number(amount) <= 0 || Number(amount) > 999999999999.99) errors.fundingAsk = "Enter an INR amount above zero and up to 999,999,999,999.99, with at most two decimal places.";
  }
  if ((step === undefined || step === 2) && financialUnavailable && !errors.financialExplanation && values.financialExplanation.trim().length < 10) errors.financialExplanation = "Explain why financial information is unavailable using at least 10 characters.";
  return errors;
}
