export const applicationUnavailableMessage = "Applications are currently unavailable. Your entries and documents have not been submitted.";
