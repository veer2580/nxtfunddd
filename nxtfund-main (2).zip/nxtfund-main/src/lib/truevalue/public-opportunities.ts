import "server-only";

// Fail closed until a published-listing query and approved public projection exist.
export function getPublicOpportunityState() {
  return { status: "unavailable" as const };
}
