# TrueValue availability and privacy boundary

`/truevalue` is an information page. No listing database, authentication provider or private file store exists. The server-only `getPublicOpportunityState()` returns only `unavailable`, not an invented empty result set or raw listing data. Filters and seller submission are disabled. No listing-detail route, access-request endpoint, private-data endpoint, example listings or prices are created. The page never fetches or exposes private records.

A native Next loading fallback and generic route error boundary handle page navigation/render failures without logging or displaying raw error details. They do not simulate a listing query. There are no live query loading, empty-results or storage-error flows to exercise yet.

Before connecting real listings:

- Use a server-only data-access layer that queries only published listings with seller-approved anonymous public fields. Return an explicit projection of sector, approved anonymous summary, asking-price range and sale type; never spread a database record into a page or client component. Validate publication and approval on the server, not only in JSX.
- Keep names, logos, identifying images, contacts, financial documents and private details in a separate protected projection and private storage. Every retrieval requires authenticated identity, completed verification and seller approval for that specific listing. References or guessed listing IDs must never bypass authorization.
- Add `/truevalue/[listing-id]` only for actual published listings. Until authorization succeeds, render approved public data only. Configure private object downloads on the server, without public asset URLs.
- The seller-entry preparation page exists at `/truevalue/list-your-business`; Start a listing opens it. Submission remains disabled until persistence, authentication and private storage are implemented. See `seller-entry/README.md`.
- Once search is connected, validate sector, sale type and exact INR ranges on the server, implement Clear filters and pending/result/error states, and test empty results, query/storage failures, direct listing access and denied private reads. Test seller approval revocation and unauthorized download attempts against the real infrastructure.

Current browsing is unavailable; this must not be represented as a successful live search returning zero records. Transactions are negotiated and agreed directly between the parties.
