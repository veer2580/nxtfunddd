# Seller entry integration

Canonical route: `/truevalue/list-your-business` (page exists). Header TrueValue → List Your Business and overview Start a listing both use this URL. `/truevalue` remains the overview. No private listing/detail or document retrieval routes exist.

The four-step form is a local preparation UI. React memory only; no localStorage, uploads, network submissions, publication or success screen. Refresh clears entries. Final submission and optional document attachment are disabled. `POST /api/truevalue/seller-listings` returns 503 without reading the body, including retries and file-bearing requests. No records or references are created.

`validateSellerSubmission` is a server-only integration boundary, not an operational ingestion API. It validates allowlisted text fields, exact INR values (positive asking price, nonnegative revenue, signed profit), conditional stake percentage, lengths and duplicate fields; rejects any documents while storage is absent. It separates proposed public fields from private seller/business/financial fields. Proposed fields require anonymity review and seller approval; contact detection is only a helpful guard, not proof of anonymity. Identity, publication state and review status cannot be set by a submitted field. Technical monetary limit: INR 999,999,999,999.99; up to two decimal places. Majority: >50% and <100%; minority: >0% and <=50%.

Required before enabling submission:

- Durable database and migrations with separate private seller records and approved public projections; save application and references transactionally with initial review status, never automatic publication.
- Authentication and server-side ownership/reviewer permissions on every record request. Verified buyer + listing-specific seller approval on every private read; no public file URLs.
- Private object storage, document policy and upload scanning. Define allowed formats, per-file and total size/count limits; validate content, not extensions. Do not enable the file input until this exists. Existing startup PDF validation may be reused only if the seller document policy approves PDFs.
- Server request/body limits, validated inputs, CSRF/origin and abuse protection, unique idempotency keys, transactional duplicate handling and orphan-upload cleanup.
- Preserve form entries through recoverable errors; issue a non-sensitive reference only after durable commit and render a confirmation from that receipt. No fabricated email, approval or publication claims.
- Test durable success, failure/rollback, idempotent retries, rejected content, orphan cleanup, ownership checks, buyer permission revocation and document downloads against the actual infrastructure.

No backend persistence/storage failure or duplicate-record handling is implemented or claimed. The fail-closed 503 and isolated validation are testable now.
