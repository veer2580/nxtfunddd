import "server-only";
import { sellerLimits, validateSellerFields, type SellerFields, type SellerErrors } from "./validation";

// Pure integration boundary; it never writes, publishes or issues a receipt.
export function validateSellerSubmission(data: FormData) {
  const fields = Object.fromEntries(Object.keys(sellerLimits).map(key => [key, data.get(key) ?? ""])) as SellerFields;
  const errors: SellerErrors = {};
  for (const key of Object.keys(sellerLimits) as (keyof SellerFields)[]) {
    if (typeof fields[key] !== "string" || fields[key].length > sellerLimits[key] || data.getAll(key).length > 1) errors[key] = "Enter one text value within the field limit.";
  }
  // Reject file-bearing requests before reading file content while storage is absent.
  for (const [key, value] of data) if (typeof value !== "string" || key === "documents") errors.documents = "Document uploads are unavailable until private storage is configured.";
  if (Object.keys(errors).length) return { ok: false as const, errors };
  Object.assign(errors, validateSellerFields(fields));
  if (Object.keys(errors).length) return { ok: false as const, errors };
  const normalized = Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, value.trim()])) as SellerFields;
  if (!["majority", "minority"].includes(normalized.saleType)) normalized.stake = "";
  if (normalized.financialAvailability === "unavailable") { normalized.revenue = ""; normalized.profit = ""; normalized.period = ""; }
  else normalized.financialExplanation = "";
  const { sector, saleType, askingPrice, publicDescription, ...privateFields } = normalized;
  // Proposed public fields still require seller approval and platform review before publication.
  return { ok: true as const, proposedPublic: { sector, saleType, askingPrice, publicDescription }, privateFields };
}
