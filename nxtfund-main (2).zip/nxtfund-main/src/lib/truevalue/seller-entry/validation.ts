export const saleOptions = [
  { value: "full", label: "Full ownership" },
  { value: "majority", label: "Majority stake" },
  { value: "minority", label: "Minority stake" },
  { value: "product-ip", label: "Product or IP" },
] as const;
export const financialOptions = [{ value: "available", label: "Available" }, { value: "unavailable", label: "Not available" }] as const;
export const sellerLimits = {
  sellerName: 120, email: 254, phone: 25, sellerRole: 200, businessName: 160,
  sector: 120, location: 200, description: 2000, saleType: 20, stake: 6,
  askingPrice: 18, included: 2000, financialAvailability: 20, revenue: 18,
  profit: 19, period: 120, financialExplanation: 1000, publicDescription: 700,
} as const;
export type SellerFields = Record<keyof typeof sellerLimits, string>;
export type SellerErrors = Partial<Record<keyof SellerFields | "documents", string>>;
export const initialSellerFields = Object.fromEntries(Object.keys(sellerLimits).map(name => [name, name === "financialAvailability" ? "unavailable" : ""])) as SellerFields;
export const sellerLabels: Record<keyof SellerFields, string> = {
  sellerName: "Seller name", email: "Email", phone: "Phone", sellerRole: "Role or relationship to the business",
  businessName: "Business name — private", sector: "Sector", location: "Business location", description: "Brief business description — private",
  saleType: "What’s available", stake: "Stake percentage", askingPrice: "Asking price (INR)", included: "What is included in the proposed transaction",
  financialAvailability: "Revenue / profit information", revenue: "Available revenue (INR)", profit: "Available profit or loss (INR)", period: "Reporting period",
  financialExplanation: "Why financial information is unavailable", publicDescription: "Proposed anonymous public description",
};
function money(value: string, signed = false) {
  if (!(signed ? /^-?\d+(\.\d{1,2})?$/ : /^\d+(\.\d{1,2})?$/).test(value)) return undefined;
  const [whole, fraction = ""] = value.replace(/^-/, "").split(".");
  const amount = BigInt(whole) * BigInt(100) + BigInt(fraction.padEnd(2, "0"));
  return amount <= BigInt("99999999999999") ? (value.startsWith("-") ? -amount : amount) : undefined;
}
export function validateSellerFields(fields: SellerFields, step?: number): SellerErrors {
  const errors: SellerErrors = {};
  const groups: (keyof SellerFields)[][] = [
    ["sellerName", "email", "phone", "sellerRole", "businessName", "sector", "location", "description"],
    ["saleType", "askingPrice", "included", ...(["majority", "minority"].includes(fields.saleType) ? ["stake" as const] : [])],
    ["financialAvailability", ...(fields.financialAvailability === "available" ? ["period" as const] : ["financialExplanation" as const])],
    ["publicDescription"],
  ];
  for (const key of step === undefined ? groups.flat() : groups[step] ?? []) {
    if (typeof fields[key] !== "string" || !fields[key].trim()) errors[key] = "Enter this information.";
    else if (fields[key].length > sellerLimits[key]) errors[key] = `Use ${sellerLimits[key]} characters or fewer.`;
  }
  if (step === undefined || step === 0) {
    if (!errors.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email)) errors.email = "Enter a valid email address.";
    if (!errors.phone && (!/^\+?[\d\s().-]+$/.test(fields.phone) || !/^\d{7,15}$/.test(fields.phone.replace(/\D/g, "")))) errors.phone = "Enter a phone number with 7–15 digits.";
  }
  if (step === undefined || step === 1) {
    if (!saleOptions.some(option => option.value === fields.saleType)) errors.saleType = "Choose an available transaction type.";
    const amount = typeof fields.askingPrice === "string" && fields.askingPrice.length <= sellerLimits.askingPrice ? money(fields.askingPrice) : undefined;
    if (amount === undefined || amount <= BigInt(0)) errors.askingPrice = "Enter an INR amount above zero, up to 999,999,999,999.99, with at most two decimal places.";
    if (["majority", "minority"].includes(fields.saleType)) {
      const stake = /^\d+(\.\d{1,2})?$/.test(fields.stake) ? Number(fields.stake) : NaN;
      if (!(fields.saleType === "majority" ? stake > 50 && stake < 100 : stake > 0 && stake <= 50)) errors.stake = fields.saleType === "majority" ? "Enter more than 50% and less than 100%, with at most two decimal places." : "Enter more than 0% and up to 50%, with at most two decimal places.";
    }
  }
  if (step === undefined || step === 2) {
    if (!financialOptions.some(option => option.value === fields.financialAvailability)) errors.financialAvailability = "Choose Available or Not available.";
    if (fields.financialAvailability === "available") {
      if (!fields.revenue.trim() && !fields.profit.trim()) errors.revenue = "Provide available revenue or profit information, or choose Not available.";
      for (const key of ["revenue", "profit"] as const) {
        if (fields[key] && (fields[key].length > sellerLimits[key] || money(fields[key], key === "profit") === undefined)) errors[key] = "Enter INR without commas, up to 999,999,999,999.99 with at most two decimal places. Profit may be negative for a loss.";
      }
    }
  }
  if ((step === undefined || step === 3) && !errors.publicDescription && /[\w.+-]+@[\w.-]+\.[a-z]{2,}|(?:\+?\d[\s().-]*){7,}|https?:\/\/|www\./i.test(fields.publicDescription)) errors.publicDescription = "Remove contact details and website addresses from the public description.";
  return errors;
}
