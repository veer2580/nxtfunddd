export type Block = string | string[] | { h: string };
export type LegalSection = { title: string; blocks: Block[] };

export const lastUpdated = "September 7, 2026";

export const termsSections: LegalSection[] = [
  {
    "title": "About NXTFUND",
    "blocks": [
      "NXTFUND is a venture investment initiative associated with Celebso Group and operated by Celebso Technologies.",
      "NXTFUND may provide information relating to startups, entrepreneurship, funding opportunities, investment initiatives, applications, programs, and related business activities.",
      "The Website is intended to facilitate communication and information sharing between NXTFUND and founders, startups, investors, partners, and other ecosystem participants."
    ]
  },
  {
    "title": "Eligibility",
    "blocks": [
      "By using this Website, you represent that:",
      [
        "You are legally capable of entering into a binding agreement.",
        "The information you provide is accurate and complete.",
        "You will use the Website only for lawful purposes.",
        "You will not misuse, disrupt, or attempt to compromise the Website or its services."
      ],
      "If you are submitting information on behalf of a company or startup, you represent that you are authorized to provide such information."
    ]
  },
  {
    "title": "Startup Applications",
    "blocks": [
      "NXTFUND may provide founders or startups with the ability to submit applications, proposals, business information, pitch materials, financial information, or other documents for consideration.",
      "Submission of an application does not guarantee:",
      [
        "Funding;",
        "Investment;",
        "Selection;",
        "Partnership;",
        "Incubation;",
        "Acceleration;",
        "Mentorship;",
        "Commercial opportunities; or",
        "Any other benefit."
      ],
      "NXTFUND reserves the right to review, evaluate, reject, or discontinue any application at its discretion."
    ]
  },
  {
    "title": "No Guarantee of Funding",
    "blocks": [
      "Any information displayed on the Website regarding funding amounts, investment opportunities, programs, portfolio companies, or potential investments is provided for informational purposes unless expressly stated otherwise in a separate written agreement.",
      "Nothing on the Website should be interpreted as a promise, commitment, or guarantee that NXTFUND will invest in any particular startup or company.",
      "Any investment or funding commitment, where applicable, shall be subject to separate documentation, due diligence, internal approvals, applicable laws, and mutually agreed terms."
    ]
  },
  {
    "title": "Information Provided by Users",
    "blocks": [
      "You are responsible for ensuring that all information submitted to NXTFUND is:",
      [
        "Accurate;",
        "Complete;",
        "Current;",
        "Lawful; and",
        "Not misleading."
      ],
      "You must not submit information that infringes the intellectual property, privacy, confidentiality, or other legal rights of another person or organization.",
      "NXTFUND may rely on information provided by users when reviewing applications or communicating with applicants."
    ]
  },
  {
    "title": "Confidentiality",
    "blocks": [
      "Users should carefully consider what information they submit through the Website.",
      "Where a separate confidentiality or non-disclosure agreement (“NDA”) has been executed between the parties, the confidentiality obligations contained in that agreement shall apply.",
      "Unless otherwise agreed in writing, submission of information through the Website alone does not automatically create a confidential or fiduciary relationship between the user and NXTFUND.",
      "Users should avoid submitting passwords, payment-card information, government identification documents, or other highly sensitive information unless specifically requested through an authorized process."
    ]
  },
  {
    "title": "Intellectual Property",
    "blocks": [
      "All content available on the Website, including but not limited to:",
      [
        "Logos;",
        "Brand names;",
        "Text;",
        "Graphics;",
        "Images;",
        "Designs;",
        "Website layouts;",
        "Software;",
        "User interface elements;",
        "Videos;",
        "Icons;",
        "Trademarks; and",
        "Other materials"
      ],
      "may be owned by or licensed to Celebso Technologies, Celebso Group, NXTFUND, or their respective partners.",
      "Such content may not be copied, reproduced, modified, distributed, republished, sold, or commercially exploited without prior written permission, except where permitted by applicable law."
    ]
  },
  {
    "title": "User Content",
    "blocks": [
      "Where the Website permits users to submit content, you retain ownership of your content, subject to any separate agreement entered into with NXTFUND.",
      "By submitting content to NXTFUND, you grant NXTFUND permission to use, review, reproduce, store, process, and communicate such content to the extent reasonably necessary to evaluate applications, provide services, operate the Website, or perform activities connected with NXTFUND.",
      "NXTFUND does not claim ownership of a startup’s intellectual property merely because an application or proposal has been submitted, unless otherwise expressly agreed in writing."
    ]
  },
  {
    "title": "Prohibited Use",
    "blocks": [
      "You agree not to:",
      [
        "Use the Website for unlawful purposes;",
        "Submit false or misleading information;",
        "Impersonate another individual or organization;",
        "Attempt to gain unauthorized access to the Website;",
        "Introduce malware, viruses, or harmful code;",
        "Interfere with the Website’s operation;",
        "Scrape or systematically collect Website content without permission;",
        "Reverse engineer or attempt to reproduce Website systems;",
        "Abuse application or communication features; or",
        "Use the Website to commit fraud or facilitate illegal activity."
      ],
      "NXTFUND may restrict or terminate access where it reasonably believes these Terms have been violated."
    ]
  },
  {
    "title": "Third-Party Services and Links",
    "blocks": [
      "The Website may contain links to third-party websites, platforms, tools, or services.",
      "NXTFUND does not control and is not responsible for the content, availability, security, privacy practices, or policies of third-party websites.",
      "Your use of third-party services is subject to the terms and policies of the relevant third party."
    ]
  },
  {
    "title": "Website Availability",
    "blocks": [
      "We aim to keep the Website available and functional, but we do not guarantee that:",
      [
        "The Website will always be available;",
        "The Website will be uninterrupted;",
        "All information will always be accurate or current;",
        "The Website will be free from errors or technical issues; or",
        "The Website will be free from viruses or other harmful components."
      ],
      "NXTFUND may modify, suspend, restrict, or discontinue any part of the Website without prior notice where reasonably necessary."
    ]
  },
  {
    "title": "Disclaimers",
    "blocks": [
      "The Website and its content are provided on an “as available” and “as is” basis to the extent permitted by applicable law.",
      "Information available through NXTFUND should not be considered:",
      [
        "Legal advice;",
        "Tax advice;",
        "Financial advice;",
        "Investment advice;",
        "Accounting advice; or",
        "A recommendation to invest in any particular company or opportunity."
      ],
      "Users should obtain appropriate professional advice before making financial, investment, legal, or business decisions."
    ]
  },
  {
    "title": "Investment Disclaimer",
    "blocks": [
      "Startup investments involve significant risks, including the potential loss of capital.",
      "Past performance, previous funding, portfolio information, projections, business plans, market estimates, or other information displayed on the Website should not be interpreted as a guarantee of future performance.",
      "Any investment decision should be made only after appropriate independent evaluation and due diligence.",
      "Nothing on the Website constitutes an offer, solicitation, invitation, or commitment to invest unless expressly provided through legally valid documentation and permitted under applicable law."
    ]
  },
  {
    "title": "Limitation of Liability",
    "blocks": [
      "To the maximum extent permitted by applicable law, NXTFUND, Celebso Group, Celebso Technologies, and their respective directors, employees, representatives, partners, or affiliates shall not be liable for indirect, incidental, special, consequential, or similar losses arising from or relating to:",
      [
        "Use or inability to use the Website;",
        "Information submitted through the Website;",
        "Investment or business decisions;",
        "Funding outcomes;",
        "Loss of business opportunities;",
        "Technical interruptions;",
        "Third-party services; or",
        "Reliance on information published on the Website."
      ],
      "Nothing in these Terms excludes liability that cannot legally be excluded under applicable law."
    ]
  },
  {
    "title": "Indemnification",
    "blocks": [
      "You agree to indemnify and hold harmless NXTFUND, Celebso Group, Celebso Technologies, and their respective directors, employees, representatives, and affiliates from claims, liabilities, damages, losses, costs, or expenses arising from:",
      [
        "Your violation of these Terms;",
        "Your misuse of the Website;",
        "Information or content submitted by you;",
        "Your violation of another person’s rights; or",
        "Your violation of applicable laws or regulations."
      ]
    ]
  },
  {
    "title": "Privacy",
    "blocks": [
      "Your use of the Website may involve the collection and processing of personal information.",
      "Such information will be handled in accordance with the NXTFUND Privacy Policy.",
      "By using the Website, you acknowledge that you have read the applicable Privacy Policy."
    ]
  },
  {
    "title": "Communications",
    "blocks": [
      "By submitting your contact information through the Website, you may receive communications relating to:",
      [
        "Your application;",
        "NXTFUND programs;",
        "Startup opportunities;",
        "Events;",
        "Partnerships;",
        "Updates; or",
        "Other relevant communications."
      ],
      "You may contact us if you wish to modify your communication preferences."
    ]
  },
  {
    "title": "Modification of These Terms",
    "blocks": [
      "NXTFUND may update or modify these Terms from time to time.",
      "The updated version will be published on the Website with a revised “Last Updated” date.",
      "Your continued use of the Website after changes are published constitutes acceptance of the updated Terms, to the extent permitted by applicable law."
    ]
  },
  {
    "title": "Termination",
    "blocks": [
      "NXTFUND may suspend or terminate your access to the Website where it reasonably believes that you have:",
      [
        "Violated these Terms;",
        "Misused the Website;",
        "Submitted fraudulent information;",
        "Engaged in unlawful activity; or",
        "Created a security or operational risk."
      ],
      "Termination does not affect rights or obligations that accrued before termination."
    ]
  },
  {
    "title": "Governing Law and Jurisdiction",
    "blocks": [
      "These Terms shall be governed by and interpreted in accordance with the laws applicable in India.",
      "Subject to applicable law, courts having jurisdiction in Jaipur, Rajasthan, India shall have jurisdiction over disputes arising from or relating to these Terms or your use of the Website."
    ]
  },
  {
    "title": "Severability",
    "blocks": [
      "If any provision of these Terms is determined to be invalid, unlawful, or unenforceable, the remaining provisions shall continue to remain effective to the extent permitted by applicable law."
    ]
  },
  {
    "title": "Entire Agreement",
    "blocks": [
      "These Terms, together with the Privacy Policy and any additional written agreements entered into between you and NXTFUND, constitute the applicable understanding regarding your use of the Website, unless otherwise expressly agreed in writing."
    ]
  },
  {
    "title": "Contact Us",
    "blocks": [
      "For questions, concerns, applications, or other matters relating to these Terms, you may contact us using the details below."
    ]
  }
];

export const riskIntro: string[] = [
  "The information and materials presented on this website and through NXTFUND communications are provided for general informational purposes only. Nothing contained herein shall constitute, or be construed as, an offer, invitation, solicitation, recommendation, investment advice, financial advice, tax advice or legal advice to purchase, subscribe to, acquire or dispose of any securities, investment product or interest in any entity.",
  "NXTFUND does not provide any assurance or guarantee regarding the performance, valuation, profitability, liquidity, repayment or future prospects of any startup, company, investment opportunity or transaction referred to on this platform."
];

export const riskSections: LegalSection[] = [
  {
    "title": "Investment Risk",
    "blocks": [
      "Investments in startups, early-stage companies, private companies and other alternative investments involve a high degree of risk. Such investments may be illiquid and may result in partial or complete loss of the invested capital.",
      "Past performance, previous funding, valuation, business traction or projections of any company should not be considered an indication or guarantee of future performance.",
      "Prospective investors should independently evaluate all relevant risks and conduct their own due diligence before making any investment decision."
    ]
  },
  {
    "title": "Regulatory Status",
    "blocks": [
      "Unless expressly stated otherwise, NXTFUND is not, by virtue of this website alone, representing itself as a SEBI-registered Alternative Investment Fund, Investment Adviser, Portfolio Manager, Mutual Fund or other regulated intermediary.",
      "Where any investment, fundraising, securities issuance, private placement or other regulated activity is undertaken, such activity shall be subject to the applicable laws, regulations, approvals, registrations, exemptions and compliance requirements applicable to the relevant entity, transaction and jurisdiction.",
      "The Securities and Exchange Board of India (SEBI) regulates various activities relating to securities markets and has specific regulatory frameworks applicable to Alternative Investment Funds and Investment Advisers."
    ]
  },
  {
    "title": "Private Investment Opportunities",
    "blocks": [
      "Certain opportunities presented through NXTFUND may be available only to identified, eligible or otherwise permitted investors and may be subject to applicable private-placement, securities and other legal requirements.",
      "Where securities are proposed to be issued by an Indian company on a private-placement basis, the relevant provisions of the Companies Act, 2013 and applicable rules and regulations shall apply.",
      "Nothing on this website should be interpreted as a public offer of securities unless expressly stated in legally compliant offering documentation."
    ]
  },
  {
    "title": "No Investment Recommendation",
    "blocks": [
      "NXTFUND does not make individual investment recommendations through its website, social-media channels, presentations or general communications.",
      "The appearance of a startup, company, founder, investment opportunity or project on the NXTFUND platform does not constitute an endorsement, recommendation or assurance regarding its investment merits.",
      "Any investment decision must be made independently by the prospective investor after reviewing the relevant documentation and obtaining professional advice where appropriate."
    ]
  },
  {
    "title": "Due Diligence",
    "blocks": [
      "Information regarding startups, founders, businesses, financial projections, market opportunities, valuations, funding requirements and other matters may be provided by the respective company, founder or third-party sources.",
      "While NXTFUND may undertake certain screening, verification or due-diligence activities, no representation is made that all information is complete, accurate, current or independently verified in every respect.",
      "Investors should conduct their own independent legal, financial, commercial, tax and technical due diligence before entering into any transaction."
    ]
  },
  {
    "title": "No Guarantee of Returns",
    "blocks": [
      "NXTFUND does not guarantee or represent that any investment opportunity will generate a particular return, achieve a particular valuation, provide liquidity, or return the original invested capital.",
      "Investors may lose some or all of their invested capital."
    ]
  },
  {
    "title": "Professional Advice",
    "blocks": [
      "Prospective investors should seek independent advice from appropriately qualified legal, financial, tax and investment professionals before making any investment decision.",
      "Investors should consider their own financial circumstances, investment objectives, risk tolerance and applicable legal and regulatory requirements."
    ]
  },
  {
    "title": "Jurisdiction",
    "blocks": [
      "This website and its materials are primarily intended for use in India, subject to applicable Indian laws and regulations.",
      "Persons accessing this website from outside India are responsible for ensuring compliance with the laws and regulations applicable in their respective jurisdiction.",
      "NXTFUND does not intend to make any offer or solicitation in any jurisdiction where such activity would be prohibited or require regulatory approval that has not been obtained."
    ]
  },
  {
    "title": "Changes to Information",
    "blocks": [
      "NXTFUND may update, modify or remove information, investment opportunities, projections, descriptions or other materials published on this website at any time without prior notice.",
      "The availability of any opportunity on the website does not constitute a commitment by NXTFUND to proceed with, arrange, facilitate or complete any transaction."
    ]
  },
  {
    "title": "Final Notice",
    "blocks": [
      "By accessing this website and its materials, you acknowledge that investment decisions involve risk and that you should not rely solely upon information published by NXTFUND when making an investment decision.",
      "NXTFUND does not provide investment, legal, financial or tax advice through this website.",
      "Investments are subject to risk, including the possible loss of the entire amount invested."
    ]
  }
];

export const privacySections: LegalSection[] = [
  {
    "title": "Information We Collect",
    "blocks": [
      "Depending on how you use our Website, we may collect the following information.",
      {
        "h": "1.1 Information You Provide"
      },
      "When you contact us, submit a startup application, or otherwise communicate with NXTFUND, you may provide information such as:",
      [
        "Full name",
        "Email address",
        "Phone number",
        "Company or startup name",
        "Founder or team information",
        "Business information",
        "Website and social-media links",
        "Startup description",
        "Business model",
        "Funding requirements",
        "Pitch-deck or business documents",
        "Other information voluntarily submitted by you"
      ],
      "You should only provide information that you are authorized to share.",
      {
        "h": "1.2 Information Collected Automatically"
      },
      "When you visit our Website, certain technical information may be collected automatically, including:",
      [
        "IP address",
        "Browser type",
        "Device type",
        "Operating system",
        "Pages visited",
        "Approximate usage information",
        "Date and time of access",
        "Referring website",
        "Technical and diagnostic information"
      ],
      "This information may be used to maintain, secure, and improve the Website."
    ]
  },
  {
    "title": "How We Use Your Information",
    "blocks": [
      "We may use information collected through the Website to:",
      [
        "Process startup or funding applications;",
        "Review and evaluate submitted information;",
        "Communicate with founders, applicants, partners, and users;",
        "Respond to enquiries and requests;",
        "Provide information about NXTFUND programs and initiatives;",
        "Improve our Website and services;",
        "Maintain Website security;",
        "Detect and prevent fraud, abuse, or unauthorized activity;",
        "Maintain internal records;",
        "Comply with applicable legal and regulatory requirements; and",
        "Carry out legitimate business activities."
      ],
      "We will not use your information for purposes materially unrelated to the purpose for which it was collected without appropriate notice or lawful basis where required."
    ]
  },
  {
    "title": "Startup and Business Information",
    "blocks": [
      "If you submit information about a startup or business, NXTFUND may use that information for purposes including:",
      [
        "Application review;",
        "Business evaluation;",
        "Due diligence;",
        "Internal assessment;",
        "Communication with you;",
        "Evaluation of potential investment or partnership opportunities; and",
        "Related NXTFUND activities."
      ],
      "Submitting information does not guarantee funding, investment, selection, partnership, or any other outcome."
    ]
  },
  {
    "title": "How We Share Information",
    "blocks": [
      "We may share information where reasonably necessary with:",
      [
        "Employees and authorized representatives;",
        "Professional advisors;",
        "Service providers;",
        "Technology and hosting providers;",
        "Legal, accounting, or compliance professionals;",
        "Business partners involved in relevant activities; or",
        "Government, regulatory, or law-enforcement authorities where required by law."
      ],
      "We do not intend to sell your personal information as a commercial data product.",
      "Where information is shared with service providers, we seek to limit access to information reasonably necessary for the relevant purpose."
    ]
  },
  {
    "title": "Confidential Business Information",
    "blocks": [
      "NXTFUND understands that founders may submit commercially sensitive information.",
      "However, submission of information through the Website does not automatically create a legally binding confidentiality or non-disclosure obligation unless a separate agreement expressly provides for one.",
      "If you have highly confidential or proprietary information, you should consider whether an appropriate NDA or other confidentiality agreement is required before sharing such information."
    ]
  },
  {
    "title": "Cookies and Tracking Technologies",
    "blocks": [
      "The Website may use cookies or similar technologies to:",
      [
        "Enable Website functionality;",
        "Remember preferences;",
        "Understand Website usage;",
        "Improve performance;",
        "Analyze traffic; and",
        "Enhance user experience."
      ],
      "You may be able to control cookies through your browser settings.",
      "Disabling certain cookies may affect some Website functionality."
    ]
  },
  {
    "title": "Data Security",
    "blocks": [
      "We take reasonable technical and organizational measures designed to protect information against unauthorized access, loss, misuse, alteration, or disclosure.",
      "However, no method of transmission or electronic storage is completely secure.",
      "Therefore, while we take reasonable precautions, we cannot guarantee absolute security of information transmitted to or stored by us."
    ]
  },
  {
    "title": "Data Retention",
    "blocks": [
      "We may retain information for as long as reasonably necessary to:",
      [
        "Provide or administer our services;",
        "Evaluate applications;",
        "Maintain business records;",
        "Resolve disputes;",
        "Enforce agreements;",
        "Meet legal or regulatory obligations; or",
        "Protect our legitimate business interests."
      ],
      "Retention periods may vary depending on the nature and purpose of the information."
    ]
  },
  {
    "title": "Third-Party Services",
    "blocks": [
      "Our Website may use third-party services for functions such as:",
      [
        "Website hosting;",
        "Analytics;",
        "Communication;",
        "Forms;",
        "Security;",
        "Cloud storage; or",
        "Other technical services."
      ],
      "These third parties may process information according to their own privacy policies and applicable contractual obligations.",
      "We are not responsible for the independent privacy practices of third-party websites or services."
    ]
  },
  {
    "title": "Third-Party Links",
    "blocks": [
      "The Website may contain links to external websites or platforms.",
      "If you follow a third-party link, you will leave the NXTFUND Website.",
      "We do not control the privacy policies or practices of those third-party websites and recommend reviewing their privacy policies before providing information."
    ]
  },
  {
    "title": "Your Privacy Rights",
    "blocks": [
      "Depending on applicable law, you may have rights regarding your personal information, which may include the ability to:",
      [
        "Request access to certain personal information;",
        "Request correction of inaccurate information;",
        "Request deletion where legally applicable;",
        "Withdraw certain permissions or consent;",
        "Raise concerns regarding the processing of your information; and",
        "Request information about how your data is handled."
      ],
      "To exercise an applicable privacy right, contact us using the details provided below.",
      "We may need to verify your request before taking action."
    ]
  },
  {
    "title": "Children’s Privacy",
    "blocks": [
      "The Website is not intended to knowingly collect personal information from children in circumstances where such collection is prohibited by applicable law.",
      "If you believe that a child has provided personal information to us improperly, please contact us so that we can review the matter and take appropriate action where required."
    ]
  },
  {
    "title": "International Data Transfers",
    "blocks": [
      "Depending on the technology providers and services used by NXTFUND, information may be processed or stored in locations outside the user’s state or country.",
      "Where applicable, we will take reasonable steps to ensure that such processing is carried out in accordance with applicable legal requirements."
    ]
  },
  {
    "title": "Application and Communication Data",
    "blocks": [
      "Information submitted through application forms, contact forms, emails, or other communication channels may be retained for legitimate business purposes, including reviewing applications, responding to enquiries, maintaining records, and communicating with applicants.",
      "Please ensure that information submitted through these channels is accurate and that you have the necessary authority to provide it."
    ]
  },
  {
    "title": "Fraud and Security",
    "blocks": [
      "We may collect and use technical or other information where reasonably necessary to:",
      [
        "Detect suspicious activity;",
        "Prevent fraud;",
        "Protect our Website;",
        "Investigate security incidents;",
        "Prevent unauthorized access; and",
        "Protect our users, business, and systems."
      ],
      "Information may be disclosed to relevant authorities where legally required or reasonably necessary to address unlawful activity."
    ]
  },
  {
    "title": "Changes to This Privacy Policy",
    "blocks": [
      "We may update this Privacy Policy from time to time to reflect changes in our services, technology, legal requirements, or business practices.",
      "When we make changes, we may update the “Last Updated” date displayed at the beginning of this Policy.",
      "You are encouraged to review this page periodically."
    ]
  },
  {
    "title": "Governing Law",
    "blocks": [
      "This Privacy Policy shall be governed by the laws applicable in India, subject to any mandatory rights or protections available to you under applicable law.",
      "Subject to applicable law, courts having jurisdiction in Jaipur, Rajasthan, India shall have jurisdiction over matters arising from or relating to this Privacy Policy."
    ]
  },
  {
    "title": "Contact Us",
    "blocks": [
      "If you have questions, concerns, requests, or complaints regarding this Privacy Policy or the handling of your information, you can contact us using the details below."
    ]
  },
  {
    "title": "Acceptance",
    "blocks": [
      "By using www.nxtfund.in, you acknowledge that you have read and understood this Privacy Policy.",
      "If you do not agree with the practices described in this Policy, please discontinue use of the Website."
    ]
  }
];
