import type { InvestorFields } from "./validation";

export const investorRoleStatement = "NxtFund facilitates verification and introductions. Investment agreements are made directly with founders. Startup investments involve risk, including loss of capital. Funding and returns are not guaranteed.";
export const investorSubmissionUnavailable = "Investor submissions are currently unavailable. Your entries have not been submitted or saved.";

export const investorFieldLabels: Record<keyof InvestorFields, string> = {
  fullName: "Full name", email: "Email", phone: "Phone", registeringAs: "Registering as", organisationName: "Organisation name", investorCategory: "Investor category",
  sectors: "Sectors of interest", stages: "Preferred startup stages", minimumInvestment: "Minimum investment (INR)", maximumInvestment: "Maximum investment (INR)", riskAcknowledged: "Investment risk acknowledgement",
};
