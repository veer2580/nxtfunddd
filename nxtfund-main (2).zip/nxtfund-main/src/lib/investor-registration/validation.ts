export const investorCategoryOptions = [
  { value: "vc", label: "VC Network" },
  { value: "hni-uhni", label: "HNI/UHNI" },
  { value: "angel", label: "Angel" },
  { value: "strategic", label: "Strategic" },
  { value: "global", label: "Global Investor Partner" },
  { value: "family-office", label: "Family Office" },
] as const;
export const registrationTypeOptions = [
  { value: "individual", label: "Individual" },
  { value: "organisation", label: "Organisation" },
] as const;
export const investorFieldLimits = {
  fullName: 120, email: 254, phone: 25, registeringAs: 20, organisationName: 160,
  investorCategory: 100, sectors: 500, stages: 500, minimumInvestment: 18, maximumInvestment: 18, riskAcknowledged: 5,
} as const;
export type InvestorFields = Record<keyof typeof investorFieldLimits, string>;
export type InvestorErrors = Partial<Record<keyof InvestorFields, string>>;
export const initialInvestorFields: InvestorFields = {
  fullName: "", email: "", phone: "", registeringAs: "individual", organisationName: "", investorCategory: "",
  sectors: "", stages: "", minimumInvestment: "", maximumInvestment: "", riskAcknowledged: "false",
};

// Compare integer paise so decimal ranges are exact even at the technical upper limit.
function parseInvestment(value: string) {
  if (!/^\d+(\.\d{1,2})?$/.test(value) || value.length > investorFieldLimits.minimumInvestment) return undefined;
  const [rupees, fraction = ""] = value.split(".");
  const paise = BigInt(rupees) * BigInt(100) + BigInt(fraction.padEnd(2, "0"));
  return paise >= BigInt(100) && paise <= BigInt("10000000000000") ? paise : undefined;
}

export function validateInvestorFields(values: InvestorFields, step?: number): InvestorErrors {
  const errors: InvestorErrors = {};
  const groups: (keyof InvestorFields)[][] = [
    ["fullName", "email", "phone", "registeringAs", "investorCategory", ...(values.registeringAs === "organisation" ? ["organisationName" as const] : [])],
    ["sectors", "stages", "minimumInvestment", "maximumInvestment"],
  ];
  for (const field of step === undefined ? groups.flat() : groups[step] ?? []) {
    const value = values[field];
    if (typeof value !== "string" || !value.trim()) errors[field] = "Enter this information.";
    else if ([...value].length > investorFieldLimits[field]) errors[field] = `Use ${investorFieldLimits[field]} characters or fewer.`;
  }
  if (step === undefined || step === 0) {
    if (!registrationTypeOptions.some(option => option.value === values.registeringAs)) errors.registeringAs = "Choose Individual or Organisation.";
    if (!values.investorCategory || !values.investorCategory.split(",").every(value => investorCategoryOptions.some(option => option.value === value))) errors.investorCategory = "Choose one or more of the six investor categories.";
    if (!errors.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) errors.email = "Enter a valid email address, for example investor@example.com.";
    if (!errors.phone && (!/^\+?[\d\s().-]+$/.test(values.phone) || !/^\d{7,15}$/.test(values.phone.replace(/\D/g, "")))) errors.phone = "Enter a phone number with 7–15 digits, including country code where applicable.";
  }
  if (step === undefined || step === 1) {
    const minimum = typeof values.minimumInvestment === "string" ? parseInvestment(values.minimumInvestment) : undefined;
    const maximum = typeof values.maximumInvestment === "string" ? parseInvestment(values.maximumInvestment) : undefined;
    for (const [field, amount] of [["minimumInvestment", minimum], ["maximumInvestment", maximum]] as const) {
      if (!errors[field] && amount === undefined) errors[field] = "Enter an INR amount from 1 to 100,000,000,000, with at most two decimal places.";
    }
    if (minimum !== undefined && maximum !== undefined && maximum < minimum) errors.maximumInvestment = "Maximum must be greater than or equal to minimum.";
  }
  return errors;
}
