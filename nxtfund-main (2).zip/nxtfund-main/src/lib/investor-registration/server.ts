import "server-only";
import { investorFieldLimits, validateInvestorFields, type InvestorFields, type InvestorErrors } from "./validation";

// Call inside an authenticated ingestion handler before future durable writes.
export function validateInvestorRegistration(data: FormData) {
  const fields = Object.fromEntries(Object.keys(investorFieldLimits).map(key => [key, data.get(key) ?? ""])) as InvestorFields;
  const errors: InvestorErrors = validateInvestorFields(fields);
  for (const field of Object.keys(investorFieldLimits) as (keyof InvestorFields)[]) {
    if (typeof fields[field] !== "string" || [...fields[field]].length > investorFieldLimits[field] || data.getAll(field).length > 1) errors[field] = "Enter one text value within the field limit.";
  }
  if (fields.riskAcknowledged !== "true") errors.riskAcknowledged = "Acknowledge investment risk before submitting.";
  if (Object.keys(errors).length) return { ok: false as const, errors };
  const normalized = Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, value.trim()])) as InvestorFields;
  normalized.investorCategory = [...new Set(normalized.investorCategory.split(","))].join(",");
  if (normalized.registeringAs === "individual") normalized.organisationName = "";
  return { ok: true as const, fields: normalized };
}
