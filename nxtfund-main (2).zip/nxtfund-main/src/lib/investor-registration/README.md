# Investor registration integration

The approved three-step form remains at `/investor-registration`. Its server validator is reused and extended for multi-category selection and the local risk acknowledgement. See [backend foundation and exact setup](../../../docs/investor-backend-foundation.md).

## What works locally

`npm run dev:backend` enables a durable private SQLite database and password/session authentication on loopback. Sign in/create an account inline without unmounting the registration form. Unsaved entries stay in React memory, not localStorage/sessionStorage. Only a committed database save returns a non-sensitive reference and initial-review status. Identical duplicate retries return the original receipt; changed duplicates conflict without overwriting records.

Save drafts explicitly and verify account email before submission. Investor Overview is `/app/investor`; `/account/investor-registration` remains connected. Manual review is `/review/investor-registrations` (also `/ops/reviews`). Server-derived account ownership and database reviewer roles protect all private APIs. Reviewer roles are provisioned only by the trusted local CLI. Public profiles cannot be published, and preferences are never added to public capital totals. Email verification and manual investor approval are separate implemented local states. Notifications use a transactional outbox and private development mailbox (`npm run mail:local -- --watch`); external email delivery is not configured.

## Validation

Limits: name 120 characters, email 254, phone 25 (7–15 digits), organisation 160, sectors/stages 500 each, type 20, categories 100, amounts 18 each. Types and six category IDs are allowlisted; category selections are deduplicated. Risk acknowledgement is recorded with a local version and timestamp. Organisation name is required for Organisation and omitted for Individual. Duplicate/non-text/oversized values are rejected. Typical tickets follow the handbook range of INR 1 to 100,000,000,000 with at most two decimal places; maximum must be at least minimum. Exact strings are stored; validator comparisons use integer paise. These are input limits, not eligibility rules or committed capital.

## Production remains disabled

`NODE_ENV=production` disables local account, submission and reviewer operations regardless of the local flag. A production provider/adapter, deployment configuration, approved privacy/consent text, real email/account recovery, operator MFA and release checks are still required. No selected provider or credentials existed before this task. PostgreSQL + Supabase Auth is proposed; it has not been provisioned or integrated. Local SQLite/password authentication must not be presented as a deployed solution.

The receipt component is now mounted only after the committed local API response. Error, validation and retry paths retain entries; no receipt comes from a query parameter, browser storage, client fields or validation results. Private applicant information and passwords are never logged by application code.
