export const investorCategories = [
  { name: "VC Network", description: "Venture capital firms backing scalable startups.", x: 50, y: 10 },
  { name: "HNI / UHNI Investors", description: "Individual investors exploring ambitious ventures.", x: 80, y: 32 },
  { name: "Angel Investors", description: "Early-stage investors supporting emerging founders.", x: 80, y: 68 },
  { name: "Strategic Investors", description: "Industry connections alongside capital.", x: 50, y: 90 },
  { name: "Global Investor Partners", description: "Cross-border investment perspectives.", x: 20, y: 68 },
  { name: "Family Offices", description: "Investment teams with a long-term outlook.", x: 20, y: 32 },
] as const;
