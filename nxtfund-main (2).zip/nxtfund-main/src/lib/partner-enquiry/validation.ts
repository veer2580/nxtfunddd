export const organisationOptions = [
  { value: "incubator-accelerator", label: "Incubator or accelerator" },
  { value: "education-research", label: "Educational or research institution" },
  { value: "industry-community", label: "Industry body or founder community" },
  { value: "professional-services", label: "Professional or service organisation" },
  { value: "other", label: "Other" },
] as const;
export const collaborationOptions = [
  { value: "readiness", label: "Startup readiness and mentoring" },
  { value: "introductions", label: "Founder/investor introductions" },
  { value: "events", label: "Events and programmes" },
  { value: "services", label: "Professional services" },
  { value: "other", label: "Other" },
] as const;
export const partnerFieldLimits = {
  organisationName: 160, organisationType: 40, website: 500, contactPerson: 120,
  email: 254, phone: 25, proposal: 3000,
} as const;
export const partnerLabels: Record<keyof typeof partnerFieldLimits, string> = {
  organisationName: "Organisation name", organisationType: "Organisation type", website: "Website — optional",
  contactPerson: "Contact person", email: "Email", phone: "Phone", proposal: "Partnership proposal/message",
};
export type PartnerFields = Record<keyof typeof partnerFieldLimits, string> & { collaborationAreas: string[] };
export type PartnerErrors = Partial<Record<keyof PartnerFields, string>>;
export const initialPartnerFields: PartnerFields = {
  organisationName: "", organisationType: "", website: "", contactPerson: "", email: "", phone: "", proposal: "", collaborationAreas: [],
};
export function validatePartnerFields(fields: PartnerFields): PartnerErrors {
  const errors: PartnerErrors = {};
  for (const key of Object.keys(partnerFieldLimits) as (keyof typeof partnerFieldLimits)[]) {
    const value = fields[key];
    if (typeof value !== "string" || (key !== "website" && !value.trim())) errors[key] = "Enter this information.";
    else if (value.length > partnerFieldLimits[key]) errors[key] = `Use ${partnerFieldLimits[key]} characters or fewer.`;
  }
  if (!organisationOptions.some(option => option.value === fields.organisationType)) errors.organisationType = "Choose an organisation type.";
  if (!errors.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim())) errors.email = "Enter a valid email address.";
  if (!errors.phone && (!/^\+?[\d\s().-]+$/.test(fields.phone) || !/^\d{7,15}$/.test(fields.phone.replace(/\D/g, "")))) errors.phone = "Enter a phone number with 7–15 digits.";
  if (!errors.website && fields.website.trim()) {
    try {
      const url = new URL(fields.website.trim());
      if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || !url.hostname.includes(".")) throw new Error("Invalid website");
    } catch { errors.website = "Enter a full http:// or https:// website URL without sign-in credentials, or leave it blank."; }
  }
  if (!Array.isArray(fields.collaborationAreas) || fields.collaborationAreas.length === 0 || fields.collaborationAreas.length > collaborationOptions.length || new Set(fields.collaborationAreas).size !== fields.collaborationAreas.length || fields.collaborationAreas.some(value => !collaborationOptions.some(option => option.value === value))) errors.collaborationAreas = "Select one or more of the available collaboration areas.";
  return errors;
}
