# Partner enquiry integration and routes

`/partners` describes potential collaboration, not existing partner relationships. No approved partner records exist, so no directory is shown. `/become-a-partner` is the canonical enquiry page, connected from the header, Partners closing action and Ecosystem invitation. Header, Ecosystem teaser/selector and footer link to `/partners`. Events/Gallery now exist with empty states; verified activity records remain absent.

The details/review form uses React memory only, with no network submission or localStorage. Leaving or refreshing clears entries. Only final Submit is disabled. `POST /api/partner-enquiries` returns 503 without reading request bodies or generating receipts, including retries. No public enquiry or record retrieval endpoints exist.

`validatePartnerEnquiry` is a server-only integration boundary, not operational persistence. It validates text lengths, organisation and collaboration allowlists, duplicate fields/options, email/phone and optional HTTP(S) URLs without embedded credentials. It never fetches the supplied website. Fields are projected to a private enquiry only; submitted approval/publication fields are ignored. Collaboration selections are repeated `collaborationAreas` form fields, limited to the five allowed unique options.

Before enabling submission, configure:

- Durable database/migrations and private enquiry records, with an initial review status and a non-sensitive backend-issued reference only after commit. No automatic partnership approval or directory publication.
- Authentication and server-side owner/reviewer permissions on every enquiry read. Keep contact/proposal data out of public data projections and logs.
- Server body limits, origin/CSRF and abuse protection, unique idempotency keys and duplicate handling. Preserve client entries on recoverable validation/persistence errors; pending UI must prevent repeated sends.
- Tests against real infrastructure for saved success, rollback/server failure, idempotent retries and unauthorized enquiry reads. Those flows are not implemented or simulated while infrastructure is absent.

No email delivery, partnership approval, success screen or production deployment is claimed.
