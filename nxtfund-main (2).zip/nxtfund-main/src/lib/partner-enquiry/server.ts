import "server-only";
import { partnerFieldLimits, validatePartnerFields, type PartnerFields, type PartnerErrors } from "./validation";

// Integration boundary only: no persistence, approval or public record is created here.
export function validatePartnerEnquiry(data: FormData) {
  const errors: PartnerErrors = {};
  const fields = Object.fromEntries(Object.keys(partnerFieldLimits).map(key => [key, data.get(key) ?? ""])) as Omit<PartnerFields, "collaborationAreas">;
  for (const key of Object.keys(partnerFieldLimits) as (keyof typeof partnerFieldLimits)[]) {
    if (typeof fields[key] !== "string" || fields[key].length > partnerFieldLimits[key] || data.getAll(key).length > 1) errors[key] = "Enter one text value within the field limit.";
  }
  const areas = data.getAll("collaborationAreas");
  if (areas.some(area => typeof area !== "string")) errors.collaborationAreas = "Choose text values from the available collaboration areas.";
  if (Object.keys(errors).length) return { ok: false as const, errors };
  const privateEnquiry = { ...Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, value.trim()])), collaborationAreas: areas as string[] } as PartnerFields;
  Object.assign(errors, validatePartnerFields(privateEnquiry));
  if (Object.keys(errors).length) return { ok: false as const, errors };
  return { ok: true as const, privateEnquiry };
}
