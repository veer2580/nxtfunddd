# Contact enquiry availability

`/contact-us` is the canonical page, connected in the header and footer. `/startup-registration` and `/investor-registration` are existing dedicated information/form routes; their own submissions remain unavailable.

No durable database, authentication provider, deployment-backed abuse protection/rate limiter or approved contact email/phone/address/social links exist. The contact-details block is omitted. Submit is disabled; inputs and inline validation work. React memory only: no localStorage, network submission, success screen, reference, email delivery or response-time promise. Leaving/refresh clears entries.

`validateContactEnquiry` is a server-only integration boundary, not persistence. It rejects missing, invalid, oversized, duplicate and non-text fields, validates the five allowed categories and optional phone, and projects only private enquiry fields. No supplied approval/publication fields are trusted. The unavailable `POST /api/contact-enquiries` returns no-store 503 without reading private bodies, including retries. No enquiry retrieval endpoint exists.

Before enabling Submit:

- Configure durable private enquiry storage/migrations, transactional commit and backend-issued non-sensitive receipt. Render success only after commit.
- Enforce authenticated owner/reviewer access on every enquiry read; never expose messages or contact details in public projections or logs.
- Configure deployment-supported shared server-side rate limiting, request/body limits, origin/CSRF checks and abuse protection. Do not substitute an in-memory limiter for durable multi-instance enforcement.
- Add idempotency keys/unique constraints, pending UI that prevents repeat sends, recoverable validation/persistence errors that retain entries, and transactional duplicate handling.
- Test real saved success, failed persistence/rollback, concurrent retries, denied record access and rate limiting against the configured infrastructure.

These backend flows are not operational and are not simulated. Server validation and the fail-closed 503 guard are testable now.
