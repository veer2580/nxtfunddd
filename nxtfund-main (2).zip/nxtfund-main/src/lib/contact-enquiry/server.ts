import "server-only";
import { contactFieldLimits, validateContactFields, type ContactFields, type ContactErrors } from "./validation";

// Pure integration boundary; confidential enquiries are never published or saved here.
export function validateContactEnquiry(data: FormData) {
  const fields = Object.fromEntries(Object.keys(contactFieldLimits).map(key => [key, data.get(key) ?? ""])) as ContactFields;
  const errors: ContactErrors = {};
  for (const key of Object.keys(contactFieldLimits) as (keyof ContactFields)[]) {
    if (typeof fields[key] !== "string" || fields[key].length > contactFieldLimits[key] || data.getAll(key).length > 1) errors[key] = "Enter one text value within the field limit.";
  }
  if (Object.keys(errors).length) return { ok: false as const, errors };
  const privateEnquiry = Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, value.trim()])) as ContactFields;
  Object.assign(errors, validateContactFields(privateEnquiry));
  if (Object.keys(errors).length) return { ok: false as const, errors };
  return { ok: true as const, privateEnquiry };
}
