export const contactCategoryOptions = [
  { value: "startup", label: "Startup" },
  { value: "investor", label: "Investor" },
  { value: "partner", label: "Partner" },
  { value: "media", label: "Media" },
  { value: "other", label: "Other" },
] as const;
export const contactFieldLimits = { name: 120, email: 254, phone: 25, category: 20, message: 3000 } as const;
export const contactLabels: Record<keyof typeof contactFieldLimits, string> = { name: "Name", email: "Email", phone: "Phone", category: "I am a", message: "Message" };
export type ContactFields = Record<keyof typeof contactFieldLimits, string>;
export type ContactErrors = Partial<Record<keyof ContactFields, string>>;
export const initialContactFields: ContactFields = { name: "", email: "", phone: "", category: "", message: "" };

export function validateContactFields(fields: ContactFields): ContactErrors {
  const errors: ContactErrors = {};
  for (const key of Object.keys(contactFieldLimits) as (keyof ContactFields)[]) {
    const value = fields[key];
    if (typeof value !== "string" || (key !== "phone" && !value.trim())) errors[key] = "Enter this information.";
    else if (value.length > contactFieldLimits[key]) errors[key] = `Use ${contactFieldLimits[key]} characters or fewer.`;
  }
  if (!errors.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim())) errors.email = "Enter a valid email address.";
  if (!errors.phone && fields.phone.trim() && (!/^\+?[\d\s().-]+$/.test(fields.phone.trim()) || !/^\d{7,15}$/.test(fields.phone.replace(/\D/g, "")))) errors.phone = "Enter a phone number with 7–15 digits, or leave it blank.";
  if (!contactCategoryOptions.some(option => option.value === fields.category)) errors.category = "Choose Startup, Investor, Partner, Media or Other.";
  return errors;
}
