import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createRequire } from 'node:module';
import ts from 'typescript';

// Compile the actual server validator in an isolated Node runtime, without adding a test framework.
const directory = await mkdtemp(join(tmpdir(), 'app-nivesh-validation-'));
for (const name of ['validation', 'documents', 'server']) {
  const source = await readFile(new URL(`../src/lib/startup-application/${name}.ts`, import.meta.url), 'utf8');
  const output = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  await writeFile(join(directory, name + '.js'), output);
}
// Next enforces this marker at bundling time; the isolated test runtime only tests validation.
await mkdir(join(directory, 'node_modules/server-only'), { recursive: true });
await writeFile(join(directory, 'node_modules/server-only/index.js'), 'module.exports = {};');
const require = createRequire(import.meta.url);
const { validateStartupApplication } = require(join(directory, 'server.js'));
const { validatePdf, maxDocumentBytes } = require(join(directory, 'documents.js'));
after(() => rm(directory, { recursive: true, force: true }));

function pdf(extra = '') {
  let body = '%PDF-1.7\n';
  const offsets = [0];
  for (const [index, content] of ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>', '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] >>' + extra].entries()) {
    offsets.push(Buffer.byteLength(body));
    body += `${index + 1} 0 obj\n${content}\nendobj\n`;
  }
  const start = Buffer.byteLength(body);
  body += 'xref\n0 4\n0000000000 65535 f \n' + offsets.slice(1).map(offset => String(offset).padStart(10, '0') + ' 00000 n \n').join('');
  body += `trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n${start}\n%%EOF\n`;
  return new File([body], 'pitch.pdf', { type: 'application/pdf' });
}
function application(explanation = false) {
  const data = new FormData();
  for (const [key, value] of Object.entries({ companyName: 'Example Startup', founderName: 'Example Founder', email: 'founder@example.com', phone: '+91 98765 43210', sector: 'Fintech', stage: 'Prototype', fundingAsk: '2500000.50', useOfFunds: 'Product development and hiring', financialExplanation: explanation ? 'Pre-revenue startup with no financial statements yet.' : '', financialUnavailable: String(explanation) })) data.set(key, value);
  data.set('pitchDeck', pdf());
  if (!explanation) data.set('financialDocument', pdf());
  return data;
}

test('server validates both document and early-stage explanation paths without persisting', async () => {
  for (const mode of [true, false]) {
    const result = await validateStartupApplication(application(mode));
    assert.equal(result.ok, true);
    assert.equal(result.financialUnavailable, mode);
    assert.equal(result.financialDocument === null, mode);
    assert.equal('reference' in result, false);
  }
});
test('server rejects invalid, oversized, missing, non-text and duplicate fields', async () => {
  for (const [key, value] of [['email', 'bad'], ['phone', '123'], ['companyName', 'x'.repeat(161)], ['founderName', ''], ['fundingAsk', '-1'], ['fundingAsk', '1e7'], ['fundingAsk', '1.001'], ['fundingAsk', '1000000000000'], ['useOfFunds', 'x'.repeat(3001)]]) {
    const data = application(); data.set(key, value);
    const result = await validateStartupApplication(data);
    assert.equal(result.ok, false); assert.ok(result.errors[key]);
  }
  const malformedPhone = application(); malformedPhone.set('phone', '++91 9876543210'); assert.ok((await validateStartupApplication(malformedPhone)).errors.phone);
  const missing = new FormData(); assert.equal((await validateStartupApplication(missing)).ok, false);
  const nonText = application(); nonText.set('founderName', pdf()); assert.ok((await validateStartupApplication(nonText)).errors.founderName);
  const duplicate = application(); duplicate.append('email', 'another@example.com'); assert.ok((await validateStartupApplication(duplicate)).errors.email);
});
test('server rejects financial-mode bypasses and incomplete explanations', async () => {
  const missing = application(); missing.delete('financialDocument'); assert.ok((await validateStartupApplication(missing)).errors.financialDocument);
  const reason = application(true); reason.set('financialExplanation', 'short'); assert.ok((await validateStartupApplication(reason)).errors.financialExplanation);
  const ambiguous = application(true); ambiguous.set('financialDocument', pdf()); assert.ok((await validateStartupApplication(ambiguous)).errors.financialDocument);
  const mode = application(); mode.set('financialUnavailable', 'yes'); assert.equal((await validateStartupApplication(mode)).ok, false);
});
test('rejects spoofed, oversized, encrypted, active and malformed PDFs', async () => {
  const rejected = [
    new File(['hello'], 'pitch.pdf', { type: 'application/pdf' }),
    new File([await pdf().arrayBuffer()], 'pitch.txt', { type: 'application/pdf' }),
    new File([await pdf().arrayBuffer()], 'pitch.pdf', { type: 'text/plain' }),
    new File([new Uint8Array(maxDocumentBytes + 1)], 'pitch.pdf', { type: 'application/pdf' }),
    pdf('/JavaScript (alert) '), pdf('/Encrypt 5 0 R'), pdf('/EmbeddedFile 5 0 R'),
    new File(['%PDF-1.7\n1 0 obj\n/Root 1 0 R\nendobj\nstartxref\n0\n%%EOF'], 'pitch.pdf', { type: 'application/pdf' }),
  ];
  for (const file of rejected) assert.ok(await validatePdf(file, true));
  for (const file of rejected) { const data = application(); data.set('pitchDeck', file); assert.ok((await validateStartupApplication(data)).errors.pitchDeck); }
});
test('read failures return a useful error and duplicate documents are rejected', async () => {
  const unreadable = pdf(); unreadable.arrayBuffer = async () => { throw Error('read failed'); }; assert.match(await validatePdf(unreadable, true), /could not be read/);
  const data = application(); data.append('pitchDeck', pdf()); assert.ok((await validateStartupApplication(data)).errors.pitchDeck);
});
