import { test } from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { renderToStaticMarkup } from 'react-dom/server';
import { createElement } from 'react';
import ts from 'typescript';

const require = createRequire(import.meta.url);
const modules = {
  '../components/site-link': '../src/app/components/site-link.tsx',
  './site-navigation': '../src/app/components/site-navigation.ts',
  confirmation: '../src/app/startup-registration/application-confirmation.tsx',
  investorConfirmation: '../src/app/investor-registration/investor-confirmation.tsx',
};
function load(name) {
  const source = readFileSync(new URL(modules[name], import.meta.url), 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true } }).outputText;
  const compiledModule = { exports: {} };
  // Styles are handled by Next; this isolated test checks receipt content and real link resolution.
  const resolve = name => name.endsWith('.css') ? {} : modules[name] ? load(name) : require(name);
  new Function('require', 'module', 'exports', code)(resolve, compiledModule, compiledModule.exports);
  return compiledModule.exports;
}
const Confirmation = load('confirmation').default;
test('confirmation uses a supplied receipt and distinguishes the overview from current status', () => {
  const html = renderToStaticMarkup(createElement(Confirmation, { application: { reference: 'TEST-RECEIPT-ONLY', status: 'Backend test status' } }));
  assert.match(html, /Application received\./);
  assert.match(html, /TEST-RECEIPT-ONLY/);
  assert.match(html, /Backend test status/);
  assert.match(html, /Later stages depend on review outcomes/);
  assert.match(html, /href="\/"/);
  assert.match(html, /href="\/due-diligence"/);
  assert.doesNotMatch(html, /href="\/#due-diligence"/);
  assert.doesNotMatch(html, /Track application|dashboard|aria-current/);
});
test('incomplete receipts cannot render a confirmation', () => {
  for (const application of [{ reference: '', status: 'test' }, { reference: 'test', status: ' ' }]) {
    assert.equal(renderToStaticMarkup(createElement(Confirmation, { application })), '');
  }
});

const { getPublicDestination, isPublicRouteAvailable } = load('./site-navigation');
test('page availability stays independent of submissions and never redirects missing pages', () => {
  assert.equal(getPublicDestination('/startup-registration'), '/startup-registration');
  assert.equal(getPublicDestination('/startup-registration?source=startups'), '/startup-registration?source=startups');
  assert.equal(isPublicRouteAvailable('/startup-registration'), true);
  for (const route of ['/investors', '/investor-registration', '/due-diligence', '/truevalue', '/truevalue/list-your-business', '/ecosystem', '/partners', '/become-a-partner', '/events', '/gallery', '/contact-us']) assert.equal(getPublicDestination(route), route);
  for (const route of ['/privacy-policy', '/terms-and-conditions']) {
    assert.equal(getPublicDestination(route), route);
  }
  assert.equal(getPublicDestination('/#process'), '/#process');
});

const InvestorConfirmation = load('investorConfirmation').default;
test('investor confirmation requires a receipt and does not claim verification or publication', () => {
  assert.equal(renderToStaticMarkup(createElement(InvestorConfirmation, { registration: { reference: '', status: '' } })), '');
  const html = renderToStaticMarkup(createElement(InvestorConfirmation, { registration: { reference: 'TEST-INVESTOR-ONLY', status: 'Backend test status' } }));
  assert.match(html, /Registration received\./);
  assert.match(html, /TEST-INVESTOR-ONLY/);
  assert.match(html, /Backend test status/);
  assert.match(html, /Submission does not mean verification or access approval is complete/);
  assert.match(html, /href="\/investors"/);
  assert.doesNotMatch(html, /email sent|Track registration|dashboard/);
});

// Navigation must describe actual pages independently of their submission capability.
test('canonical route availability and navigation agree with the filesystem', () => {
  const root = new URL('../src/app/', import.meta.url);
  const pages = readdirSync(root, { recursive: true }).filter(path => /(^|\/)page\.tsx$/.test(path));
  for (const page of pages) {
    const route = '/' + page.replace(/(^|\/)page\.tsx$/, '');
    assert.equal(getPublicDestination(route), route);
  }
  const { navigation } = load('./site-navigation');
  for (const item of navigation.flatMap(item => [item, ...(item.children ?? [])])) {
    assert.ok(existsSync(new URL(`.${item.href}/page.tsx`, root)), `Missing destination: ${item.href}`);
    assert.equal(getPublicDestination(item.href), item.href);
  }
  for (const missing of ['/truevalue/unpublished-listing']) {
    assert.equal(getPublicDestination(missing), undefined);
  }
});
