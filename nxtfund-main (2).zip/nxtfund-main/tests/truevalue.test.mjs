import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import ts from 'typescript';

const require = createRequire(import.meta.url);
const modules = {
  '@/lib/truevalue/public-opportunities': '../src/lib/truevalue/public-opportunities.ts',
  opportunities: '../src/app/truevalue/truevalue-opportunities.tsx',
  './truevalue-visual': '../src/app/truevalue/truevalue-visual.tsx',
  '../components/site-link': '../src/app/components/site-link.tsx',
  './site-navigation': '../src/app/components/site-navigation.ts',
  error: '../src/app/truevalue/error.tsx',
  loading: '../src/app/truevalue/loading.tsx',
};
function load(name) {
  const source = readFileSync(new URL(modules[name], import.meta.url), 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true } }).outputText;
  const compiled = { exports: {} };
  const resolve = dependency => {
    if (dependency === 'server-only' || dependency.endsWith('.css')) return {};
    // Real header/router behavior is covered in browser checks, not this isolated render test.
    if (dependency === '../components/site-header') return { __esModule: true, default: () => createElement('header') };
    return modules[dependency] ? load(dependency) : require(dependency);
  };
  new Function('require', 'module', 'exports', code)(resolve, compiled, compiled.exports);
  return compiled.exports;
}

test('server opportunity boundary returns unavailable without records or an invented empty result', () => {
  const { getPublicOpportunityState } = load('@/lib/truevalue/public-opportunities');
  assert.deepEqual(getPublicOpportunityState(), { status: 'unavailable' });
  assert.equal(getPublicOpportunityState().listings, undefined);
});
test('disconnected opportunities render disabled filters and useful public guidance', () => {
  const html = renderToStaticMarkup(createElement(load('opportunities').default));
  assert.match(html, /<fieldset disabled=""/);
  assert.match(html, /Opportunity browsing and filters are currently unavailable/);
  assert.match(html, /Clear filters/);
  assert.match(html, /Full ownership/);
  assert.match(html, /Majority stake/);
  assert.match(html, /Minority stake/);
  assert.match(html, /href="#buyer-access"/);
  assert.doesNotMatch(html, /No results|0 listings|Request access|Unlock|\/truevalue\/[^"< ]+/);
});
test('route error recovery uses retry and never renders raw error details', () => {
  let attempts = 0;
  const element = load('error').default({ error: new Error('PRIVATE-CONTACT-AND-FINANCIAL-DATA'), retry: () => attempts++ });
  const html = renderToStaticMarkup(element);
  assert.match(html, /TrueValue is temporarily unavailable/);
  assert.doesNotMatch(html, /PRIVATE-CONTACT-AND-FINANCIAL-DATA/);
  function findButton(node) {
    if (!node || typeof node !== 'object') return undefined;
    if (node.type === 'button') return node;
    for (const child of [node.props?.children].flat(Infinity)) {
      const found = findButton(child);
      if (found) return found;
    }
  }
  findButton(element).props.onClick();
  assert.equal(attempts, 1);
});
test('native loading fallback announces navigation without simulated listings', () => {
  const html = renderToStaticMarkup(createElement(load('loading').default));
  assert.match(html, /role="status"/);
  assert.match(html, /Opening the TrueValue pathway/);
  assert.doesNotMatch(html, /listing-id|asking-price|Loading listings|counter/);
});
