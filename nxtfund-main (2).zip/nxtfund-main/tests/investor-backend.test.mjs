import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { openStore, authenticate, sessionAccount, requireAccount, saveRegistration, getRegistration, reviewQueue, reviewRegistration, applicantMessages, revokeSession, localBackendEnabled } from '../src/lib/backend/local-store.mjs';

import { requestVerification, verifyEmail } from '../src/lib/backend/email-verification.mjs';
const fields = { fullName: 'Local Test Investor', email: 'investor@example.test', phone: '+919876543210', registeringAs: 'individual', organisationName: '', investorCategory: 'vc', sectors: 'Technology', stages: 'Prototype', minimumInvestment: '500000.50', maximumInvestment: '1000000.00', riskAcknowledged: 'true' };
function verified(db, email, password, create = true) { const result = authenticate(db, email, password, create); requestVerification(db, result.account, email); const mail = db.prepare("SELECT payload_json FROM notification_outbox WHERE account_id=? AND kind='email_verification'").get(result.account.id); const code = JSON.parse(mail.payload_json).body.match(/\b\d{6}\b/)[0]; assert.equal(verifyEmail(db, result.account, code).verified,true); return result; }
const password = 'local-test-password-only';
function fixture(run) {
  const directory = mkdtempSync(join(tmpdir(), 'nivesh-real-sqlite-'));
  const path = join(directory, 'private.sqlite');
  const db = openStore(path);
  try { run(db, path); } finally { db.close(); rmSync(directory, { recursive: true, force: true }); }
}
test('real SQLite commit, migration re-open and duplicate retries produce one private registration', () => fixture((db, path) => {
  const { account, token } = verified(db, 'one@example.test', password, true);
  const key = randomUUID();
  const saved = saveRegistration(db, requireAccount(db, token), fields, key);
  assert.match(saved.reference, /^INV-[A-F0-9]{24}$/);
  assert.equal(saved.statusCode, 'pending_review');
  assert.equal(saveRegistration(db, account, fields, key).reference, saved.reference);
  assert.equal(saveRegistration(db, account, fields, randomUUID()).reference, saved.reference);
  assert.throws(() => saveRegistration(db, account, { ...fields, sectors: 'Changed' }, key), error => error.status === 409);
  const second = openStore(path);
  try {
    assert.equal(getRegistration(second, account).reference, saved.reference);
    assert.equal(second.prepare('SELECT COUNT(*) AS count FROM investor_registrations').get().count, 1);
    assert.equal(second.prepare('SELECT published FROM investor_registrations').get().published, 0);
  } finally { second.close(); }
}));
test('actual SQLite insert failure rolls back and a subsequent retry commits', () => fixture(db => {
  const { account } = verified(db, 'failure@example.test', password, true);
  const key = randomUUID();
  db.exec("CREATE TRIGGER fail_registration BEFORE INSERT ON investor_registrations BEGIN SELECT RAISE(ABORT,'test storage failure'); END;");
  assert.throws(() => saveRegistration(db, account, fields, key));
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM investor_registrations').get().count, 0);
  db.exec('DROP TRIGGER fail_registration');
  assert.ok(saveRegistration(db, account, fields, key).reference);
}));
test('sessions and ownership reject anonymous, expired, revoked and cross-account private access', () => fixture(db => {
  const one = verified(db, 'owner@example.test', password, true);
  const two = verified(db, 'other@example.test', password, true);
  const saved = saveRegistration(db, one.account, fields, randomUUID());
  assert.throws(() => requireAccount(db, undefined), error => error.status === 401);
  assert.throws(() => getRegistration(db, two.account, saved.id), error => error.status === 404);
  assert.throws(() => applicantMessages(db, two.account, saved.id), error => error.status === 404);
  assert.throws(() => reviewQueue(db, two.account), error => error.status === 403);
  assert.throws(() => reviewQueue(db, { ...two.account, reviewer: true }), error => error.status === 403);
  assert.throws(() => authenticate(db, 'owner@example.test', 'wrong-password-value'), error => error.status === 401);
  const row = db.prepare('SELECT * FROM accounts WHERE id=?').get(one.account.id);
  assert.notEqual(row.password_hash, password);
  assert.equal(row.reviewer, 0);
  assert.equal(db.prepare('SELECT token_hash FROM sessions WHERE account_id=?').get(one.account.id).token_hash.includes(one.token), false);
  revokeSession(db, one.token);
  assert.equal(sessionAccount(db, one.token), null);
  db.prepare('UPDATE sessions SET expires_at=0 WHERE account_id=?').run(two.account.id);
  assert.equal(sessionAccount(db, two.token), null);
}));
test('only separately provisioned reviewers can update review; stale, self and invalid approval updates are denied', () => fixture(db => {
  const owner = verified(db, 'applicant@example.test', password, true);
  const reviewer = verified(db, 'reviewer@example.test', password, true);
  const registration = saveRegistration(db, owner.account, fields, randomUUID());
  assert.throws(() => reviewRegistration(db, owner.account, registration.id, 'in_review', '', 'pending_review', 1), error => error.status === 403);
  db.prepare('UPDATE accounts SET reviewer=1 WHERE id=?').run(reviewer.account.id);
  const authorized = requireAccount(db, reviewer.token, true);
  reviewRegistration(db, authorized, registration.id, 'in_review', '', 'pending_review', 1);
  assert.throws(() => reviewRegistration(db, authorized, registration.id, 'needs_information', 'Please clarify.', 'pending_review', 1), error => error.status === 409);
  reviewRegistration(db, authorized, registration.id, 'needs_information', 'Please clarify your preferred stages.', 'in_review', 2);
  assert.equal(applicantMessages(db, owner.account, registration.id).length, 1);
  assert.throws(() => reviewRegistration(db, authorized, registration.id, 'approved', '', 'needs_information', 3), error => error.status === 422);
  const own = saveRegistration(db, authorized, fields, randomUUID());
  assert.throws(() => reviewRegistration(db, authorized, own.id, 'in_review', '', 'pending_review', 1), error => error.status === 403);
  assert.equal(db.prepare('SELECT COUNT(*) AS count FROM investor_review_events').get().count, 2);
}));
test('production cannot be enabled with the local feature flag', () => {
  const previous = { mode: process.env.NODE_ENV, enabled: process.env.APP_NIVESH_LOCAL_BACKEND };
  try { process.env.NODE_ENV = 'production'; process.env.APP_NIVESH_LOCAL_BACKEND = '1'; assert.equal(localBackendEnabled(), false); }
  finally { if (previous.mode === undefined) delete process.env.NODE_ENV; else process.env.NODE_ENV = previous.mode; if (previous.enabled === undefined) delete process.env.APP_NIVESH_LOCAL_BACKEND; else process.env.APP_NIVESH_LOCAL_BACKEND = previous.enabled; }
});
