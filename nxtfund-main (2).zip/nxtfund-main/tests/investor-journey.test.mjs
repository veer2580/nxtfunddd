import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { randomUUID } from 'node:crypto';
import { openStore, authenticate, getRegistration, reviewRegistration, applicantMessages, reviewQueue } from '../src/lib/backend/local-store.mjs';
import { assignLocalReviewer } from '../src/lib/backend/local-admin.mjs';
import { saveDraft, readDraft } from '../src/lib/backend/investor-drafts.mjs';
import { requestVerification, verifyEmail } from '../src/lib/backend/email-verification.mjs';
import { saveRegistration, requireApprovedInvestor } from '../src/lib/backend/investor-persistence.mjs';
import { drainOutbox, deliverLocalEmail } from '../src/lib/backend/notifications.mjs';
const fields = { fullName:'Local Test',email:'owner@example.test',phone:'+919876543210',registeringAs:'individual',organisationName:'',investorCategory:'angel',sectors:'Climate',stages:'Seed',minimumInvestment:'1.01',maximumInvestment:'500000',riskAcknowledged:'true' };
async function fixture(run) {
 const directory=mkdtempSync(join(tmpdir(),'nivesh-journey-')); const path=join(directory,'private.sqlite'); const db=openStore(path);
 try { await run(db,directory,path); } finally { db.close(); rmSync(directory,{recursive:true,force:true}); }
}
const account = (db,email='owner@example.test') => authenticate(db,email,'local-test-password-only',true).account;
function code(db,owner) { const row=db.prepare("SELECT payload_json FROM notification_outbox WHERE account_id=? AND kind='email_verification' ORDER BY next_attempt_at DESC LIMIT 1").get(owner.id); return JSON.parse(row.payload_json).body.match(/\b\d{6}\b/)[0]; }
function verify(db,owner,time=Date.now()) { requestVerification(db,owner,owner.id,time); assert.equal(verifyEmail(db,owner,code(db,owner),time+1).verified,true); }
test('authenticated drafts survive database reopen; stale and cross-account writes cannot overwrite',async()=>fixture((db,directory,path)=>{
 const one=account(db),two=account(db,'other@example.test'); const saved=saveDraft(db,one,{fullName:'Draft Unicode आरती'},0); assert.equal(saved.version,1);
 const reopened=openStore(path); assert.equal(readDraft(reopened,one).fields.fullName,'Draft Unicode आरती'); reopened.close();
 assert.equal(readDraft(db,two),null); assert.throws(()=>readDraft(db,two,one.id),e=>e.status===404);
 assert.throws(()=>saveDraft(db,one,fields,0),e=>e.status===409); assert.equal(readDraft(db,one).version,1);
 saveDraft(db,two,{fullName:'Own draft',accountId:one.id},0); assert.equal(readDraft(db,one).fields.fullName,'Draft Unicode आरती');
 assert.throws(()=>saveDraft(db,one,{fullName:'x'.repeat(121)},1),e=>e.status===422);
}));
test('verification uses random private delivery, expiry, single use and replacement on resend',async()=>fixture(async(db,directory)=>{
 const one=account(db),time=Date.now(); requestVerification(db,one,'loopback',time); const first=code(db,one);
 assert.throws(()=>requestVerification(db,one,'loopback',time+59999),e=>e.status===429);
 requestVerification(db,one,'loopback',time+60000); const second=code(db,one);
 assert.equal(db.prepare('SELECT COUNT(*) AS count FROM email_challenges WHERE invalidated_at IS NOT NULL').get().count,1);
 assert.throws(()=>verifyEmail(db,one,second,time+360001),e=>e.status===422);
 requestVerification(db,one,'loopback',time+360002); const latest=code(db,one);
 const delivered=await drainOutbox(db,event=>deliverLocalEmail(event,join(directory,'mail')),time+360003); assert.equal(delivered.delivered,1);
 const email=JSON.parse(readFileSync(join(directory,'mail',readdirSync(join(directory,'mail'))[0]),'utf8')); assert.ok(email.body.includes(latest));
 assert.equal(verifyEmail(db,one,latest,time+360004).verified,true); assert.throws(()=>verifyEmail(db,one,latest,time+360005),e=>e.status===422);
 assert.match(first,/^\d{6}$/);
}));
test('five failed attempts invalidate challenge and enforce 15-minute lock; hourly destination/IP limits persist',async()=>fixture(db=>{
 const one=account(db),time=Date.now(); requestVerification(db,one,'loopback',time); const wrong=code(db,one)==='000000'?'000001':'000000';
 for(let i=0;i<5;i++) assert.equal(verifyEmail(db,one,wrong,time+i+1).verified,false);
 assert.throws(()=>requestVerification(db,one,'loopback',time+900000),e=>e.status===429);
 requestVerification(db,one,'loopback',time+900006);
 for(let i=1;i<=3;i++) requestVerification(db,one,'loopback',time+900006+i*60000);
 assert.throws(()=>requestVerification(db,one,'loopback',time+1200006),e=>e.status===429);
 const other=account(db,'limited@example.test'); for(let i=0;i<20;i++) db.prepare('INSERT INTO verification_sends VALUES (?,?,?)').run(one.id,db.prepare('SELECT ip_hash FROM verification_sends LIMIT 1').get().ip_hash,time+1);
 assert.throws(()=>requestVerification(db,other,'loopback',time+2),e=>e.status===429);
}));
test('submission requires actual verified account and acknowledgement; rollback includes snapshot and outbox',async()=>fixture(db=>{
 const one=account(db),key=randomUUID(); assert.throws(()=>saveRegistration(db,one,fields,key),e=>e.status===403);
 assert.throws(()=>saveRegistration(db,{...one,emailVerified:true},fields,key),e=>e.status===403); verify(db,one);
 assert.throws(()=>saveRegistration(db,one,{...fields,riskAcknowledged:'false'},key),e=>e.status===422);
 db.exec("CREATE TRIGGER fail_outbox BEFORE INSERT ON notification_outbox WHEN NEW.kind='investor_submission' BEGIN SELECT RAISE(ABORT,'local failure'); END;");
 assert.throws(()=>saveRegistration(db,one,fields,key)); assert.equal(db.prepare('SELECT COUNT(*) AS count FROM investor_registrations').get().count,0); assert.equal(db.prepare('SELECT COUNT(*) AS count FROM investor_submission_snapshots').get().count,0);
 db.exec('DROP TRIGGER fail_outbox'); const saved=saveRegistration(db,one,fields,key); assert.equal(saveRegistration(db,one,fields,key).reference,saved.reference); assert.equal(db.prepare("SELECT COUNT(*) AS count FROM notification_outbox WHERE kind='investor_submission'").get().count,1);
}));
test('same review system supports requested changes, immutable resubmission, approval and suspension with authorization',async()=>fixture(db=>{
 const owner=account(db),reviewer=account(db,'reviewer@example.test'),other=account(db,'other@example.test'); verify(db,owner); const saved=saveRegistration(db,owner,fields,randomUUID());
 assert.throws(()=>reviewQueue(db,{...other,reviewer:true}),e=>e.status===403); db.prepare('UPDATE accounts SET reviewer=1 WHERE id=?').run(reviewer.id);
 assert.throws(()=>reviewRegistration(db,reviewer,saved.id,'approved','Reviewed.',saved.statusCode,1),e=>e.status===422);
 reviewRegistration(db,reviewer,saved.id,'in_review','Review started.','pending_review',1,'Internal only');
 reviewRegistration(db,reviewer,saved.id,'needs_information','Clarify stages.','in_review',2,'Never public');
 assert.equal(applicantMessages(db,owner,saved.id).some(m=>m.message.includes('Never public')),false);
 const draft=saveDraft(db,owner,{...fields,stages:'Growth'},readDraft(db,owner).version); const revised=saveRegistration(db,owner,{...fields,stages:'Growth'},randomUUID(),draft.version); assert.equal(revised.reference,saved.reference); assert.equal(revised.revision,2);
 assert.equal(db.prepare('SELECT COUNT(*) AS count FROM investor_submission_snapshots').get().count,2);
 reviewRegistration(db,reviewer,saved.id,'in_review','Review revision.','pending_review',4); reviewRegistration(db,reviewer,saved.id,'approved','Local review completed.','in_review',5);
 assert.doesNotThrow(()=>requireApprovedInvestor(db,owner)); assert.throws(()=>requireApprovedInvestor(db,other),e=>e.status===403);
 assert.equal(db.prepare('SELECT published FROM investor_registrations').get().published,0);
 assert.throws(()=>reviewRegistration(db,reviewer,saved.id,'suspended','Reason.','approved',5),e=>e.status===409);
 reviewRegistration(db,reviewer,saved.id,'suspended','Review required.','approved',6); assert.throws(()=>requireApprovedInvestor(db,owner),e=>e.status===403);
 db.prepare('UPDATE accounts SET reviewer=1 WHERE id=?').run(owner.id); assert.throws(()=>reviewRegistration(db,owner,saved.id,'in_review','Self.','suspended',7),e=>e.status===403);
 assert.throws(()=>getRegistration(db,other,saved.id),e=>e.status===404);
}));
test('email failure after commit leaves success intact; retry delivery is deduplicated and stops after five failures',async()=>fixture(async(db,directory)=>{
 const one=account(db); verify(db,one); const saved=saveRegistration(db,one,fields,randomUUID()); const now=Date.now()+1000;
 const blocked=join(directory,'blocked-mail');writeFileSync(blocked,'This file deliberately prevents creating a mail directory.');
 const failure=await drainOutbox(db,event=>deliverLocalEmail(event,blocked),now); assert.ok(failure.failed); assert.equal(getRegistration(db,one).reference,saved.reference);
 const success=await drainOutbox(db,event=>deliverLocalEmail(event,join(directory,'mail')),now+10000); assert.ok(success.delivered); const count=readdirSync(join(directory,'mail')).length;
 await drainOutbox(db,event=>deliverLocalEmail(event,join(directory,'mail')),now+20000); assert.equal(readdirSync(join(directory,'mail')).length,count);
 const row=db.prepare("SELECT * FROM notification_outbox WHERE kind='investor_submission'").get(); deliverLocalEmail({...row,email:'owner@example.test'},join(directory,'mail')); assert.equal(readdirSync(join(directory,'mail')).length,count);
 db.prepare("UPDATE notification_outbox SET state='pending',attempts=4,next_attempt_at=0 WHERE id=?").run(row.id);
 await drainOutbox(db,event=>deliverLocalEmail(event,blocked),now+30000); assert.equal(db.prepare('SELECT state,attempts FROM notification_outbox WHERE id=?').get(row.id).state,'failed');
 assert.equal(db.prepare('SELECT attempts FROM notification_outbox WHERE id=?').get(row.id).attempts,5);
}));

test('trusted local reviewer provisioning is audited atomically and revocation takes effect immediately',async()=>fixture(db=>{
 const owner=account(db); assignLocalReviewer(db,owner.email); assert.equal(db.prepare('SELECT reviewer FROM accounts WHERE id=?').get(owner.id).reviewer,1); assert.equal(db.prepare('SELECT COUNT(*) AS count FROM account_permission_events').get().count,1);
 assignLocalReviewer(db,owner.email,false); assert.throws(()=>reviewQueue(db,owner),e=>e.status===403);
 db.exec("CREATE TRIGGER fail_permission_audit BEFORE INSERT ON account_permission_events BEGIN SELECT RAISE(ABORT,'local audit failure'); END;");
 assert.throws(()=>assignLocalReviewer(db,owner.email)); assert.equal(db.prepare('SELECT reviewer FROM accounts WHERE id=?').get(owner.id).reviewer,0);
}));
