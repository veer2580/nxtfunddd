import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createRequire } from 'node:module';
import ts from 'typescript';

const directory = await mkdtemp(join(tmpdir(), 'app-nivesh-investor-validation-'));
for (const name of ['validation', 'content', 'server', 'http', 'route']) {
  const path = name === 'http' ? '../src/lib/backend/http.ts' : name === 'route' ? '../src/app/api/investor-registrations/route.ts' : `../src/lib/investor-registration/${name}.ts`;
  const source = (await readFile(new URL(path, import.meta.url), 'utf8')).replace('@/lib/investor-registration/content', './content').replace('@/lib/investor-registration/server', './server').replace('@/lib/backend/http', './http').replace('@/lib/backend/local-store.mjs', './local-store.mjs').replace('from "next/headers"', 'from "./headers"');
  const output = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  await writeFile(join(directory, name + '.js'), output);
}
await writeFile(join(directory, 'headers.js'), 'module.exports = { cookies() { throw new Error("Disabled backend must not read cookies"); } };');
for (const name of ['local-store', 'investor-persistence', 'email-verification', 'notifications']) await writeFile(join(directory, name + '.mjs'), (await readFile(new URL('../src/lib/backend/' + name + '.mjs', import.meta.url), 'utf8')).replace('../investor-registration/review-states.mjs', './review-states.mjs'));
await writeFile(join(directory, 'review-states.mjs'), await readFile(new URL('../src/lib/investor-registration/review-states.mjs', import.meta.url), 'utf8'));
// Bundling enforces server-only; this isolated runtime tests the actual validator and 503 guard.
await mkdir(join(directory, 'node_modules/server-only'), { recursive: true });
await writeFile(join(directory, 'node_modules/server-only/index.js'), 'module.exports = {};');
const require = createRequire(import.meta.url);
const { validateInvestorRegistration } = require(join(directory, 'server.js'));
const { POST } = require(join(directory, 'route.js'));
after(() => rm(directory, { recursive: true, force: true }));

function registration(organisation = false) {
  const data = new FormData();
  for (const [key, value] of Object.entries({ fullName: ' Test Investor ', email: 'investor@example.com', phone: '+91 98765 43210', registeringAs: organisation ? 'organisation' : 'individual', organisationName: organisation ? 'Example Organisation' : 'Previously entered name', investorCategory: 'vc', sectors: 'Fintech, clean energy', stages: 'Prototype, early revenue', minimumInvestment: '500000.50', maximumInvestment: '2500000', riskAcknowledged: 'true' })) data.set(key, value);
  return data;
}

test('server validates private individual/organisation preferences without claiming persistence', () => {
  for (const organisation of [false, true]) {
    const data = registration(organisation);
    data.set('publishProfile', 'true');
    const result = validateInvestorRegistration(data);
    assert.equal(result.ok, true);
    assert.equal(result.fields.fullName, 'Test Investor');
    assert.equal(result.fields.organisationName, organisation ? 'Example Organisation' : '');
    assert.equal(result.fields.publishProfile, undefined);
    assert.equal(result.reference, undefined);
  }
});
test('server enforces conditional organisation, identity fields and enum allowlists', () => {
  for (const [field, value] of [['fullName', ''], ['email', 'invalid'], ['phone', '++919876543210'], ['registeringAs', 'other'], ['investorCategory', 'made-up']]) {
    const data = registration(); data.set(field, value);
    const result = validateInvestorRegistration(data);
    assert.equal(result.ok, false); assert.ok(result.errors[field]);
  }
  const data = registration(true); data.delete('organisationName');
  assert.ok(validateInvestorRegistration(data).errors.organisationName);
});
test('server compares exact INR ranges and rejects invalid or excessive amounts', () => {
  for (const [minimum, maximum] of [['2', '1'], ['100.02', '100.01'], ['999999999999.99', '999999999999.98'], ['0', '1'], ['0.01', '1'], ['1', '100000000000.01'], ['-1', '2'], ['1e6', '2000000'], ['1.001', '2'], ['1', '1000000000000'], ['1,000', '2000'], ['1', 'Infinity']]) {
    const data = registration(); data.set('minimumInvestment', minimum); data.set('maximumInvestment', maximum);
    assert.equal(validateInvestorRegistration(data).ok, false, minimum + '/' + maximum);
  }
  for (const amount of ['1', '100.50', '100000000000']) {
    const data = registration(); data.set('minimumInvestment', amount); data.set('maximumInvestment', amount);
    assert.equal(validateInvestorRegistration(data).ok, true);
  }
});
test('server rejects missing, duplicate, oversized and non-text fields', () => {
  for (const mutate of [data => data.delete('sectors'), data => data.append('email', 'duplicate@example.com'), data => data.set('stages', 'a'.repeat(501)), data => data.set('organisationName', 'a'.repeat(161)), data => data.set('phone', new File(['test'], 'identity.txt')), data => data.set('minimumInvestment', new File(['1'], 'amount.txt'))]) {
    const data = registration(); mutate(data); assert.equal(validateInvestorRegistration(data).ok, false);
  }
});
test('unavailable submission never reads private data or returns a receipt, including retries', async () => {
  for (let index = 0; index < 2; index++) {
    const request = { formData() { throw Error('Must not read private data'); } };
    const response = await POST(request);
    assert.equal(response.status, 503);
    assert.equal(response.headers.get('Cache-Control'), 'private, no-store');
    const body = await response.json();
    assert.equal(body.error, 'SUBMISSION_UNAVAILABLE');
    assert.equal(body.reference, undefined);
    assert.equal(body.fields, undefined);
  }
});

const { safeReturnUrl, checkOrigin, readJson } = require(join(directory, 'http.js'));
test('authentication redirects accept only the defined internal journey routes', () => {
  for (const path of ['/investor-registration', '/account/investor-registration', '/review/investor-registrations']) assert.equal(safeReturnUrl(path), path);
  for (const path of ['https://example.test', '//example.test', '/\\example.test', '%2f%2fexample.test', 'javascript:alert(1)', '/login', '/account/investor-registration?next=evil', null, { to: '/' }]) assert.equal(safeReturnUrl(path), '/investor-registration');
});
test('request boundaries reject foreign origins, unsupported or oversized bodies and malformed JSON', async () => {
  assert.doesNotThrow(() => checkOrigin(new Request('http://localhost:3101/api/auth/session', { headers: { origin: 'http://localhost:3101' } })));
  assert.throws(() => checkOrigin(new Request('http://localhost:3101/api/auth/session', { headers: { origin: 'https://example.test' } })), error => error.status === 403);
  for (const [body, type, status] of [['{}', 'text/plain', 415], ['bad', 'application/json', 422], ['[]', 'application/json', 422], ['x'.repeat(32769), 'application/json', 413]]) {
    await assert.rejects(() => readJson(new Request('http://localhost:3101/api/auth/session', { method: 'POST', headers: { 'Content-Type': type }, body })), error => error.status === status);
  }
});
