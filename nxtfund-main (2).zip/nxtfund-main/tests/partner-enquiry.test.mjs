import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createRequire } from 'node:module';
import ts from 'typescript';
const directory = await mkdtemp(join(tmpdir(), 'app-nivesh-partner-'));
for (const name of ['validation', 'server', 'route']) {
  const path = name === 'route' ? '../src/app/api/partner-enquiries/route.ts' : `../src/lib/partner-enquiry/${name}.ts`;
  const source = await readFile(new URL(path, import.meta.url), 'utf8');
  await writeFile(join(directory, name + '.js'), ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText);
}
await mkdir(join(directory, 'node_modules/server-only'), { recursive: true });
await writeFile(join(directory, 'node_modules/server-only/index.js'), 'module.exports = {};');
const require = createRequire(import.meta.url);
const { validatePartnerEnquiry } = require(join(directory, 'server.js'));
const { POST } = require(join(directory, 'route.js'));
after(() => rm(directory, { recursive: true, force: true }));
function enquiry() {
  const data = new FormData();
  Object.entries({ organisationName: ' Test Organisation ', organisationType: 'education-research', website: 'https://example.org/programmes', contactPerson: 'Test Contact', email: 'contact@example.org', phone: '+91 98765 43210', proposal: 'Explore founder readiness and knowledge exchange.' }).forEach(([key, value]) => data.set(key, value));
  data.append('collaborationAreas', 'readiness'); data.append('collaborationAreas', 'introductions'); return data;
}
test('validates private partner enquiries without receipt, approval or publication', () => {
  const data = enquiry(); data.set('approved', 'true'); data.set('publish', 'true');
  const result = validatePartnerEnquiry(data); assert.equal(result.ok, true);
  assert.equal(result.privateEnquiry.organisationName, 'Test Organisation'); assert.deepEqual(result.privateEnquiry.collaborationAreas, ['readiness', 'introductions']);
  assert.equal(result.reference, undefined); assert.equal(result.privateEnquiry.approved, undefined); assert.equal(result.privateEnquiry.publish, undefined);
  data.set('website', ''); assert.equal(validatePartnerEnquiry(data).ok, true);
});
test('rejects invalid organisation/category/contact and unsafe or malformed optional website values', () => {
  for (const [key, value] of [['organisationType', 'unapproved'], ['email', 'invalid'], ['phone', 'abc'], ['website', 'example.org'], ['website', 'javascript:alert(1)'], ['website', 'ftp://example.org'], ['website', 'https://user:secret@example.org'], ['website', 'https://']]) {
    const data = enquiry(); data.set(key, value); assert.equal(validatePartnerEnquiry(data).ok, false, key + ':' + value);
  }
});
test('rejects missing, oversized, duplicate or non-text fields and invalid multi-select values', () => {
  for (const mutate of [data => data.delete('proposal'), data => data.set('proposal', 'a'.repeat(3001)), data => data.append('email', 'second@example.org'), data => data.set('contactPerson', new File(['private'], 'contact.txt')), data => data.delete('collaborationAreas'), data => data.append('collaborationAreas', 'readiness'), data => data.append('collaborationAreas', 'unapproved'), data => data.append('collaborationAreas', new File(['private'], 'area.txt'))]) {
    const data = enquiry(); mutate(data); assert.equal(validatePartnerEnquiry(data).ok, false);
  }
});
test('unavailable submission returns 503 on retries without reading confidential bodies or inventing success', async () => {
  for (let i = 0; i < 2; i++) {
    const response = await POST({ formData() { throw Error('Must not read contact data'); } });
    assert.equal(response.status, 503); assert.equal(response.headers.get('cache-control'), 'no-store');
    const result = await response.json(); assert.equal(result.error, 'SUBMISSION_UNAVAILABLE'); assert.equal(result.reference, undefined);
  }
});
