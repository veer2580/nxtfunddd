import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createRequire } from 'node:module';
import ts from 'typescript';
const directory = await mkdtemp(join(tmpdir(), 'app-nivesh-contact-'));
for (const name of ['validation', 'server', 'route']) {
  const path = name === 'route' ? '../src/app/api/contact-enquiries/route.ts' : `../src/lib/contact-enquiry/${name}.ts`;
  const source = await readFile(new URL(path, import.meta.url), 'utf8');
  await writeFile(join(directory, name + '.js'), ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText);
}
await mkdir(join(directory, 'node_modules/server-only'), { recursive: true });
await writeFile(join(directory, 'node_modules/server-only/index.js'), 'module.exports = {};');
const require = createRequire(import.meta.url);
const { validateContactEnquiry } = require(join(directory, 'server.js'));
const { POST } = require(join(directory, 'route.js'));
after(() => rm(directory, { recursive: true, force: true }));
function enquiry() {
  const data = new FormData();
  Object.entries({ name: ' Test Contact ', email: 'name@example.com', phone: '', category: 'startup', message: 'A question about the startup pathway.' }).forEach(([key, value]) => data.set(key, value)); return data;
}
test('validates all enquiry categories and optional phone without claiming persistence or publication', () => {
  for (const category of ['startup', 'investor', 'partner', 'media', 'other']) {
    const data = enquiry(); data.set('category', category); data.set('publish', 'true');
    const result = validateContactEnquiry(data); assert.equal(result.ok, true); assert.equal(result.privateEnquiry.name, 'Test Contact'); assert.equal(result.privateEnquiry.phone, ''); assert.equal(result.privateEnquiry.publish, undefined); assert.equal(result.reference, undefined);
  }
  const data = enquiry(); data.set('phone', '+91 98765 43210'); assert.equal(validateContactEnquiry(data).ok, true);
});
test('rejects invalid server inputs, excess lengths, duplicate fields and file values', () => {
  for (const mutate of [data => data.delete('name'), data => data.set('message', ' '), data => data.set('email', 'invalid'), data => data.set('phone', 'abc'), data => data.set('category', 'unapproved'), data => data.set('name', 'a'.repeat(121)), data => data.set('message', 'a'.repeat(3001)), data => data.append('email', 'second@example.com'), data => data.set('message', new File(['private'], 'message.txt'))]) {
    const data = enquiry(); mutate(data); assert.equal(validateContactEnquiry(data).ok, false);
  }
});
test('unavailable submission returns 503 on retries without reading private bodies or returning success', async () => {
  for (let i = 0; i < 2; i++) {
    const response = await POST({ formData() { throw Error('Must not ingest'); } });
    assert.equal(response.status, 503); assert.equal(response.headers.get('cache-control'), 'no-store'); const result = await response.json(); assert.equal(result.error, 'SUBMISSION_UNAVAILABLE'); assert.equal(result.reference, undefined);
  }
});
