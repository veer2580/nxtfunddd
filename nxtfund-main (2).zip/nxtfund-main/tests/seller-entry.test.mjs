import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createRequire } from 'node:module';
import ts from 'typescript';
const directory = await mkdtemp(join(tmpdir(), 'app-nivesh-seller-'));
for (const name of ['validation', 'server', 'route']) {
  const path = name === 'route' ? '../src/app/api/truevalue/seller-listings/route.ts' : `../src/lib/truevalue/seller-entry/${name}.ts`;
  const source = await readFile(new URL(path, import.meta.url), 'utf8');
  await writeFile(join(directory, name + '.js'), ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText);
}
await mkdir(join(directory, 'node_modules/server-only'), { recursive: true });
await writeFile(join(directory, 'node_modules/server-only/index.js'), 'module.exports = {};');
const require = createRequire(import.meta.url);
const { validateSellerSubmission } = require(join(directory, 'server.js'));
const { POST } = require(join(directory, 'route.js'));
after(() => rm(directory, { recursive: true, force: true }));
function submission() {
  const fields = { sellerName: ' Test Seller ', email: 'seller@example.com', phone: '+91 98765 43210', sellerRole: 'Owner', businessName: 'Private Company', sector: 'Software', location: 'Mumbai', description: 'Private description', saleType: 'majority', stake: '60', askingPrice: '1000000.50', included: 'Ownership rights', financialAvailability: 'unavailable', revenue: '', profit: '', period: '', financialExplanation: 'Pre-revenue business', publicDescription: 'Software business offering an ownership opportunity.' };
  const data = new FormData(); Object.entries(fields).forEach(([key, value]) => data.set(key, value)); return data;
}
test('seller validator separates proposed public information and private fields without saving or publishing', () => {
  const data = submission(); data.set('published', 'true'); data.set('reviewStatus', 'approved');
  const result = validateSellerSubmission(data); assert.equal(result.ok, true);
  assert.equal(result.privateFields.sellerName, 'Test Seller');
  assert.deepEqual(Object.keys(result.proposedPublic).sort(), ['askingPrice', 'publicDescription', 'saleType', 'sector']);
  assert.equal(result.proposedPublic.businessName, undefined); assert.equal(result.reference, undefined);
  assert.equal(result.privateFields.published, undefined); assert.equal(result.privateFields.reviewStatus, undefined);
});
test('seller validation rejects invalid identity, types, amounts, conditional stakes and identifying public contacts', () => {
  for (const [key, value] of [['email', 'invalid'], ['phone', 'abc'], ['saleType', 'other'], ['askingPrice', '0'], ['askingPrice', '1e6'], ['askingPrice', '1000000000000'], ['stake', '50'], ['stake', '100'], ['publicDescription', 'Call +91 98765 43210'], ['publicDescription', 'seller@example.com'], ['publicDescription', 'https://example.com']]) {
    const data = submission(); data.set(key, value); assert.equal(validateSellerSubmission(data).ok, false, key + ':' + value);
  }
  const minority = submission(); minority.set('saleType', 'minority'); minority.set('stake', '50'); assert.equal(validateSellerSubmission(minority).ok, true);
  minority.set('stake', '50.01'); assert.equal(validateSellerSubmission(minority).ok, false);
  const full = submission(); full.set('saleType', 'full'); full.set('stake', '90'); assert.equal(validateSellerSubmission(full).privateFields.stake, '');
});
test('financial availability allows honest explanations or available figures with reporting period and losses', () => {
  const data = submission(); data.set('financialExplanation', ''); assert.equal(validateSellerSubmission(data).ok, false);
  data.set('financialAvailability', 'available'); data.set('revenue', '0'); data.set('profit', '-25000.50'); data.set('period', 'FY 2025–26');
  assert.equal(validateSellerSubmission(data).ok, true);
  data.set('period', ''); assert.equal(validateSellerSubmission(data).ok, false);
  data.set('period', 'FY 2025–26'); data.set('revenue', '-1'); assert.equal(validateSellerSubmission(data).ok, false);
});
test('rejects duplicate, oversized, non-text fields and every upload while storage is unavailable', () => {
  for (const mutate of [data => data.append('email', 'second@example.com'), data => data.set('businessName', 'a'.repeat(161)), data => data.set('sellerName', new File(['private'], 'name.txt')), data => data.set('documents', new File(['%PDF-fake'], 'document.pdf')), data => data.set('otherUpload', new File(['private'], 'document.exe'))]) {
    const data = submission(); mutate(data); assert.equal(validateSellerSubmission(data).ok, false);
  }
});
test('unavailable ingestion returns 503 on retries without reading confidential bodies or issuing success', async () => {
  for (let attempt = 0; attempt < 2; attempt++) {
    const response = await POST({ formData() { throw Error('Must not ingest'); } });
    assert.equal(response.status, 503); assert.equal(response.headers.get('cache-control'), 'no-store');
    const result = await response.json(); assert.equal(result.error, 'SUBMISSION_UNAVAILABLE'); assert.equal(result.reference, undefined);
  }
});
