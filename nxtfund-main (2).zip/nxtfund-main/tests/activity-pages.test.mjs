import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import ts from 'typescript';
const require = createRequire(import.meta.url);
const modules = {
  events: '../src/app/events/page.tsx', gallery: '../src/app/gallery/page.tsx',
  '../components/activity-visual': '../src/app/components/activity-visual.tsx',
  '../components/activity-error': '../src/app/components/activity-error.tsx',
  eventsError: '../src/app/events/error.tsx', galleryError: '../src/app/gallery/error.tsx',
  '../components/site-link': '../src/app/components/site-link.tsx', './site-link': '../src/app/components/site-link.tsx',
  './site-navigation': '../src/app/components/site-navigation.ts',
};
function load(name) {
  const source = readFileSync(new URL(modules[name], import.meta.url), 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true } }).outputText;
  const compiled = { exports: {} };
  const resolve = dependency => {
    if (dependency.endsWith('.css')) return {};
    if (dependency.endsWith('/site-header')) return { __esModule: true, default: () => createElement('header') };
    // Scroll/router interactions are checked with the real components in the browser.
    if (dependency === '../components/activity-section') return { __esModule: true, default: ({ id, children }) => createElement('section', { id }, children) };
    return modules[dependency] ? load(dependency) : require(dependency);
  };
  new Function('require', 'module', 'exports', code)(resolve, compiled, compiled.exports);
  return compiled.exports;
}
test('activity pages render honest empty states without unverified photos, fake dates or inactive filters', () => {
  for (const name of ['events']) {
    const html = renderToStaticMarkup(createElement(load(name).default));
    assert.equal((html.match(/<h1\b/g) ?? []).length, 1);
    assert.doesNotMatch(html, /<img\b|<time\b|<select\b|<dialog\b|Gemini|ecosystem-stage|ecosystem-panel|Register now/);
    if (name === 'events') { assert.match(html, /Upcoming events will appear here when announced\./); assert.match(html, /No verified past events are available to show\./); }
  }
});
test('gallery page references photos that exist in public/images/gallery', async () => {
  const { readFileSync, existsSync } = await import('node:fs');
  const source = readFileSync(new URL('../src/app/gallery/page.tsx', import.meta.url), 'utf8');
  const sources = [...source.matchAll(/src: "(\/images\/gallery\/[^"]+)"/g)].map((match) => match[1]);
  assert.ok(sources.length > 0);
  for (const src of sources) assert.ok(existsSync(new URL(`../public${src}`, import.meta.url)), src);
  assert.equal((source.match(/alt: "/g) ?? []).length, sources.length);
});
test('both activity error boundaries use genuine retry without exposing raw errors', () => {
  for (const name of ['eventsError', 'galleryError']) {
    let retries = 0;
    const wrapper = load(name).default({ error: new Error('PRIVATE-DETAILS'), retry: () => retries++ });
    const html = renderToStaticMarkup(wrapper);
    assert.match(html, /temporarily unavailable/); assert.doesNotMatch(html, /PRIVATE-DETAILS/);
    const element = wrapper.type(wrapper.props);
    function findButton(node) {
      if (!node || typeof node !== 'object') return;
      if (node.type === 'button') return node;
      for (const child of [node.props?.children].flat(Infinity)) { const found = findButton(child); if (found) return found; }
    }
    findButton(element).props.onClick(); assert.equal(retries, 1);
  }
});
