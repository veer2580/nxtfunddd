# NxtFund source handoff

Snapshot: 4 October 2026. This archive contains the current working source, including local uncommitted changes. It has not been deployed. It excludes installed dependencies, build output, Git history, local accounts/databases, private documents, development mail and credentials. The supplied approved 44-page handbook is in `docs/NxtFund-MVP-Handoff.pdf`; latest explicit owner approvals take precedence where it conflicts with the implementation.

## Install and run

Use **Node.js 24** (tested with **24.21.0**) and npm. The local backend uses Node's native SQLite API. From the extracted `app-nivesh` folder:

```sh
npm ci
npm run dev
```

The public site opens at `http://localhost:3000`. For the real local investor journey, use separate terminals:

```sh
npm run db:local -- migrate
npm run dev:backend
```

```sh
npm run mail:local -- --watch
```

Open `http://localhost:3101/investor-registration` or `/login`; use exactly the `localhost` origin, not `127.0.0.1`, for cookie-authenticated form actions. Create a new test account: accounts and credentials are deliberately not included. New passwords require 15–128 characters. Verification messages are delivered only to the private `.local/mail/` folder, not external inboxes; codes expire after five minutes. `npm run mail:local` can also perform one delivery pass. On macOS, `open .local/mail` opens the development mailbox.

For an authorized local reviewer, create a separate account, then run `npm run db:local -- reviewer <existing-account-email>`. Visit `/review/investor-registrations` or `/ops/reviews`. Revoke with `npm run db:local -- revoke-reviewer <existing-account-email>`. Applicants cannot grant themselves reviewer access or approve themselves.

The sanitized `.env.example` contains placeholders only. The local scripts set the necessary development flag/origin; no real `.env` is needed for them. Do not enable production submission by copying local flags. Build with `npm run build -- --webpack`; `npm start` serves the production public site, with local submission disabled.

## Implemented and incomplete

- Approved public pages, shared header/footer, homepage intro/reveals, responsive layouts and established navigation are present.
- The investor journey uses real local disk SQLite: owned drafts, email verification, validated/idempotent submission, committed references, initial review, authorized manual decisions, requested-change resubmissions, applicant status and transactional notification outbox/retries.
- Submitted investors default to `/app/investor`; registration redirects to status unless server-authorized corrections are needed. Overview presents actual status and grouped read-only details. Exactly three primary workspace destinations are present: Overview, Browse startups and My interests.
- Public investor profiles remain unpublished. Startup discovery, interest submission and investment-budget editing are not connected; no listings, investors or metrics have been invented.
- Startup/document, TrueValue seller, partner and contact submissions remain unavailable. Their form pages are viewable. Private production document storage is not configured. Events/gallery have no approved activity records or photos. Terms/Privacy pages remain unavailable.
- Local implementation is not production-ready. Production submission is hard-disabled. PostgreSQL/Supabase is a proposal, not an integration.

## Checks and limitations

Before packaging, the current implementation passed ESLint, `npx tsc --noEmit`, all 47 application tests, `npm run build -- --webpack` and `git diff --check`. Real local browser regressions passed for draft restoration, submitted/changes-requested routing, refresh, keyboard sign-in/correction navigation, valid internal return destinations and logout Back/Forward privacy. Investor status layouts were checked at 320, 375, 390, 430, 768 and 1440px with reduced motion; desktop/mobile screenshots were inspected. The application tests cover SQLite commits/rollback, duplicates, ownership/reviewer denial, verification limits and notification failure/retry. No new install or production-provider test was performed as part of packaging.

Browser regressions require the local backend and an isolated Chrome debug browser on loopback port 9223; setup is in `docs/investor-backend-foundation.md`. Run `npm run test:investor-postsubmission` and `npm run test:investor-history`. They create private test fixtures. The existing sign-in limiter allows 15 attempts per 15-minute window; repeated runs may require waiting. Do not bypass it.

Physical-device, cross-browser, complete WCAG/zoom, staging load and production recovery testing remain unverified. The archive itself was checked for prohibited paths/file types and common exposed-secret patterns; that check is not a security certification.

## Approved constraints

Follow `AGENTS.md`. Preserve approved typography, hero imagery, header style, intro/scroll-lock behavior, original NxtFund content, page designs and URLs. Keep the exact homepage headline: “Fund the Next Big Idea. Back the Next Big Return.” Preserve the existing Startup/Investor pathways. Use shared tokens, focused components and meaningful visuals; respect reduced motion and keyboard/touch access. Refactor responsible styles instead of adding conflicting overrides. Do not invent people, profiles, partners, listings, metrics, guarantees, contact details or legal policies. Keep unavailable functionality honest and all investor/private document data protected server-side.

## Missing external configuration

Production requires an approved database/auth/deployment provider decision, credentials and a tested production adapter/migrations; no PostgreSQL/Supabase resources exist in this handoff. It also requires a verified transactional-email sender/provider and durable delivery worker; production account recovery, session policies and operator MFA; approved Terms/Privacy, consent/risk versions, retention/deletion policy, support identity and reviewer operating checklist; monitoring, backup/restore and deployment/rate-limit configuration. Private storage and an authorized retrieval workflow are required before document-based modules can submit. Real approved opportunity/event/gallery/partner data must be supplied before those directories can operate. There are no implemented production provider environment-variable names to configure yet; do not mistake placeholder credentials for an integrated backend.

See `docs/investor-backend-foundation.md`, module READMEs and the handbook for details. `docs/website-audit.md` is historical and may describe earlier gaps since addressed.
