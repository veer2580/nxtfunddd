import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  outputFileTracingExcludes: { "/*": ["./.local/**/*"] },
  // Keep backend testing separate from an existing marketing-site dev server.
  distDir: process.env.APP_NIVESH_LOCAL_BACKEND === "1" && process.env.NODE_ENV !== "production" ? ".next-local" : ".next",
};

export default nextConfig;
