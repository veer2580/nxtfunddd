# NxtFund website ko live karne ki guide (bina coding ke)

Is website ko live karne ke liye 3 cheezein chahiye: **GitHub** (code rakhne ke liye), **Vercel** (website chalane ke liye), aur ye project folder. Dono accounts free hain. Terminal ya command nahi chalana padega.

## Step 1: Zip ko extract karo
`nxtfund-main.zip` pe right click karke **Extract** karo. Ek folder `nxtfund-main` banega.

## Step 2: Code ko GitHub pe daalo
1. https://github.com pe account banao (ya login karo).
2. **GitHub Desktop** install karo: https://desktop.github.com . Open karke GitHub account se sign in karo.
3. GitHub Desktop me **File → Add local repository** dabao, aur `nxtfund-main` folder choose karo.
4. Agar wo bole "This directory does not appear to be a Git repository", to **create a repository** wale link pe click karo, aur **Create repository** dabao.
5. Left side me saari files dikhengi. Neeche "Summary" me likho `first version` aur **Commit to main** dabao.
6. Upar **Publish repository** dabao. Naam `nxtfund` rehne do. "Keep this code private" tick rakh sakte ho (Vercel private repo bhi le leta hai). **Publish repository** dabao.

> Browser me GitHub pe seedha upload mat karna. Browser ek baar me sirf 100 files leta hai, aur is project me 200 se zyada files hain. GitHub Desktop is problem se bachata hai.

## Step 3: Vercel se live karo
1. https://vercel.com pe jao aur **Continue with GitHub** se sign up karo.
2. **Add New → Project** dabao.
3. List me `nxtfund` dikhega. Uske saamne **Import** dabao.
4. Koi setting mat badlo. Framework apne aap **Next.js** dikhega. Environment Variables bhi kuch nahi daalne.
5. **Deploy** dabao. 2-3 minute lagenge. Phir confetti aayega aur ek link milega, jaise `nxtfund-xxxx.vercel.app`. Wahi tumhari live website hai.

## Step 4: Apna domain (nxtfund.in) jodna
**Dhyan:** abhi `nxtfund.in` pe jo purani website chal rahi hai, domain jodte hi uski jagah ye nayi website aa jayegi. Pehle Vercel ke link pe sab check kar lo, phir ye karo.
1. Vercel me project kholo, phir **Settings → Domains**.
2. `www.nxtfund.in` likho aur **Add** dabao.
3. Vercel kuch DNS records dikhayega. Unhe wahan jaake daalo jahan se tumne domain kharida hai (GoDaddy, Hostinger, etc.), uske DNS settings me.
4. 10 minute se kuch ghante me domain chalne lagega.

## Step 5: Baad me kuch badalna ho
Folder me file badlo (ya mujhse naya zip banwao aur purani files replace kar do), GitHub Desktop kholo, **Commit to main** aur phir **Push origin** dabao. Vercel apne aap 2-3 minute me website update kar dega.

## Agar Deploy fail ho jaye
Vercel me **Settings → General → Node.js Version** me `24.x` chuno, phir **Deployments** me last wale ke saamne **Redeploy** dabao. Phir bhi na chale to Vercel ka error text copy karke mujhe bhej do.

## Abhi kya kaam nahi karta
Startup application, investor registration, login aur contact form ka message bhejna abhi band hai (backend nahi juda hai). Wo pages dikhenge, par submit nahi honge. Ye original code me bhi aise hi tha.
